"""Playable single-hole demo: Augusta National, hole 12 (Golden Bell).

Wraps the real game engine -- vendored unmodified (save two WASM-only
compatibility shims, see golf/handicap.py and the font() patch in
golf/game.py) in ./golf, the same code the desktop build ships -- in an
asyncio loop for pygbag/WASM. Boots straight past the menu into the real
aim/swing/putt loop for one hole, then loops back to a fresh tee shot
instead of returning to the menu or quitting -- there is no "next hole" or
"quit" in this embed, just Golden Bell, again.
"""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pygame

from golf import game as G
from golf import sound
from golf import store

# Keep any leaderboard writes inside the browser sandbox's scratch space,
# same convention the desktop dev scripts (shots.py, smoke_test.py) use.
store.PATH = Path(tempfile.gettempdir()) / "golf_web_demo_leaderboard.json"

HOLE_NUMBER = 12


def _augusta_index() -> int:
    return next(i for i, c in enumerate(G.COURSES) if c.name == "Augusta National")


def setup(game: G.Game) -> None:
    """Configure a fresh Exhibition/Stroke Play round and jump to hole 12."""
    game.mode_index = 0  # Exhibition
    game.format_index = 0  # Stroke Play
    game.tee_index = 0  # Championship tees
    game.course_index = _augusta_index()
    game.names[0] = "You"
    game.start_round()
    hole = next(h for h in game.all_holes if h.number == HOLE_NUMBER)
    game.holes = [hole]
    game.hole_index = 0
    game.begin_hole()


def replay(game: G.Game) -> None:
    """Play Golden Bell again instead of proceeding to a scorecard."""
    for pl in game.players:
        pl.scores = []
    game.hole_index = 0
    game.begin_hole()


async def main() -> None:
    pygame.init()
    pygame.display.set_caption("Augusta National -- Hole 12, Golden Bell")
    screen = pygame.display.set_mode((G.W, G.H))
    clock = pygame.time.Clock()
    sound.init()

    game = G.Game(screen)
    setup(game)

    while True:
        dt = min(0.05, clock.tick(G.FPS) / 1000.0)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                continue
            if (
                game.state == G.HOLE_DONE
                and ev.type == pygame.KEYDOWN
                and ev.key in (pygame.K_SPACE, pygame.K_RETURN)
            ):
                replay(game)
                continue
            if not game.handle(ev):
                # The full game treats "ESC at the menu" as quit; the demo
                # treats it as "back to the tee" so the embed never dies.
                setup(game)
                continue
        game.update(dt)
        game.draw()
        pygame.display.flip()
        await asyncio.sleep(0)


asyncio.run(main())
