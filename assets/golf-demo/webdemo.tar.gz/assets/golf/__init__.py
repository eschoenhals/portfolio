"""A Wii-Golf-flavoured 9-hole golf game."""
