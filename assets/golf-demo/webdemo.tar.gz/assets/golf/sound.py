"""Synthesised sound effects.

The game ships no audio files.  Every clip is built here out of sine tones and
filtered white noise the first time :func:`init` runs, so there is nothing to
load from disk and nothing to keep in the repo.

Two things shape the module.  Audio must never be able to take the game down --
no device, a headless run under ``SDL_AUDIODRIVER=dummy``, a mixer someone else
closed -- so every entry point swallows its exceptions and degrades to silence.
And we do not get to pick the mixer format: ``pygame.init()`` may have already
opened it in stereo at 44.1kHz, ignoring our ``pre_init`` hint, and a mono
buffer fed to a stereo mixer plays at double speed and half the length.  So the
recipes are written as functions of the sample rate and the frames are
interleaved to whatever ``pygame.mixer.get_init`` actually reports.
"""

from __future__ import annotations

import array
import math
import random
from collections.abc import Callable, Sequence

import pygame

RATE = 22050  # only a request; the mixer may already be open at another rate
MASTER = 0.85  # headroom so several clips at once still do not clip the mixer

_enabled = True
_ready = False
_sounds: dict[str, pygame.mixer.Sound] = {}


# --------------------------------------------------------------------------- building blocks


def _lowpass(xs: Sequence[float], cut: float, rate: int, cut2: float | None = None) -> list[float]:
    """One-pole lowpass, sweeping to ``cut2`` across the clip if given.  A single
    pole is the whole difference between noise that reads as water or sand and
    noise that reads as static; sweeping it is what makes the whoosh move."""
    out = [0.0] * len(xs)
    y = 0.0
    span = max(1, len(xs) - 1)
    for i, x in enumerate(xs):
        c = cut if cut2 is None else cut + (cut2 - cut) * (i / span)
        a = 1.0 - math.exp(-2.0 * math.pi * max(20.0, c) / rate)
        y += a * (x - y)
        out[i] = y
    return out


def _air(rate: int, dur: float, cut: float, cut2: float | None, thin: float, seed: int) -> list[float]:
    """A bed of filtered noise.  ``thin`` subtracts a heavily lowpassed copy,
    which takes out the rumble and leaves the hiss."""
    n = int(rate * dur)
    rng = random.Random(seed)
    band = _lowpass([rng.uniform(-1.0, 1.0) for _ in range(n)], cut, rate, cut2)
    if thin <= 0.0:
        return band
    return [b - low for b, low in zip(band, _lowpass(band, thin, rate))]


def _finish(xs: list[float], peak: float, rate: int) -> list[float]:
    """Set the level and kill the end clicks.  Filtering costs a lot of gain and
    how much depends on the cutoff, so levels are set here rather than guessed
    inside each recipe; the 2ms ramps are because a buffer that starts or ends
    away from zero pops, and a pop sounds like a bug in the game."""
    hi = max((abs(x) for x in xs), default=0.0)
    if hi > 1e-9:
        k = peak / hi
        xs = [x * k for x in xs]
    ramp = min(max(1, int(rate * 0.002)), len(xs))
    for i in range(ramp):
        xs[i] *= i / ramp
        xs[-1 - i] *= i / ramp
    return xs


def _impact(
    rate: int,
    modes: Sequence[tuple[float, float, float]],
    dur: float,
    *,
    noise: float,
    cut: float,
    ring: float,
    peak: float,
    thump: tuple[float, float, float] = (0.0, 0.0, 0.0),
    seed: int = 1,
) -> list[float]:
    """One thing hitting another, hard.

    A real strike is not a note.  It is a click -- a sub-millisecond attack and
    a broadband transient -- followed by whatever the two bodies ring at, and
    the ring is *inharmonic*: a titanium face gives a cluster of high modes at
    no musical interval, which is why the old sine-plus-octave recipe read as a
    beep rather than a crack.  So: ``modes`` are (hz, decay seconds, level)
    triples, ``thump`` is the low body knock underneath, and the noise burst
    dies in a few milliseconds because that is how long a real one lasts.
    """
    n = int(rate * dur)
    click = _air(rate, dur, cut, cut * 0.35, 0.0, seed)
    tf, td, tl = thump
    out = [0.0] * n
    for i in range(n):
        t = i / rate
        v = 0.0
        for hz, decay, level in modes:
            v += level * math.sin(2.0 * math.pi * hz * t) * math.exp(-t / decay)
        if tl > 0.0:
            v += tl * math.sin(2.0 * math.pi * tf * t) * math.exp(-t / td)
        # 0.3ms attack: instant to the ear, but not a discontinuity at sample 0.
        attack = min(1.0, t / 0.0003)
        out[i] = attack * (v * ring + click[i] * noise * 7.0 * math.exp(-t / 0.004))
    return _finish(out, peak, rate)


def _blip(rate: int, f0: float, f1: float, dur: float, peak: float) -> list[float]:
    """A UI tick.  It glides, because a flat tone this short is just a click."""
    n = int(rate * dur)
    out = [0.0] * n
    phase = 0.0
    for i in range(n):
        u = i / max(1, n - 1)
        phase += 2.0 * math.pi * (f0 + (f1 - f0) * u) / rate
        out[i] = math.sin(phase) * min(1.0, u * 12.0) * math.exp(-u * 4.0)
    return _finish(out, peak, rate)


# --------------------------------------------------------------------------- the longer clips


def _cup_hit(rate: int, level: float, bright: float, seed: int) -> list[float]:
    """One knock against the plastic liner of a hole."""
    return _impact(
        rate,
        ((820.0 * bright, 0.014, 1.0), (1330.0 * bright, 0.008, 0.55), (2150.0 * bright, 0.004, 0.3)),
        0.09,
        noise=0.55, cut=4200.0, ring=1.0, peak=level, thump=(300.0, 0.020, 0.5), seed=seed,
    )


def _holed(rate: int) -> list[float]:
    """The ball dropping in.

    Nobody mistakes this sound: a hard rattle as the ball catches the liner two
    or three times on the way down, the knocks getting closer together and
    duller as it loses energy, over the short hollow ring of the cup itself.
    The accelerating spacing is what makes it a ball settling rather than
    somebody knocking on a door.
    """
    n = int(rate * 0.70)
    out = [0.0] * n
    for k, (at_s, level, bright) in enumerate(
        ((0.000, 0.95, 1.00), (0.055, 0.72, 0.92), (0.098, 0.52, 0.86), (0.130, 0.34, 0.80),
         (0.152, 0.20, 0.75))
    ):
        at = int(rate * at_s)
        for i, v in enumerate(_cup_hit(rate, level, bright, 11 + k)):
            if at + i < n:
                out[at + i] += v
    # The cup's own hollow resonance, struck once and left to die.
    for i in range(n):
        t = i / rate
        out[i] += 0.30 * math.exp(-t / 0.075) * (
            math.sin(2.0 * math.pi * 196.0 * t) + 0.45 * math.sin(2.0 * math.pi * 262.0 * t)
        )
    return _finish(out, 0.85, rate)


def _lip(rate: int) -> list[float]:
    """A ball across the edge of the hole: one bright tick off the far lip."""
    return _impact(
        rate,
        ((1450.0, 0.010, 1.0), (2380.0, 0.005, 0.45)),
        0.08,
        noise=0.45, cut=5200.0, ring=0.9, peak=0.52, thump=(330.0, 0.014, 0.4), seed=31,
    )


def _splash(rate: int) -> list[float]:
    """Spray over a gulp.  The falling pitch is the cavity closing over the ball."""
    dur = 0.55
    spray = _air(rate, dur, 5000.0, 900.0, 0.0, 3)
    out = [0.0] * len(spray)
    for i in range(len(spray)):
        t = i / rate
        u = t / dur
        gulp = math.sin(2.0 * math.pi * (230.0 - 150.0 * u) * t) * math.exp(-u * 3.2) * 0.11
        out[i] = spray[i] * math.exp(-t / 0.13) * 1.6 + gulp
    return _finish(out, 0.8, rate)


def _sand(rate: int) -> list[float]:
    """Filtered noise and nothing else: a bunker shot has no pitch to it, and
    any ring at all turns it into a strike off hardpan."""
    body = _air(rate, 0.22, 750.0, 380.0, 0.0, 5)
    return _finish([v * math.exp(-(i / rate) / 0.055) for i, v in enumerate(body)], 0.62, rate)


def _tree(rate: int) -> list[float]:
    """A dry knock: two inharmonic modes killed fast, because wood does not ring."""
    grain = _air(rate, 0.16, 3000.0, None, 0.0, 9)
    out = [0.0] * len(grain)
    for i in range(len(grain)):
        t = i / rate
        out[i] = (
            math.sin(2.0 * math.pi * 196.0 * t) * math.exp(-t / 0.030)
            + 0.6 * math.sin(2.0 * math.pi * 437.0 * t) * math.exp(-t / 0.016)
            + grain[i] * 3.0 * math.exp(-t / 0.006)
        )
    return _finish(out, 0.75, rate)


def _cheer(rate: int) -> list[float]:
    """Applause: a swelling band of noise with sparse claps scattered over it,
    so there are individual hands in there and not just a wash."""
    hiss = _air(rate, 0.9, 2400.0, None, 180.0, 13)
    n = len(hiss)
    out = [0.0] * n
    for i in range(n):
        u = i / n
        swell = min(1.0, (u / 0.3) ** 1.4) * math.exp(-max(0.0, u - 0.35) * 3.4)
        out[i] = hiss[i] * swell * 2.2
    rng = random.Random(29)
    for _ in range(30):
        at = int(rng.triangular(0.0, n, n * 0.35))
        amp = rng.uniform(0.3, 1.0)
        for i in range(at, min(n, at + int(rate * 0.012))):
            out[i] += rng.uniform(-1.0, 1.0) * amp * math.exp(-((i - at) / rate) / 0.0025) * 0.8
    return _finish(out, 0.7, rate)


def _whoosh(rate: int) -> list[float]:
    """The clubhead passing the mic: the cutoff sweeps up while the level swells
    and dies, and it is the movement of the filter that sells it."""
    air = _air(rate, 0.34, 500.0, 4200.0, 300.0, 17)
    n = len(air)
    out = [air[i] * math.sin(math.pi * min(1.0, (i / n) ** 0.75)) ** 2 for i in range(n)]
    return _finish(out, 0.55, rate)


# Amplitudes are deliberately ranked: the driver is the loudest thing in the
# game, the putter is nearly a whisper, and the UI blips sit under both.
#
# The four strikes differ the way the real ones do, which is almost entirely in
# the ring rather than the click.  A driver is a thin titanium shell: a bright
# inharmonic crack up around 3-5kHz, gone in 40 milliseconds.  A forged iron is
# a solid lump of steel, so its modes are lower and shorter -- a "thock", not a
# crack.  A wedge is softer still and mostly turf.  A putter is a dull tap with
# no brightness at all, and that ranking is what makes the bag audible.
_RECIPES: dict[str, Callable[[int], list[float]]] = {
    "drive": lambda r: _impact(
        r,
        ((2950.0, 0.030, 1.0), (3870.0, 0.020, 0.62), (5120.0, 0.012, 0.38), (1460.0, 0.040, 0.5)),
        0.20, noise=0.85, cut=7000.0, ring=1.0, peak=0.95,
        thump=(185.0, 0.055, 0.55), seed=21,
    ),
    "iron": lambda r: _impact(
        r,
        ((1880.0, 0.020, 1.0), (2540.0, 0.013, 0.5), (3260.0, 0.007, 0.26)),
        0.15, noise=0.7, cut=5200.0, ring=1.0, peak=0.78,
        thump=(235.0, 0.038, 0.6), seed=22,
    ),
    "wedge": lambda r: _impact(
        r,
        ((980.0, 0.016, 1.0), (1290.0, 0.009, 0.45)),
        0.14, noise=0.9, cut=2600.0, ring=0.75, peak=0.52,
        thump=(210.0, 0.030, 0.7), seed=23,
    ),
    "putt": lambda r: _impact(
        r,
        ((640.0, 0.014, 1.0), (930.0, 0.007, 0.35)),
        0.11, noise=0.35, cut=1800.0, ring=1.0, peak=0.36,
        thump=(255.0, 0.022, 0.55), seed=24,
    ),
    "holed": _holed,
    "lip": _lip,
    "splash": _splash,
    "sand": _sand,
    "tree": _tree,
    "cheer": _cheer,
    "whoosh": _whoosh,
    "menu": lambda r: _blip(r, 760.0, 700.0, 0.05, 0.28),
    "select": lambda r: _blip(r, 1050.0, 1560.0, 0.08, 0.38),
}

NAMES: tuple[str, ...] = tuple(_RECIPES)


def _pack(samples: Sequence[float], channels: int) -> bytes:
    """Interleave to the mixer's channel count, clamped into 16-bit signed."""
    buf = array.array("h")
    for s in samples:
        v = int(max(-1.0, min(1.0, s)) * 32767)
        for _ in range(max(1, channels)):
            buf.append(v)
    return buf.tobytes()


# --------------------------------------------------------------------------- public interface


def init(enabled: bool = True) -> None:
    """Open the mixer if nobody else has, then build every clip.  Never raises."""
    global _enabled, _ready
    _enabled = bool(enabled)
    _ready = False
    _sounds.clear()
    if not _enabled:
        return
    try:
        if pygame.mixer.get_init() is None:
            pygame.mixer.pre_init(RATE, -16, 1, 512)
            pygame.mixer.init()
        fmt = pygame.mixer.get_init()
        if fmt is None or abs(fmt[1]) != 16:  # we only know how to write 16-bit frames
            return
        rate, channels = int(fmt[0]), int(fmt[2])
        for name, recipe in _RECIPES.items():
            _sounds[name] = pygame.mixer.Sound(buffer=_pack(recipe(rate), channels))
        _ready = True
    except Exception:
        _sounds.clear()
        _ready = False


def set_enabled(value: bool) -> None:
    global _enabled
    _enabled = bool(value)


def is_enabled() -> bool:
    return _enabled and _ready


def play(name: str, volume: float = 1.0) -> None:
    """Fire a clip.  An unknown name, a dead mixer and a module nobody
    initialised are all silent no-ops."""
    if not _enabled or not _ready:
        return
    snd = _sounds.get(name)
    if snd is None:
        return
    try:
        snd.set_volume(max(0.0, min(1.0, volume)) * MASTER)
        snd.play()
    except Exception:
        pass
