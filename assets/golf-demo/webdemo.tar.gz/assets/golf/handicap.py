"""World Handicap System (WHS/GHIN) handicap index calculation.

Pure arithmetic, no state and no I/O: everything here takes numbers or frozen
:class:`RoundRecord`s and gives numbers back, so the leaderboard page can be
rebuilt from stored rounds at any time.

The chain of calculations, in the order the WHS Rules of Handicapping walk it:

    hole scores --(net double bogey cap)--> Adjusted Gross Score
    AGS + Course Rating + Slope Rating   --> Score Differential
    best 8 of the last 20 differentials  --> Handicap Index (then soft/hard cap)
    Handicap Index + course ratings      --> Course Handicap

Two places need care.  A round is *posted* with the Course Handicap the player
held that day -- the adjusted gross therefore depends on the index that existed
*before* the round, not after -- so :func:`adjusted_gross` is separate from the
index pipeline and :attr:`RoundRecord.strokes` is expected to already be the
adjusted gross.  And the soft/hard caps compare against the Low Handicap Index,
which is itself a past Handicap Index, so :func:`index_history` walks the
rounds oldest-first and carries the cap forward rather than recursing.

This game ships no rated courses, so :func:`estimate_rating` invents a
plausible Course/Slope Rating from par and yardage.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

# pygbag's WASM CPython ships a trimmed `decimal` module without the
# ROUND_HALF_UP name bound (it's just the string constant upstream) --
# this file is a web-build-only vendored copy, patched here rather than
# in the desktop source, which doesn't have the problem.
ROUND_HALF_UP = "ROUND_HALF_UP"

# Rule 5.2: the neutral Slope Rating.  Every differential is expressed as if it
# had been shot on a course of average difficulty, which is what makes scores
# from different courses comparable.
NEUTRAL_SLOPE = 113.0

# Rule 6.1: a Handicap Index may not exceed 54.0, for any player, any gender.
MAX_INDEX = 54.0

# Rule 5.3: maximum hole score for a player without an established handicap is
# par + 5.  (With a handicap it is net double bogey -- see adjusted_gross.)
MAX_HOLE_OVER_PAR_UNESTABLISHED = 5

# Rule 5.6: soft cap kicks in 3.0 above the Low Handicap Index and halves any
# further increase; the hard cap stops the index 5.0 above it, full stop.
SOFT_CAP_THRESHOLD = 3.0
SOFT_CAP_FACTOR = 0.5
HARD_CAP_LIMIT = 5.0

# Rule 5.6: the Low Handicap Index is the lowest index held in the 365 days
# preceding the round being posted, and only exists once 20 scores are in.
LOW_INDEX_WINDOW_DAYS = 365
LOW_INDEX_MIN_ROUNDS = 20


# --------------------------------------------------------------------------- rounding
#
# The WHS rounds half *up*, always (5.5 -> 6, not 6.0 -> 6 as Python's
# banker's rounding would give).  Decimal is the cheap way to be exact about
# it; float round() would quietly turn a 12.25 differential into 12.2.


def _round_half_up(value: float, places: int = 0) -> float:
    q = Decimal(1).scaleb(-places)
    return float(Decimal(repr(float(value))).quantize(q, rounding=ROUND_HALF_UP))


def _round_int(value: float) -> int:
    return int(_round_half_up(value, 0))


# --------------------------------------------------------------------------- records


@dataclass(frozen=True)
class RoundRecord:
    """One posted score.

    ``strokes`` is the **Adjusted Gross Score** -- run raw hole scores through
    :func:`adjusted_gross` before building the record.  If ``hole_scores`` and
    ``hole_pars`` are both present the adjustment can be (re)applied later by
    :func:`score_differential`, which is handy for rounds stored before a
    handicap existed.

    ``holes`` is 9 or 18, and ``course_rating``/``slope_rating`` must be on the
    same 9- or 18-hole scale as ``par``.
    """

    strokes: int
    par: int
    holes: int
    course_rating: float
    slope_rating: float
    date: str  # ISO yyyy-mm-dd
    hole_scores: list[int] | None = None
    hole_pars: list[int] | None = None


# --------------------------------------------------------------------------- adjusted gross


def handicap_strokes(course_handicap: int, stroke_index: Sequence[int]) -> list[int]:
    """Strokes received on each hole, given the holes' stroke indexes.

    Rule 3.2 / allocation: strokes go one per hole starting at stroke index 1
    (the hardest hole) and wrap round again for handicaps above the hole count,
    so a 20 handicap on eighteen holes gets two shots on indexes 1 and 2.
    Floor division and modulo do this for plus handicaps too: a +3 comes out as
    -1 on the three *easiest* holes, which is exactly the rule.
    """
    n = len(stroke_index)
    if n == 0:
        return []
    base, extra = divmod(course_handicap, n)  # floors, so plus handicaps work
    return [base + (1 if si <= extra else 0) for si in stroke_index]


def default_stroke_index(holes: int) -> list[int]:
    """Stroke indexes when the course has none.

    This game does not rank its holes by difficulty, so we hand out indexes in
    playing order.  For a *total* adjusted gross that choice is very nearly
    free: which holes get the extra shot only matters when the player blows up
    on one of them, and over a round the difference is a stroke or two.
    """
    return list(range(1, holes + 1))


def net_double_bogey(par: int, strokes_received: int) -> int:
    """Rule 5.3: the maximum hole score for handicap purposes.

    Par + 2 + whatever handicap strokes the player gets on that hole -- i.e. a
    double bogey *net* of their shots.  Exposed on its own because the HUD wants
    to show the number while the hole is still being played.
    """
    return par + 2 + strokes_received


def adjusted_gross(
    hole_scores: Sequence[int],
    pars: Sequence[int],
    course_handicap: int | None,
    stroke_index: Sequence[int] | None = None,
) -> int:
    """Adjusted Gross Score: every hole capped for handicap purposes (Rule 5.3).

    With an established handicap the cap is **net double bogey** -- par + 2 +
    the handicap strokes the player receives on that hole -- which is what
    stops one catastrophic hole from inflating an index.  A player with no
    established handicap (``course_handicap is None``) instead caps at par + 5,
    the maximum hole score for a new player, because there are no strokes to
    allocate yet.
    """
    if len(hole_scores) != len(pars):
        raise ValueError("hole_scores and pars must be the same length")

    if course_handicap is None:
        caps = [p + MAX_HOLE_OVER_PAR_UNESTABLISHED for p in pars]
    else:
        idx = list(stroke_index) if stroke_index is not None else default_stroke_index(len(pars))
        got = handicap_strokes(course_handicap, idx)
        caps = [net_double_bogey(p, s) for p, s in zip(pars, got)]

    return sum(min(score, cap) for score, cap in zip(hole_scores, caps))


# --------------------------------------------------------------------------- differentials


def _raw_differential(ags: int, course_rating: float, slope_rating: float, pcc: float) -> float:
    """Rule 5.1: (113 / Slope) x (AGS - Course Rating - PCC), to one decimal."""
    return _round_half_up(
        (NEUTRAL_SLOPE / slope_rating) * (ags - course_rating - pcc), 1
    )


def nine_hole_differential(
    ags: int, course_rating: float, slope_rating: float, pcc: float = 0.0
) -> float:
    """The 9-hole Score Differential, on the 9-hole scale (Rule 5.1a).

    Pass the *9-hole* Course and Slope Rating -- a 9-hole rating is roughly
    half the 18-hole rating, while the 9-hole Slope Rating stays on the usual
    55-155 scale.  PCC is halved for nine holes.
    """
    return _round_half_up(
        (NEUTRAL_SLOPE / slope_rating) * (ags - course_rating - pcc / 2.0), 1
    )


def combine_nine_hole_differentials(first: float, second: float) -> float:
    """Two 9-hole differentials paired into one 18-hole differential.

    This is what the WHS actually does: nine-hole scores sit in a queue and the
    next nine played is bolted onto the previous one.  Because each half is
    already normalised to slope 113, combining is just addition.
    """
    return _round_half_up(first + second, 1)


def expand_nine_hole_differential(nine: float) -> float:
    """Scale a lone 9-hole differential to 18 by **doubling it**.

    Chosen deliberately for this game: rounds here are self-contained, so there
    is no partner nine sitting in a queue waiting to be paired, and holding a
    nine back until another one arrives would mean a 9-hole round never counted.

    The tradeoff is variance.  Real pairing averages two independent nines;
    doubling weights one nine twice, so a hot or blown-up nine moves the index
    about sqrt(2) times as hard as it should.  Since only the best 8 of 20
    differentials count, that mostly shows up as a slightly optimistic index
    for players who post a lot of nines -- acceptable for a game, and clearly
    better than dropping the score.
    """
    return _round_half_up(nine * 2.0, 1)


def score_differential(
    record: RoundRecord,
    pcc: float = 0.0,
    course_handicap: int | None = None,
    stroke_index: Sequence[int] | None = None,
) -> float:
    """Score Differential for a posted round, 18-hole scale, one decimal.

    ``record.strokes`` is taken as the Adjusted Gross Score.  If the record
    carries per-hole detail the cap is re-applied here using ``course_handicap``
    (pass the handicap the player held on the day; ``None`` means "no
    established handicap", i.e. the par + 5 cap).

    A 9-hole record produces a 9-hole differential which is then expanded to 18
    -- see :func:`expand_nine_hole_differential` for why and at what cost.
    """
    ags = record.strokes
    if record.hole_scores and record.hole_pars:
        ags = adjusted_gross(record.hole_scores, record.hole_pars, course_handicap, stroke_index)

    if record.holes == 9:
        return expand_nine_hole_differential(
            nine_hole_differential(ags, record.course_rating, record.slope_rating, pcc)
        )
    return _raw_differential(ags, record.course_rating, record.slope_rating, pcc)


# --------------------------------------------------------------------------- the index

# Rule 5.2a, the official table.  Key is the number of differentials available,
# value is (how many of the lowest to average, adjustment in strokes).  Under 3
# scores there is no index at all.  Note there is *no* 0.96 multiplier anywhere:
# "bonus for excellence" belonged to the pre-2020 USGA formula and the WHS took
# it out -- a plain average of the best 8 is the whole of Rule 5.2.
_SELECTION_TABLE: dict[int, tuple[int, float]] = {
    3: (1, -2.0),
    4: (1, -1.0),
    5: (1, 0.0),
    6: (2, -1.0),
    7: (2, 0.0),
    8: (2, 0.0),
    9: (3, 0.0),
    10: (3, 0.0),
    11: (3, 0.0),
    12: (4, 0.0),
    13: (4, 0.0),
    14: (4, 0.0),
    15: (5, 0.0),
    16: (5, 0.0),
    17: (6, 0.0),
    18: (6, 0.0),
    19: (7, 0.0),
    20: (8, 0.0),
}

MIN_ROUNDS_FOR_INDEX = 3


def selection(count: int) -> tuple[int, float] | None:
    """How many differentials to average and what to add, for ``count`` scores."""
    if count < MIN_ROUNDS_FOR_INDEX:
        return None
    return _SELECTION_TABLE[min(count, 20)]


def apply_caps(raw_index: float, low_index: float | None) -> float:
    """Rule 5.6 soft cap and hard cap, relative to the Low Handicap Index.

    Both exist to stop a temporary slump (or a stretch of sandbagging) from
    running the index away from a level the player has genuinely played to
    inside the last year.  The soft cap halves the part of the increase beyond
    3.0; the hard cap is an absolute ceiling 5.0 above the Low Index.  Nothing
    limits a *downward* move -- getting better is allowed to be instant.
    """
    if low_index is None:
        return raw_index
    increase = raw_index - low_index
    if increase <= SOFT_CAP_THRESHOLD:
        return raw_index
    capped = low_index + SOFT_CAP_THRESHOLD + (increase - SOFT_CAP_THRESHOLD) * SOFT_CAP_FACTOR
    return min(capped, low_index + HARD_CAP_LIMIT)


def handicap_index(
    differentials_newest_first: Sequence[float], low_index: float | None = None
) -> float | None:
    """Handicap Index from a score history, newest score first.

    Only the most recent 20 differentials are eligible (Rule 5.2); of those the
    lowest N are averaged per :func:`selection`, the table adjustment is added,
    the caps are applied, and the result is limited to 54.0 and rounded to one
    decimal.  Returns ``None`` with fewer than 3 scores -- there is no index to
    show yet, and inventing one would be worse than saying so.
    """
    recent = list(differentials_newest_first)[:20]
    sel = selection(len(recent))
    if sel is None:
        return None
    take, adjustment = sel

    lowest = sorted(recent)[:take]
    # Rule 5.2: the table adjustment is applied to the average *before* the
    # result is rounded, so a -1.0 never gets rounded away.
    raw = _round_half_up(sum(lowest) / len(lowest) + adjustment, 1)

    capped = apply_caps(raw, low_index)
    return _round_half_up(min(capped, MAX_INDEX), 1)


# --------------------------------------------------------------------------- history / low index


def _date(value: str) -> _dt.date:
    try:
        return _dt.date.fromisoformat(value)
    except ValueError:
        return _dt.date.min


def index_history(records_newest_first: Sequence[RoundRecord], pcc: float = 0.0) -> list[
    tuple[str, float | None]
]:
    """(date, index) after each posted round, newest first.

    Walked oldest-first internally so the Low Handicap Index can be carried
    forward: the cap for round N needs the indexes that existed at rounds
    1..N-1, and computing that recursively would be quadratic and, worse,
    ill-defined.  Records must already hold adjusted gross scores.
    """
    oldest_first = sorted(records_newest_first, key=lambda r: _date(r.date))
    diffs = [score_differential(r, pcc) for r in oldest_first]

    out: list[tuple[str, float | None]] = []
    seen: list[tuple[_dt.date, float]] = []  # (date, index) for the low-index window
    for i, rec in enumerate(oldest_first):
        played = _date(rec.date)
        # Rule 5.6: no Low Handicap Index until 20 scores are in, so no cap for
        # a player still building a history.
        low: float | None = None
        if i >= LOW_INDEX_MIN_ROUNDS:
            window = [
                idx
                for when, idx in seen
                if (played - when).days <= LOW_INDEX_WINDOW_DAYS
            ]
            low = min(window) if window else None

        history = list(reversed(diffs[: i + 1]))  # newest first, as required
        idx = handicap_index(history, low)
        out.append((rec.date, idx))
        if idx is not None:
            seen.append((played, idx))

    out.reverse()
    return out


def current_index(records_newest_first: Sequence[RoundRecord], pcc: float = 0.0) -> float | None:
    """The player's Handicap Index now, caps included. ``None`` under 3 rounds."""
    history = index_history(records_newest_first, pcc)
    return history[0][1] if history else None


def low_handicap_index(
    records_newest_first: Sequence[RoundRecord],
    as_of: str | None = None,
    pcc: float = 0.0,
) -> float | None:
    """Lowest Handicap Index held in the 365 days up to ``as_of`` (Rule 5.6)."""
    history = index_history(records_newest_first, pcc)
    if not history:
        return None
    end = _date(as_of) if as_of else max(_date(d) for d, _ in history)
    window = [
        idx
        for when, idx in history
        if idx is not None and 0 <= (end - _date(when)).days <= LOW_INDEX_WINDOW_DAYS
    ]
    return min(window) if window else None


# --------------------------------------------------------------------------- course handicap


def course_handicap(
    index: float | None, slope_rating: float, course_rating: float, par: int
) -> int:
    """Rule 6.1: Index x (Slope / 113) + (Course Rating - par), to a whole number.

    The Slope term converts the index to the difficulty of *this* course; the
    (Course Rating - par) term is what makes the result a target of par rather
    than of the rating, so net double bogey lines up with the scorecard.
    A player with no index yet plays off scratch.
    """
    if index is None:
        return 0
    return _round_int(index * (slope_rating / NEUTRAL_SLOPE) + (course_rating - par))


# --------------------------------------------------------------------------- rating estimation

# There is no rating team for a procedurally generated course, so we model the
# two ratings the WHS needs from the only things we know: par and yardage.
#
#   Course Rating  = the score a scratch player is expected to shoot.
#   Bogey Rating   = the score a bogey player (~20 index) is expected to shoot.
#   Slope Rating   = 5.381 x (Bogey Rating - Course Rating)     [18 holes]
#
# Both ratings are linear in yardage, and the bogey golfer's line is steeper --
# that is the whole reason slope exists.  A scratch player costs about 176
# yards per stroke, a bogey player about 128, and at neutral length the gap is
# 23.6 strokes (slope 127).  Calibrated against two real anchors: 6,500 yards
# par 72 -> 71.0 / 125, and 7,555 yards par 72 -> 77.0 / 137.

YARDS_PER_PAR_STROKE = 92.722  # a par-72 course of ~6,676 yards rates exactly 72.0
SCRATCH_YARDS_PER_STROKE = 176.0
BOGEY_YARDS_PER_STROKE = 128.0
BOGEY_GAP_AT_NEUTRAL = 23.6  # strokes, 18 holes
SLOPE_FACTOR = 5.381
SLOPE_MIN, SLOPE_MAX = 55.0, 155.0


def estimate_rating(par: int, yards: int, holes: int = 18) -> tuple[float, float]:
    """Estimate (Course Rating, Slope Rating) from par and length.

    Monotonically increasing in ``yards`` -- both ratings and therefore the
    slope, since the bogey line rises faster than the scratch line.  ``holes``
    scales the neutral bogey gap and the slope factor, because a 9-hole rating
    is on a 9-hole scale while a 9-hole Slope Rating is not: it is still quoted
    on the ordinary 55-155 range.
    """
    if holes not in (9, 18):
        raise ValueError("holes must be 9 or 18")

    neutral = par * YARDS_PER_PAR_STROKE
    excess = yards - neutral

    rating = par + excess / SCRATCH_YARDS_PER_STROKE
    bogey = par + excess / BOGEY_YARDS_PER_STROKE + BOGEY_GAP_AT_NEUTRAL * (holes / 18.0)

    slope = SLOPE_FACTOR * (bogey - rating) * (18.0 / holes)
    slope = max(SLOPE_MIN, min(SLOPE_MAX, slope))

    # Ratings are published to one decimal, slopes as whole numbers.
    return _round_half_up(rating, 1), float(_round_int(slope))


# --------------------------------------------------------------------------- self-test


def _selftest() -> None:
    def check(label: str, got, want) -> None:
        status = "ok  " if got == want else "FAIL"
        print(f"  {status} {label}: got {got!r}, want {want!r}")
        assert got == want, f"{label}: got {got!r}, want {want!r}"

    print("Score Differential (Rule 5.1)")
    # By hand: (113 / 128) x (85 - 71.2) = 0.8828125 x 13.8 = 12.1828... -> 12.2
    check("AGS 85, CR 71.2, slope 128", _raw_differential(85, 71.2, 128, 0.0), 12.2)
    # A round exactly on the rating differentials to 0.0 whatever the slope.
    check("AGS 71, CR 71.0, slope 140", _raw_differential(71, 71.0, 140, 0.0), 0.0)
    # PCC of 1 says the course played a stroke harder: (113/113) x (80-72-1) = 7.0
    check("PCC 1.0 subtracts a stroke", _raw_differential(80, 72.0, 113, 1.0), 7.0)
    # Half-up rounding: (113/113) x (85.25 - 73.0) would be 12.25 -> 12.3
    check("half-up at 12.25", _raw_differential(85, 72.75, 113, 0.0), 12.3)

    print("Fewer-than-20 table (Rule 5.2a)")
    check("2 scores -> no index", handicap_index([10.0, 12.0]), None)
    # 3 scores: lowest 1 (15.0) minus 2.0
    check("3 scores, lowest 1 - 2.0", handicap_index([20.0, 15.0, 18.0]), 13.0)
    # 4 scores: lowest 1 (15.0) minus 1.0
    check("4 scores, lowest 1 - 1.0", handicap_index([20.0, 15.0, 18.0, 22.0]), 14.0)
    # 5 scores: lowest 1, no adjustment
    check("5 scores, lowest 1", handicap_index([20.0, 15.0, 18.0, 22.0, 19.0]), 15.0)
    # 6 scores: average of lowest 2 (15.0, 18.0 = 16.5) minus 1.0
    check(
        "6 scores, avg lowest 2 - 1.0",
        handicap_index([20.0, 15.0, 18.0, 22.0, 19.0, 21.0]),
        15.5,
    )
    # 7 scores: average of lowest 2 (15.0, 18.0), no adjustment
    check(
        "7 scores, avg lowest 2",
        handicap_index([20.0, 15.0, 18.0, 22.0, 19.0, 21.0, 23.0]),
        16.5,
    )
    # 12 scores 1.0..12.0: average of lowest 4 = (1+2+3+4)/4 = 2.5
    check("12 scores, avg lowest 4", handicap_index([float(i) for i in range(1, 13)]), 2.5)
    # 20 scores 1.0..20.0: average of lowest 8 = (1..8)/8 = 4.5
    check("20 scores, avg lowest 8", handicap_index([float(i) for i in range(1, 21)]), 4.5)
    # 25 scores, newest first 1.0..25.0: only the first 20 are eligible, so the
    # low 8 are still 1..8 -- and 21..25 are ignored even though 21+ are worse.
    check("25 scores, only most recent 20", handicap_index([float(i) for i in range(1, 26)]), 4.5)
    # Same 25, newest first 25.0 down to 1.0: eligible are 25..6, low 8 = 6..13
    # -> (6+7+8+9+10+11+12+13)/8 = 9.5
    check(
        "25 scores, oldest excluded",
        handicap_index([float(i) for i in range(25, 0, -1)]),
        9.5,
    )

    print("Soft cap and hard cap (Rule 5.6)")
    # Raw 13.0 against Low 8.0: 8.0 + 3.0 + (2.0 x 0.5) = 12.0
    check("soft cap, low 8.0 raw 13.0", apply_caps(13.0, 8.0), 12.0)
    # Raw 20.0 against Low 8.0 would be 8+3+4.5 = 15.5, hard cap clamps to 13.0
    check("hard cap, low 8.0 raw 20.0", apply_caps(20.0, 8.0), 13.0)
    # Exactly 3.0 above is untouched -- the soft cap starts *beyond* 3.0
    check("no cap at exactly +3.0", apply_caps(11.0, 8.0), 11.0)
    check("no cap below the low index", apply_caps(5.0, 8.0), 5.0)
    check("no low index, no cap", apply_caps(30.0, None), 30.0)
    # Via handicap_index: 20 differentials all 13.0 average to 13.0, then cap.
    check("index applies the soft cap", handicap_index([13.0] * 20, 8.0), 12.0)

    print("Maximum Handicap Index (Rule 6.1)")
    check("54.0 ceiling", handicap_index([70.0] * 20), 54.0)
    check("54.0 ceiling with a low index", handicap_index([70.0] * 20, 60.0), 54.0)

    print("Net double bogey / Adjusted Gross Score (Rule 5.3)")
    # A 12 handicap on eighteen holes gets one stroke on every hole, so a par 4
    # caps at 4 + 2 + 1 = 7.  A 9 becomes a 7.
    pars = [4] * 18
    scores = [4] * 18
    scores[0] = 9
    check("12 handicap, 9 on a par 4 -> 7", adjusted_gross(scores, pars, 12), 4 * 17 + 7)
    check("net double bogey, par 4 with a stroke", net_double_bogey(4, 1), 7)
    check("net double bogey, par 4 with none", net_double_bogey(4, 0), 6)
    # The 12 handicap's strokes land on indexes 1..12, so hole 13 gets none and
    # caps at 4 + 2 = 6.
    strokes_got = handicap_strokes(12, default_stroke_index(18))
    check("12 handicap stroke allocation", (strokes_got[0], strokes_got[12]), (1, 0))
    scores13 = [4] * 18
    scores13[12] = 9
    check("no stroke on hole 13 -> caps at 6", adjusted_gross(scores13, pars, 12), 4 * 17 + 6)
    # A 20 handicap doubles up on indexes 1 and 2: par 4 + 2 + 2 = 8.
    check("20 handicap gets two on hole 1", handicap_strokes(20, default_stroke_index(18))[0], 2)
    check("20 handicap, 9 on hole 1 -> 8", adjusted_gross(scores, pars, 20), 4 * 17 + 8)
    # A plus handicap gives strokes back on the easiest holes (index 18 here).
    check(
        "+3 gives back on the easiest holes",
        handicap_strokes(-3, default_stroke_index(18))[17],
        -1,
    )
    # ...so the easiest hole caps at par + 2 - 1 = 5 for a +3.
    plus_scores = [4] * 18
    plus_scores[17] = 9
    check("+3 caps the easiest hole at 5", adjusted_gross(plus_scores, pars, -3), 4 * 17 + 5)
    # No established handicap: cap is par + 5, so a 9 on a par 4 stands at 9.
    check("unestablished, 9 on a par 4 stays 9", adjusted_gross([9], [4], None), 9)
    check("unestablished, 11 on a par 4 -> 9", adjusted_gross([11], [4], None), 9)
    check("under par is never adjusted up", adjusted_gross([3, 2], [4, 3], 12), 5)

    print("Course Handicap (Rule 6.1)")
    # 12.0 x (128/113) + (71.2 - 72) = 13.591 - 0.8 = 12.79 -> 13
    check("12.0 index, slope 128, CR 71.2, par 72", course_handicap(12.0, 128, 71.2, 72), 13)
    # A scratch player on a course rated over par still gets shots: 0 + 5.0 -> 5
    check("scratch on a 77.0/par 72 course", course_handicap(0.0, 137, 77.0, 72), 5)
    check("no index plays off scratch", course_handicap(None, 128, 71.2, 72), 0)
    # Half-up: 10.0 x (113/113) + 0.5 = 10.5 -> 11
    check("half-up to a whole number", course_handicap(10.0, 113, 72.5, 72), 11)

    print("Nine-hole scores (Rule 5.1a)")
    # 9 holes, AGS 43, 9-hole CR 35.6, slope 128: (113/128) x 7.4 = 6.53 -> 6.5
    check("9-hole differential", nine_hole_differential(43, 35.6, 128), 6.5)
    check("doubled to 18", expand_nine_hole_differential(6.5), 13.0)
    check("two nines combined", combine_nine_hole_differentials(6.5, 8.1), 14.6)
    nine = RoundRecord(43, 36, 9, 35.6, 128, "2026-07-01")
    check("score_differential doubles a nine", score_differential(nine), 13.0)

    print("Rating estimation")
    # The two calibration anchors.
    check("6,500 yd par 72", estimate_rating(72, 6500), (71.0, 125.0))
    check("7,555 yd par 72", estimate_rating(72, 7555), (77.0, 137.0))
    # Monotonic in yardage, for both rating and slope.
    prev = (-1.0, -1.0)
    for y in range(4500, 8200, 25):
        cur = estimate_rating(72, y)
        assert cur[0] >= prev[0] and cur[1] >= prev[1], f"not monotonic at {y}: {prev} -> {cur}"
        prev = cur
    strictly_up = estimate_rating(72, 8000) > estimate_rating(72, 6000)
    check("strictly increasing overall", strictly_up, True)
    # A nine rates about half an eighteen of twice the length.
    r18, s18 = estimate_rating(72, 7000)
    r9, s9 = estimate_rating(36, 3500, holes=9)
    check("9-hole rating is half the 18", _round_half_up(r9 * 2, 1), r18)
    check("9-hole slope is on the same scale", s9, s18)
    print(f"       6,000 yd par 72 -> {estimate_rating(72, 6000)}")
    print(f"       6,676 yd par 72 -> {estimate_rating(72, 6676)}")
    print(f"       7,000 yd par 70 -> {estimate_rating(70, 7000)}")

    print("End-to-end history")
    # Twenty-five identical 90s at a 72.0/130 course, one a week apart.  The
    # differential is (113/130) x 18 = 15.646 -> 15.6, so the index settles at
    # 15.6 and the caps never bite because nothing ever gets worse.
    start = _dt.date(2026, 1, 1)
    recs = [
        RoundRecord(90, 72, 18, 72.0, 130, (start + _dt.timedelta(weeks=i)).isoformat())
        for i in range(24, -1, -1)  # newest first
    ]
    check("steady 90s differential", score_differential(recs[0]), 15.6)
    check("steady 90s index", current_index(recs), 15.6)
    # The Low Handicap Index is 13.6, not 15.6, and that is correct: with only
    # 3 scores the table subtracted 2.0, so 13.6 is an index the player really
    # did hold inside the 365-day window.  Worth knowing, because it makes a new
    # player's cap tighter than they might expect.
    check("low index includes early table-adjusted values", low_handicap_index(recs), 13.6)
    early = dict(index_history(recs))
    check("index after 3 scores was 13.6", early[recs[-3].date], 13.6)
    check("index after 4 scores was 14.6", early[recs[-4].date], 14.6)
    # Now bury the recent scores: twenty 110s after those 90s.  The 90s fall out
    # of the most recent 20, the raw index jumps, and the caps hold it down.
    blowups = [
        RoundRecord(
            110, 72, 18, 72.0, 130, (start + _dt.timedelta(weeks=25 + i)).isoformat()
        )
        for i in range(20)
    ]
    combined = list(reversed(blowups)) + recs
    raw = handicap_index([score_differential(r) for r in combined[:20]])
    capped = current_index(combined)
    print(f"       raw index after 20 blowups {raw}, capped {capped}")
    # (113/130) x (110 - 72) = 33.0 raw; hard cap pins it at 13.6 + 5.0.
    check("blowup differential", score_differential(blowups[0]), 33.0)
    check("hard cap holds the collapse", capped, 18.6)
    assert raw is not None and capped is not None and raw > capped

    print("\nAll handicap self-tests passed.")


if __name__ == "__main__":
    _selftest()


# --------------------------------------------------------------------------- store adapter


def _record_from_row(row: dict) -> tuple[RoundRecord, dict] | None:
    """Turn one stored leaderboard row into a WHS record, or drop it.

    Match play is excluded: holes get conceded, so there is no gross score the
    Rules of Golf would accept.  Rows written before the store carried yardage
    fall back to a middling length rather than being thrown away.

    Nothing in here may raise.  A leaderboard file is data that is already on
    somebody's disk, written by whatever version of the game they were running,
    and this function is reached from the *menu screen* -- so a row the current
    code would never write still has to be readable.  One such row exists in the
    wild: a match conceded on the 14th, filed under a stroke-play format, whose
    fourteen hole scores do not line up with its eighteen pars.
    """
    if "match" in str(row.get("format", "")).lower():
        return None
    holes = int(row.get("holes") or (9 if "9" in str(row.get("round", "")) else 18))
    yards = int(row.get("yards") or (3250 if holes == 9 else 6500))
    par = int(row.get("par") or (36 if holes == 9 else 72))
    cr, slope = estimate_rating(par, yards, holes)
    scores = row.get("hole_scores") or None
    pars = row.get("pars") or None
    gross = int(row.get("strokes", 0))
    if scores and pars and len(scores) != len(pars):
        # Twelve hole scores against eighteen pars is a round that stopped early,
        # and its total is a twelve-hole total. Keeping it and falling back to
        # that total reads 48 as an eighteen-hole score against par 72, which
        # handed one of these files a Handicap Index of -12.1. There is no gross
        # score here the Rules would accept, so the row goes the same way a
        # conceded match does.
        return None
    ags = adjusted_gross(scores, pars, None) if scores and pars else gross
    rec = RoundRecord(ags, par, holes, cr, slope, row.get("date", ""), scores, pars)
    return rec, {
        "course": row.get("course", "?"),
        "round": row.get("round", "?"),
        "tee": row.get("tee", ""),
        "strokes": gross,
        "ags": ags,
        "cr": cr,
        "slope": slope,
    }


def index_for(rows: Sequence[dict]) -> float | None:
    """Handicap Index straight from stored leaderboard rows."""
    pairs = [p for p in (_record_from_row(r) for r in rows) if p]
    return current_index([rec for rec, _ in pairs])


def summary(rows: Sequence[dict]) -> dict:
    """Everything the leaderboard's handicap page needs, in one pass."""
    pairs = [p for p in (_record_from_row(r) for r in rows) if p]
    records = [rec for rec, _ in pairs]
    out = [dict(meta) for _, meta in pairs]
    for rec, meta in zip(records, out):
        meta["diff"] = score_differential(rec)
        meta["counted"] = False

    considered = out[:20]  # WHS looks at the most recent 20 scores
    sel = selection(len(considered))
    used = sel[0] if sel else 0
    for i in sorted(range(len(considered)), key=lambda i: considered[i]["diff"])[:used]:
        considered[i]["counted"] = True

    return {
        "index": current_index(records),
        "low_index": low_handicap_index(records),
        "used": used,
        "considered": len(considered),
        "rows": out,
    }


def format_index(index: float | None) -> str:
    """Display form. Better than scratch is written "+2.4", not "-2.4"."""
    if index is None:
        return "--"
    return f"+{-index:.1f}" if index < 0 else f"{index:.1f}"
