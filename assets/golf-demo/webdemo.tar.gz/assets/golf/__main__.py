from golf.game import main

main()
