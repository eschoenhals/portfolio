"""A CPU that plays a real ball.

The whole design is one restriction: **a CPU may only produce the things a
person at the keyboard produces.**  For a full swing that is a club, an aim, a
strike point, a power and an accuracy-meter miss, handed to ``Game.fire``.  For
a putt it is an aim and a power, handed to ``Game.strike_putt``.  It never
assigns a ball position, never inspects a result, never decides it holed one.

That is worth the small amount of extra work it costs, for two reasons.  It is
impossible for the opponent to cheat, so a match it wins it actually won.  And
every future change to the physics -- a new club, a different roll model, wind
that behaves differently -- applies to the CPU for free, because it is playing
the same game through the same door.

Difficulty splits in two.  ``err`` is execution: the sigma of the miss it hands
``fire``, which on a driver is worth about 120 yards of bend per unit and is by
far the dominant term.  ``nerve`` is judgement: how much of the wind it allows
for, how hard it looks for trouble before taking a line on, and how finely it
reads a putt.  Keeping them apart is what makes a weak opponent interesting --
an Amateur loses because it took on a carry it could not make, not merely
because its hands shook.
"""

from __future__ import annotations

import random

from .clubs import BAG, PUTTER_INDEX, Club
from .course import dist, terrain_at
from .physics import dir_from_deg, expected_carry, max_putt_speed, simulate_putt
from .tour import Level

#: What each terrain is worth in "extra yards to the hole" when the CPU is
#: choosing between two shots.  Water is enormous because it is a stroke plus a
#: drop; trees are nearly as bad because the escape is sideways.  These are
#: preferences, not physics -- nothing here changes what the ball does.
LIE_COST = {
    "water": 75.0,
    "trees": 45.0,
    "deep": 22.0,
    "sand": 14.0,
    "rough": 7.0,
    "fringe": 0.0,
    "fairway": 0.0,
    "green": -3.0,  # a shot that finds the green is worth going out of your way for
    "tee": 0.0,
}

#: Aim offsets, in degrees, the CPU will consider bailing out by.
BAILOUTS = (0.0, -4.0, 4.0, -9.0, 9.0, -15.0, 15.0)


def think_time(state: str) -> float:
    """How long the opponent takes over it, so the shot is watchable."""
    return {"intro": 0.7, "aim": 0.95, "putt_aim": 1.15, "hole_done": 1.5}.get(state, 0.8)


# ------------------------------------------------------------------ full swings


def _run_out(club: Club, roll_mult: float, lie: str) -> float:
    """Fraction of the carry the ball is expected to run on, as a multiplier."""
    return 1.0 + club.roll * roll_mult * (0.6 if lie in ("rough", "sand", "deep") else 1.0)


def _land(start, aim_deg: float, reach: float):
    d = dir_from_deg(aim_deg)
    return (start[0] + d[0] * reach, start[1] + d[1] * reach)


def _spot(game, start, aim_deg: float, carry: float, run: float) -> tuple:
    """Where the ball finishes, and the worse of the two lies it touches.

    A ball that pitches into a creek is wet even if it would have run up onto
    the green from there, so the landing point has to be judged as well as the
    resting one.  Judging only the rest is what let the CPU club down into the
    water fronting a green and call it a good shot.
    """
    land = _land(start, aim_deg, carry)
    end = _land(start, aim_deg, carry * run)
    a, b = terrain_at(game.hole, land), terrain_at(game.hole, end)
    lie = a if LIE_COST.get(a, 0.0) > LIE_COST.get(b, 0.0) else b
    return end, lie


def _cost(game, start, aim_deg: float, carry: float, run: float,
          spread: float, short: float) -> float:
    """How bad this shot looks, in yards-to-the-hole plus trouble.

    The shot is judged as a cross of five outcomes -- the pure one, a miss each
    side, and one each of heavy and thin -- so a line that only works when struck
    perfectly is priced as such.  The long axis matters as much as the wide one:
    every forced carry in the game is a hazard you come up *short* into, and a
    CPU that only imagined sideways misses flew a 5-iron at Rae's Creek all day.
    """
    hole = game.hole
    total = 0.0
    for off, dc, w in ((0.0, 1.0, 1.0), (-spread, 1.0, 0.5), (spread, 1.0, 0.5),
                       (0.0, 1.0 - short, 0.5), (0.0, 1.0 + short, 0.5)):
        end, lie = _spot(game, start, aim_deg + off, carry * dc, run)
        total += w * (dist(end, hole.pin) + LIE_COST.get(lie, 0.0))
    return total / 3.0


def pick_shot(game, rng: random.Random) -> tuple[int, float, float, float]:
    """(club_index, aim_deg, power, err) for the CPU's next full swing.

    Every candidate is a club and a line; the one with the cheapest expected
    outcome wins.  Because the cost function already prices water and timber,
    laying up falls out of it rather than being a special case -- on a par 5
    with a pond short of the green the 5-iron simply scores better than the
    3-wood, which is the decision a person makes for the same reason.
    """
    p = game.p
    level: Level = p.cpu
    hole = game.hole
    to_pin = dist(p.ball, hole.pin)
    base = game.bearing_to(hole.pin, p)

    # Wind is read in proportion to nerve. The term is the one simulate_shot
    # itself uses, so a full-nerve opponent clubs up into a breeze by exactly
    # the yards the breeze is going to take off it.
    wind = game.wind

    best = None
    for ci, club in enumerate(BAG):
        if club.putter:
            continue
        stock = expected_carry(club, p.lie, p.arch)
        if stock <= 0.0:
            continue
        d = dir_from_deg(base)
        head = (wind[0] * d[0] + wind[1] * d[1]) * (club.apex / 26.0) * 0.9
        carry = stock + head * level.nerve
        run = _run_out(club, game.spec.roll_mult, p.lie)

        # Full send, or throttled back to sit the ball at the pin. The cap keeps
        # the meter under 100%: crossing the line is a cliff that buys a big
        # miss, and a CPU has no reason to gamble on it.
        ceiling = 1.0 - 1.2 * level.power_err
        want = max(0.25, min(ceiling, (to_pin / run) / max(1.0, carry)))
        for power in (ceiling, want) if want < ceiling else (ceiling,):
            flown = carry * power
            spread = level.err * club.curve * (flown / 100.0) * 1.6
            # How far a heavy or thin one travels: the power it failed to find,
            # the distance a mishit costs, and the ordinary strike-to-strike
            # scatter the engine puts on every ball.
            short = level.power_err + 0.55 * level.err + 0.02
            lines = BAILOUTS if level.nerve > 0.35 else BAILOUTS[:3]
            for off in lines:
                c = _cost(game, p.ball, base + off, flown, run, spread, short)
                # A bail-out is only worth taking if it is genuinely better;
                # without this the CPU aims 15 degrees off every shot to shave a
                # yard of imagined risk.
                c += abs(off) * 0.35
                if best is None or c < best[0]:
                    best = (c, ci, base + off, power)

    if best is None:  # nothing in the bag applies -- take the shortest club straight
        return PUTTER_INDEX - 1, base, 0.5, 0.0

    _, ci, aim, power = best
    # A poor read still swings at the shot it thinks it is playing, so the
    # judgement error lands on the aim rather than on the strike.
    aim += rng.gauss(0.0, (1.0 - level.nerve) * 2.2)
    power = max(0.2, min(1.0, power * rng.gauss(1.0, level.power_err)))
    return ci, aim, power, rng.gauss(0.0, level.err)


# ------------------------------------------------------------------ putting


def pick_putt(game, rng: random.Random) -> tuple[float, float]:
    """(aim_deg, power) for the CPU's next putt.

    The read is done with the *noiseless* ``simulate_putt`` -- the same call the
    player's own preview line makes -- over a fan of aims and paces, keeping
    whichever finishes nearest the cup.  Rolling the real surface rather than
    reasoning about it is why this reads a crowned Pinehurst green correctly
    without knowing what a crown is.

    ``nerve`` sets how fine the fan is, so a weak opponent misreads the break
    and then executes that misread. Its stroke error is separate and lives in
    the archetype the level plays (see :func:`golf.tour.archetype_for`), which
    is what ``strike_putt`` already scales by.
    """
    p = game.p
    level: Level = p.cpu
    hole = game.hole
    friction = game.spec.green_friction
    to_pin = dist(p.ball, hole.pin)
    base = game.bearing_to(hole.pin, p)

    # Flat-ground power for the distance, as the centre of the search.
    flat = min(1.0, (2.0 * friction * to_pin) ** 0.5 / max(0.01, max_putt_speed(friction)))

    steps = 4 if level.nerve > 0.75 else 3 if level.nerve > 0.4 else 2
    fan = max(1.5, 9.0 * to_pin / 12.0)  # longer putts break more, so look wider
    aims = [base + fan * i / steps for i in range(-steps, steps + 1)]
    paces = [max(0.05, flat * m) for m in (0.85, 0.95, 1.02, 1.10, 1.22)]

    best = None
    for aim in aims:
        for power in paces:
            res = simulate_putt(hole, friction, p.ball, aim, power)
            if res.holed:
                # Among putts that go in, the softest one is the best one: pace
                # is what decides how forgiving the real stroke will be.
                cost = -1000.0 + power * 10.0
            else:
                cost = dist(res.end, hole.pin)
            if best is None or cost < best[0]:
                best = (cost, aim, power)

    _, aim, power = best
    aim += rng.gauss(0.0, (1.0 - level.nerve) * 1.6)
    power = max(0.05, min(1.0, power * rng.gauss(1.0, (1.0 - level.nerve) * 0.06)))
    return aim, power


# ------------------------------------------------------------------ commentary


def shot_note(game) -> str:
    """One line for the HUD while the opponent is over the ball."""
    p = game.p
    d = dist(p.ball, game.hole.pin)
    if p.lie in ("green", "fringe"):
        return f"{p.name.upper()} — {d * 3.0:.0f} ft for {_putt_for(game)}"
    return f"{p.name.upper()} — {d:.0f}y, {BAG[p.club_index].name}"


def _putt_for(game) -> str:
    n = game.p.strokes + 1 - game.hole.par
    return {-2: "eagle", -1: "birdie", 0: "par", 1: "bogey"}.get(n, f"{n:+d}")


def lie_word(lie: str) -> str:
    return {"deep": "the deep stuff", "trees": "the trees", "sand": "a bunker",
            "rough": "the rough", "fairway": "the fairway", "tee": "the tee",
            "green": "the green", "fringe": "the fringe"}.get(lie, lie)
