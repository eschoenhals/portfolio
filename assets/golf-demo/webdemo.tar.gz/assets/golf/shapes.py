"""Irregular hazard outlines: bunkers and lakes that are not circles.

Real sand and water have lobed, wandering edges.  A circle reads as a target,
and a chain of overlapping circles reads as a caterpillar, so both need to
become a single organic outline.

The approach is a *star-shaped polygon*: pick a centre, then define the radius
as a function of the angle and walk that function all the way round.  The
radius is a base value times a handful of summed low-frequency harmonics
(cos(2t), cos(3t), ...) with random phases, which is why the edges come out
lobed and smooth rather than spiky -- per-vertex noise would look like a saw
blade at the zoom levels this game draws at.  Keeping the radius strictly
positive is what guarantees the outline never crosses itself, which matters
because a self-intersecting polygon makes the point-in-polygon test lie about
which side of the edge you are on.

Chains of circles (a creek walked across a hole) are merged the same way: fire
rays out from the cluster's centroid and take the *farthest* hit on any circle.
That is the union's silhouette as seen from the middle, so the scalloped waists
between circles disappear and one winding shape remains.  It is only correct
while the union really is star-shaped from that centroid -- see
:func:`make_hazard_blobs` for how a U-bend or a very long chain is handled
instead of being faked badly.

Pure geometry: stdlib only, no pygame, so it can be tested headlessly.
Everything is in world yards, and outlines are counter-clockwise with no
repeated closing point.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

Vec = tuple[float, float]
Circle = tuple[Vec, float]

# Radius variation is capped well below 1.0 so the radius can never reach zero:
# that is the invariant that keeps a star-shaped outline simple (non-self-
# intersecting), and every caller depends on it.
MAX_WOBBLE = 0.42

DEFAULT_SAMPLES = 48  # vertices per outline -- smooth at any zoom the game uses


# --------------------------------------------------------------------------- blob


@dataclass
class Blob:
    """A closed hazard outline plus the caches that make hit-testing cheap.

    ``contains`` is called from ``terrain_at``, i.e. thousands of times per
    simulated shot and again for every frame's cursor, so the polygon is
    pre-chewed once here: a bounding box for the early-out and a set of
    horizontal bands, each holding only the edges that can possibly cross a
    probe at that height.  A 48-vertex blob then costs a couple of edge tests
    per call instead of 48 (see the benchmark in ``__main__``).

    ``bounds`` is derived from ``points``; pass it or don't, it is recomputed.
    """

    points: list[Vec]
    center: Vec
    radius: float  # nominal (mean) radius -- camera framing and fallbacks
    bounds: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)

    # Caches. Never set by callers.
    _edges: tuple[tuple[float, float, float, float, float, float, float], ...] = field(
        default=(), init=False, repr=False, compare=False
    )
    _bands: tuple[tuple[tuple[float, float, float, float], ...], ...] = field(
        default=(), init=False, repr=False, compare=False
    )
    _band_scale: float = field(default=0.0, init=False, repr=False, compare=False)
    _band_last: int = field(default=0, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        pts = self.points
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        self.bounds = (min(xs), min(ys), max(xs), max(ys))

        # Edge table for distance queries: endpoints, delta, squared length.
        n = len(pts)
        edges = []
        for i in range(n):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % n]
            dx, dy = bx - ax, by - ay
            edges.append((ax, ay, bx, by, dx, dy, dx * dx + dy * dy))
        self._edges = tuple(edges)

        # Horizontal bands for the crossing test.  Purely horizontal edges are
        # dropped: the crossing rule never counts them, and dropping them lets
        # us pre-divide by dy.
        miny, maxy = self.bounds[1], self.bounds[3]
        height = maxy - miny
        nbands = max(1, min(64, n // 2))
        scale = nbands / height if height > 1e-9 else 0.0
        buckets: list[list[tuple[float, float, float, float]]] = [[] for _ in range(nbands)]
        for i in range(n):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % n]
            if ay == by:
                continue
            edge = (ay, by, ax, (bx - ax) / (by - ay))
            lo, hi = (ay, by) if ay < by else (by, ay)
            k0 = min(nbands - 1, max(0, int((lo - miny) * scale)))
            k1 = min(nbands - 1, max(0, int((hi - miny) * scale)))
            for k in range(k0, k1 + 1):
                buckets[k].append(edge)
        self._bands = tuple(tuple(b) for b in buckets)
        self._band_scale = scale
        self._band_last = nbands - 1

    # -- queries

    def contains(self, p: Vec) -> bool:
        """Standard ray-crossing test, restricted to the edges near ``p``."""
        x = p[0]
        y = p[1]
        minx, miny, maxx, maxy = self.bounds
        if x < minx or x > maxx or y < miny or y > maxy:
            return False
        k = int((y - miny) * self._band_scale)
        if k > self._band_last:
            k = self._band_last
        inside = False
        for ay, by, ax, slope in self._bands[k]:
            if (ay > y) != (by > y) and x < ax + (y - ay) * slope:
                inside = not inside
        return inside

    def distance_to(self, p: Vec) -> float:
        """Signed distance to the outline: >= 0 outside, < 0 inside.

        Callers use the magnitude to ask "how far into the sand am I", so this
        is distance to the *edge*, not to the centre.
        """
        px = p[0]
        py = p[1]
        best = float("inf")
        for ax, ay, _bx, _by, dx, dy, len2 in self._edges:
            if len2 < 1e-12:
                d = math.hypot(px - ax, py - ay)
            else:
                t = ((px - ax) * dx + (py - ay) * dy) / len2
                if t < 0.0:
                    t = 0.0
                elif t > 1.0:
                    t = 1.0
                d = math.hypot(px - ax - t * dx, py - ay - t * dy)
            if d < best:
                best = d
        return -best if self.contains(p) else best


# --------------------------------------------------------------------------- harmonics


def _harmonics(rng: random.Random, lobes: int, roughness: float) -> list[tuple[int, float, float]]:
    """Pick (frequency, amplitude, phase) triples for the radius wobble.

    Low frequencies only, with amplitude falling off as the frequency rises, so
    the result is a few broad lobes with a little finer detail on top instead of
    uniform crinkle.  The total is normalised to ``roughness`` and clamped, so
    the radius stays positive whatever a caller asks for.
    """
    lobes = max(1, min(5, lobes))
    freqs = list(range(2, 2 + lobes))
    amps = [rng.uniform(0.55, 1.0) / (k - 1) for k in freqs]
    total = sum(amps) or 1.0
    scale = min(roughness, MAX_WOBBLE) / total
    return [(k, a * scale, rng.uniform(0.0, math.tau)) for k, a in zip(freqs, amps)]


def _wobble(harmonics: list[tuple[int, float, float]], t: float) -> float:
    """Radius multiplier at angle ``t``; mean 1.0 over a full turn."""
    w = 1.0
    for k, amp, phase in harmonics:
        w += amp * math.cos(k * t + phase)
    return w


def _finish(points: list[Vec], center: Vec) -> Blob:
    n = len(points)
    mean_r = sum(math.hypot(x - center[0], y - center[1]) for x, y in points) / n
    return Blob(points=points, center=center, radius=mean_r)


# --------------------------------------------------------------------------- builders


def make_blob(
    center: Vec,
    radius: float,
    seed: int,
    *,
    lobes: int = 3,
    roughness: float = 0.22,
    squash: float = 1.0,
    angle: float = 0.0,
    samples: int = DEFAULT_SAMPLES,
) -> Blob:
    """One irregular closed shape of roughly ``radius`` yards, from ``seed``.

    ``squash`` elongates the blob along the axis given by ``angle`` (radians);
    the stretch is area-preserving (sqrt in, sqrt out) so ``radius`` keeps
    meaning roughly what it meant for the circle it replaces.  Deterministic:
    the same seed always yields the same points.
    """
    rng = random.Random(seed)
    harmonics = _harmonics(rng, lobes, roughness)
    spin = rng.uniform(0.0, math.tau)  # so blobs of equal shape don't line up

    sx = math.sqrt(max(0.05, squash))
    sy = 1.0 / sx
    ca, sa = math.cos(angle), math.sin(angle)

    cx, cy = center
    pts: list[Vec] = []
    for i in range(samples):
        t = i / samples * math.tau  # increasing angle => counter-clockwise
        r = radius * _wobble(harmonics, t + spin)
        ux, uy = math.cos(t) * r * sx, math.sin(t) * r * sy
        pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return _finish(pts, center)


def _ray_hit(origin: Vec, dx: float, dy: float, circles: list[Circle]) -> float:
    """Farthest distance along a unit ray at which it leaves the union."""
    ox, oy = origin
    best = 0.0
    for (cx, cy), r in circles:
        mx, my = cx - ox, cy - oy
        along = mx * dx + my * dy
        perp2 = mx * mx + my * my - along * along
        gap = r * r - perp2
        if gap <= 0.0:
            continue
        t = along + math.sqrt(gap)
        if t > best:
            best = t
    return best


def _rounded_union(p: Vec, circles: list[Circle], k: float) -> float:
    """Distance to the circles' union with the waists between them filled in.

    A hard union keeps every circle's own arc, which is exactly the caterpillar
    look we are trying to lose: neighbours meet in a visible notch.  The
    polynomial smooth-min from raymarching rounds those junctions off over a
    blend width ``k``, so a chain reads as one channel of water.  It is an
    approximation and order-dependent, hence deterministic only because the
    circle list order is fixed by the caller.
    """
    px, py = p
    d = float("inf")
    quarter = 0.25 / k
    for (cx, cy), r in circles:
        di = math.hypot(px - cx, py - cy) - r
        h = k - abs(d - di)
        d = di if di < d else d
        if h > 0.0:
            d -= h * h * quarter
    return d


def _rounded_radius(origin: Vec, dx: float, dy: float, circles: list[Circle],
                    k: float, hard: float) -> float:
    """Distance from ``origin`` to the rounded union's edge along a unit ray.

    Walks inward from a point known to be outside so we land on the *outermost*
    crossing -- the silhouette -- then bisects.  Build-time only, so a couple of
    dozen evaluations per ray is free.
    """
    hi = hard + k
    step = hi / 14.0
    t = hi
    while t > 0.0 and _rounded_union((origin[0] + dx * t, origin[1] + dy * t), circles, k) > 0.0:
        t -= step
    if t <= 0.0:
        return 0.0  # origin itself is dry: caller substitutes a fallback
    lo, hi = t, t + step
    for _ in range(14):
        mid = (lo + hi) * 0.5
        if _rounded_union((origin[0] + dx * mid, origin[1] + dy * mid), circles, k) > 0.0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) * 0.5


def _centroid(circles: list[Circle]) -> Vec:
    """Area-weighted centroid -- big pools pull the viewpoint towards them."""
    wsum = 0.0
    x = y = 0.0
    for (cx, cy), r in circles:
        w = r * r
        wsum += w
        x += cx * w
        y += cy * w
    if wsum <= 0.0:
        return circles[0][0]
    return (x / wsum, y / wsum)


def _star_safe(circles: list[Circle]) -> bool:
    """Can this cluster be drawn as one star-shaped outline from its centroid?

    Two ways it cannot.  The centroid may sit on dry land (a wide U-bend), or a
    circle may be hidden behind a bend, in which case the ray towards it stops
    short and the outline would slice through water it should contain.  Both are
    caught by walking the centroid-to-centre segment and requiring it to stay
    wet, then checking the ray reaches past the far side of that circle.
    """
    o = _centroid(circles)
    ox, oy = o
    if not any((ox - c[0]) ** 2 + (oy - c[1]) ** 2 < r * r for c, r in circles):
        return False
    for (cx, cy), r in circles:
        mx, my = cx - ox, cy - oy
        d = math.hypot(mx, my)
        if d < 1e-9:
            continue
        dx, dy = mx / d, my / d
        # The silhouette in this direction must clear the far edge of the circle.
        if _ray_hit(o, dx, dy, circles) < d + r * 0.9:
            return False
        # ...and the line of sight must not leave the water on the way.
        for j in range(1, 8):
            f = j / 8.0 * d
            px, py = ox + dx * f, oy + dy * f
            if not any((px - c[0]) ** 2 + (py - c[1]) ** 2 < r2 * r2 for c, r2 in circles):
                return False
    return True


def make_merged_blob(circles: list[Circle], seed: int, *, roughness: float = 0.16) -> Blob:
    """Merge overlapping circles into ONE irregular outline.

    Rays from the centroid find the outermost edge of a *rounded* union, so the
    notches where neighbours meet are filled and a stacked-circle creek becomes
    one winding channel.  Harmonics then break up the remaining smooth arcs.

    This is best-effort: for a cluster that is not star-shaped from its centroid
    (a U-bend) the outline will bridge across the opening rather than follow it.
    The result is still a simple polygon -- it never self-intersects -- but it
    claims dry land.  Use :func:`make_hazard_blobs` if you want that case split
    up instead.  A single circle degenerates to :func:`make_blob`.
    """
    if not circles:
        raise ValueError("make_merged_blob needs at least one circle")
    if len(circles) == 1:
        (c, r) = circles[0]
        return make_blob(c, r, seed, roughness=max(roughness, 0.18))

    o = _centroid(circles)
    span = max(
        max(abs(c[0] - o[0]) + r, abs(c[1] - o[1]) + r) for c, r in circles
    )
    mean_r = sum(r for _, r in circles) / len(circles)
    # Long chains need more rays or the end caps come out faceted.
    rays = max(DEFAULT_SAMPLES, min(160, int(round(40 * math.sqrt(span / max(1e-6, mean_r))))))

    rng = random.Random(seed)
    harmonics = _harmonics(rng, 4, roughness)
    spin = rng.uniform(0.0, math.tau)
    blend = mean_r * 0.6  # wide enough to swallow the waist between neighbours

    pts: list[Vec] = []
    for i in range(rays):
        t = i / rays * math.tau
        dx, dy = math.cos(t), math.sin(t)
        hard = _ray_hit(o, dx, dy, circles)
        hit = _rounded_radius(o, dx, dy, circles, blend, hard)
        if hit <= 0.0:
            # Centroid outside the union in this direction; keep the outline
            # simple by falling back to something small and positive.
            hit = mean_r * 0.25
        r = hit * _wobble(harmonics, t + spin)
        pts.append((o[0] + dx * r, o[1] + dy * r))
    return _finish(pts, o)


def make_hazard_blobs(
    circles: list[Circle], seed: int, *, roughness: float = 0.16
) -> list[Blob]:
    """The safe entry point: one blob when it works, a few when it cannot.

    Merging is attempted on the whole cluster; if that would misrepresent the
    shape (see :func:`_star_safe`) the chain is split into the longest runs of
    consecutive circles that *are* star-safe and each run is merged on its own.
    Worst case that is one blob per circle -- lumpy, but every blob is a simple
    polygon and the union still covers exactly the water it should.  Draw and
    hit-test them as a set; because consecutive runs share a circle they overlap,
    so a filled render still reads as one continuous hazard (stroke the fills
    together, not blob by blob, or the seams show).

    Circle order matters: pass them along the creek, which is how ``course.py``
    already emits them.
    """
    if not circles:
        return []
    if _star_safe(circles):
        return [make_merged_blob(circles, seed, roughness=roughness)]

    groups: list[list[Circle]] = []
    i = 0
    n = len(circles)
    while i < n:
        run = [circles[i]]
        j = i + 1
        while j < n and _star_safe(run + [circles[j]]):
            run.append(circles[j])
            j += 1
        groups.append(run)
        # Overlap runs by one circle so the pieces stay visually joined.
        i = j - 1 if len(run) > 1 else j
    return [make_merged_blob(g, seed * 7919 + k, roughness=roughness) for k, g in enumerate(groups)]


# --------------------------------------------------------------------------- self-test


def _segments_cross(a: Vec, b: Vec, c: Vec, d: Vec) -> bool:
    def side(p: Vec, q: Vec, r: Vec) -> float:
        return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])

    d1, d2 = side(a, b, c), side(a, b, d)
    d3, d4 = side(c, d, a), side(c, d, b)
    return ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0))


def _self_intersects(blob: Blob) -> bool:
    pts = blob.points
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue  # adjacent through the wrap
            if _segments_cross(a, b, pts[j], pts[(j + 1) % n]):
                return True
    return False


def _signed_area(blob: Blob) -> float:
    pts = blob.points
    n = len(pts)
    return 0.5 * sum(
        pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n)
    )


def _demo_png(path: str = "/tmp/blobs.png") -> None:
    """Eyeball proof.  pygame is imported here only -- the module stays pure."""
    import pygame  # noqa: PLC0415

    pygame.init()
    W, H = 1100, 720
    surf = pygame.Surface((W, H))
    surf.fill((28, 96, 44))
    scale = 1.6

    def draw(blob: Blob, fill: tuple[int, int, int], ox: float, oy: float) -> None:
        pts = [(ox + x * scale, oy - y * scale) for x, y in blob.points]
        pygame.draw.polygon(surf, fill, pts)
        pygame.draw.polygon(surf, (240, 240, 230), pts, 1)

    sand = (226, 208, 160)
    water = (44, 96, 168)
    for i in range(12):
        col, row = i % 4, i // 4
        ox, oy = 90 + col * 165, 120 + row * 150
        blob = make_blob(
            (0.0, 0.0),
            16.0 + (i % 3) * 6.0,
            seed=100 + i,
            lobes=2 + i % 4,
            roughness=0.14 + 0.05 * (i % 4),
            squash=1.0 + 0.45 * (i % 3),
            angle=i * 0.5,
        )
        draw(blob, sand, ox, oy)

    creek = [((float(k) * 26.0, math.sin(k * 0.7) * 14.0), 20.0) for k in range(6)]
    for blob in make_hazard_blobs(creek, seed=7):
        draw(blob, water, 120, 640)

    pygame.image.save(surf, path)
    pygame.quit()
    print(f"wrote {path}")


if __name__ == "__main__":
    import time

    rng = random.Random(4)

    # -- 200 blobs: simple outlines, centre inside, CCW winding
    for i in range(200):
        b = make_blob(
            (rng.uniform(-300, 300), rng.uniform(-300, 300)),
            rng.uniform(4.0, 40.0),
            seed=i,
            lobes=rng.randint(1, 5),
            roughness=rng.uniform(0.05, 0.45),
            squash=rng.uniform(0.5, 2.2),
            angle=rng.uniform(0, math.tau),
        )
        assert not _self_intersects(b), f"blob {i} self-intersects"
        assert b.contains(b.center), f"blob {i} excludes its centre"
        assert _signed_area(b) > 0, f"blob {i} is clockwise"
        assert b.radius > 0
    print("200 blobs: simple, centred, counter-clockwise")

    # -- determinism
    for s in (1, 42, 9999):
        a = make_blob((10.0, 20.0), 18.0, s, squash=1.4, angle=0.3)
        c = make_blob((10.0, 20.0), 18.0, s, squash=1.4, angle=0.3)
        assert a.points == c.points
    chain = [((k * 24.0, 0.0), 19.0) for k in range(5)]
    assert make_merged_blob(chain, 5).points == make_merged_blob(chain, 5).points
    print("determinism: identical points for repeated seeds (blob + merged)")

    # -- contains agrees with the sign of distance_to
    probe_blob = make_blob((0.0, 0.0), 25.0, seed=77, lobes=4, roughness=0.3, squash=1.6)
    mism = 0
    checked = 0
    for _ in range(5000):
        p = (rng.uniform(-45, 45), rng.uniform(-45, 45))
        d = probe_blob.distance_to(p)
        if abs(d) < 1e-6:
            continue  # exactly on the edge: sign is arbitrary
        checked += 1
        if probe_blob.contains(p) != (d < 0):
            mism += 1
    assert mism == 0, f"{mism} sign mismatches"
    print(f"contains vs distance_to sign: {checked} probes, {mism} mismatches")

    # -- benchmark: 48-vertex blob, probes inside the bounding box (worst case)
    bench = make_blob((0.0, 0.0), 25.0, seed=3, lobes=4, roughness=0.28)
    minx, miny, maxx, maxy = bench.bounds
    probes = [
        (rng.uniform(minx, maxx), rng.uniform(miny, maxy)) for _ in range(20000)
    ]
    contains = bench.contains
    t0 = time.perf_counter()
    reps = 10
    hits = 0
    for _ in range(reps):
        for p in probes:
            if contains(p):
                hits += 1
    dt = time.perf_counter() - t0
    calls = reps * len(probes)
    rate = calls / dt
    print(
        f"contains benchmark: {calls} calls in {dt:.3f}s = {rate/1000:.0f}k calls/sec "
        f"({len(bench.points)} vertices, {hits/calls:.0%} inside)"
    )
    assert rate > 300_000, f"too slow: {rate:.0f} calls/sec"

    # -- merged 6-circle creek
    creek = [((k * 26.0, math.sin(k * 0.7) * 14.0), 20.0) for k in range(6)]
    merged = make_merged_blob(creek, seed=11)
    assert not _self_intersects(merged), "merged creek self-intersects"
    for c, _r in creek:
        assert merged.contains(c), f"merged creek misses circle centre {c}"
    print(
        f"merged 6-circle creek: {len(merged.points)} vertices, simple, "
        f"contains every circle centre"
    )

    # -- the graceful-degradation path: a U-bend must split, not lie
    u = [((0.0, 0.0), 16.0), ((0.0, 26.0), 16.0), ((0.0, 52.0), 16.0),
         ((26.0, 66.0), 16.0), ((52.0, 52.0), 16.0), ((52.0, 26.0), 16.0),
         ((52.0, 0.0), 16.0)]
    parts = make_hazard_blobs(u, seed=13)
    for b in parts:
        assert not _self_intersects(b)
    covered = all(any(b.contains(c) for b in parts) for c, _ in u)
    assert covered, "split blobs lost a circle"
    print(f"U-bend chain: split into {len(parts)} blobs, all simple, all centres covered")
    print(f"straight chain of 6 merges into {len(make_hazard_blobs(creek, 13))} blob(s)")

    _demo_png()
    print("all checks passed")
