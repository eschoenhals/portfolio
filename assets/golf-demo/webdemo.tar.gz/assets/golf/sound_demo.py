"""Listen to, or measure, the synthesised effects.

    uv run python -m golf.sound_demo            # play each clip in turn
    uv run python -m golf.sound_demo --wav DIR  # write WAVs and print the stats

The WAV path exists because ear-checking a change is slow and a peak amplitude
is not: it catches a clip that has gone silent, gone over full scale or grown
past the ~1s budget without anyone having to hear it.
"""

from __future__ import annotations

import argparse
import math
import sys
import time
import wave
from pathlib import Path

import pygame

from . import sound


def _write_wavs(out_dir: Path, rate: int = sound.RATE) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"{'name':8} {'frames':>7} {'seconds':>8} {'peak':>7} {'dBFS':>7}")
    for name in sound.NAMES:
        samples = sound._RECIPES[name](rate)
        data = sound._pack(samples, 1)
        path = out_dir / f"{name}.wav"
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(data)
        peak = max(abs(int(max(-1.0, min(1.0, s)) * 32767)) for s in samples)
        db = 20.0 * math.log10(max(1, peak) / 32767.0)
        print(
            f"{name:8} {len(samples):7d} {len(samples) / rate:8.3f} {peak:7d} {db:7.1f}"
        )


def _play_all() -> None:
    pygame.init()
    sound.init()
    if not sound.is_enabled():
        print("mixer unavailable -- nothing to hear", file=sys.stderr)
        return
    print("mixer:", pygame.mixer.get_init())
    for name in sound.NAMES:
        print(" ", name)
        sound.play(name)
        time.sleep(1.2)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--wav", metavar="DIR", help="write WAVs here instead of playing")
    ap.add_argument("--rate", type=int, default=sound.RATE)
    args = ap.parse_args()
    if args.wav:
        _write_wavs(Path(args.wav), args.rate)
    else:
        _play_all()


if __name__ == "__main__":
    main()
