"""Drawing the world.

Everything on screen is a top-down view of yards, so all the drawing code
works in world units and lets the camera do the conversion.  The camera eases
towards whatever it is asked to frame, which is what makes the view glide from
"whole hole" on the tee to "just the green" when you're putting.
"""

from __future__ import annotations

import math

import pygame

from .course import Hole, Vec, green_gradient
from .physics import HOLE_R

C_BG = (24, 58, 36)
C_DEEP = (30, 72, 42)
C_ROUGH = (46, 104, 56)
C_FAIRWAY = (86, 156, 72)
C_GREEN = (132, 196, 96)
C_FRINGE = (110, 176, 86)
C_SAND = (226, 209, 158)
C_WATER = (56, 118, 176)
C_WATER_EDGE = (88, 154, 206)
C_TREE = (28, 82, 46)
C_TREE_HI = (40, 108, 60)
C_BALL = (250, 250, 250)
C_SHADOW = (18, 40, 26)
C_FLAG = (226, 72, 72)
C_TEXT = (238, 244, 236)
C_DIM = (168, 186, 170)
C_AIM = (250, 250, 250)
C_ACCENT = (250, 206, 88)
C_PANEL = (16, 30, 22)


class Camera:
    """Maps yards to pixels, easing towards a requested frame."""

    def __init__(self, viewport: pygame.Rect):
        self.viewport = viewport
        self.center: Vec = (0.0, 0.0)
        self.scale = 2.0
        self.t_center: Vec = (0.0, 0.0)
        self.t_scale = 2.0

    def frame(self, points: list[Vec], margin: float, min_span: float = 40.0, snap: bool = False):
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        cx = (min(xs) + max(xs)) / 2
        cy = (min(ys) + max(ys)) / 2
        span_x = max(max(xs) - min(xs) + margin * 2, min_span)
        span_y = max(max(ys) - min(ys) + margin * 2, min_span)
        self.t_center = (cx, cy)
        self.t_scale = min(self.viewport.width / span_x, self.viewport.height / span_y)
        if snap:
            self.center, self.scale = self.t_center, self.t_scale

    def update(self, dt: float):
        k = min(1.0, dt * 4.5)
        self.center = (
            self.center[0] + (self.t_center[0] - self.center[0]) * k,
            self.center[1] + (self.t_center[1] - self.center[1]) * k,
        )
        self.scale += (self.t_scale - self.scale) * k

    def w2s(self, p: Vec) -> tuple[float, float]:
        return (
            self.viewport.centerx + (p[0] - self.center[0]) * self.scale,
            self.viewport.centery - (p[1] - self.center[1]) * self.scale,
        )

    def px(self, yards: float) -> float:
        return yards * self.scale


# --------------------------------------------------------------------------- helpers


def corridor(pts: list[Vec], half: float) -> list[Vec]:
    """Polygon hugging a polyline at ``half`` yards either side."""
    left, right = [], []
    n = len(pts)
    for i, p in enumerate(pts):
        a = pts[max(0, i - 1)]
        b = pts[min(n - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        m = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / m, dx / m
        # Square off the ends a little past the tee and the green.
        ext = 0.0
        if i == 0:
            ext = -half * 0.8
        elif i == n - 1:
            ext = half * 0.8
        ex, ey = dx / m * ext, dy / m * ext
        left.append((p[0] + nx * half + ex, p[1] + ny * half + ey))
        right.append((p[0] - nx * half + ex, p[1] - ny * half + ey))
    return left + right[::-1]


def poly(surf, cam: Camera, points: list[Vec], color, width: int = 0):
    pts = [cam.w2s(p) for p in points]
    if len(pts) >= 3:
        pygame.draw.polygon(surf, color, pts, width)


def circle(surf, cam: Camera, c: Vec, r: float, color, width: int = 0):
    pygame.draw.circle(surf, color, cam.w2s(c), max(1.0, cam.px(r)), width)


def dotted(surf, cam: Camera, a: Vec, b: Vec, color, gap_px=13, radius=2.2):
    sa, sb = cam.w2s(a), cam.w2s(b)
    dx, dy = sb[0] - sa[0], sb[1] - sa[1]
    length = math.hypot(dx, dy)
    if length < 1:
        return
    n = max(1, int(length / gap_px))
    for i in range(n + 1):
        t = i / n
        pygame.draw.circle(surf, color, (sa[0] + dx * t, sa[1] + dy * t), radius)


def dotted_path(surf, cam: Camera, pts: list[Vec], color, gap_px=13, radius=2.2):
    """Dots evenly spaced along a whole path.

    :func:`dotted` walks a straight line, so on a shaped shot it only covered
    the chord -- the dots ran out where the curve pulled away from it, which
    read as an aim line that stopped halfway.  This one walks the arc.
    """
    sp = [cam.w2s(p) for p in pts]
    if len(sp) < 2:
        return
    pygame.draw.circle(surf, color, sp[0], radius)
    left = gap_px
    for a, b in zip(sp, sp[1:]):
        seg = math.hypot(b[0] - a[0], b[1] - a[1])
        if seg < 1e-6:
            continue
        at = 0.0
        while at + left <= seg:
            at += left
            left = gap_px
            t = at / seg
            pygame.draw.circle(
                surf, color, (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t), radius
            )
        left -= seg - at


def polyline(surf, cam: Camera, pts: list[Vec], color, width=2):
    if len(pts) < 2:
        return
    pygame.draw.lines(surf, color, False, [cam.w2s(p) for p in pts], width)


def arrow(surf, tail, tip, color, width: int = 3, head: float = 0.0):
    """A line with a real filled arrowhead, in screen pixels."""
    dx, dy = tip[0] - tail[0], tip[1] - tail[1]
    length = math.hypot(dx, dy)
    if length < 1.5:
        return
    ux, uy = dx / length, dy / length
    head = head or max(5.0, min(length * 0.55, width * 3.2))
    half = head * 0.55
    base = (tip[0] - ux * head, tip[1] - uy * head)
    pygame.draw.line(surf, color, tail, base, width)
    pygame.draw.polygon(
        surf,
        color,
        [
            tip,
            (base[0] - uy * half, base[1] + ux * half),
            (base[0] + uy * half, base[1] - ux * half),
        ],
    )


# --------------------------------------------------------------------------- the hole


def draw_hole(surf, cam: Camera, hole: Hole, *, detail_green: bool):
    surf.fill(C_BG)
    poly(surf, cam, corridor(hole.center, hole.rough_half), C_ROUGH)
    poly(surf, cam, corridor(hole.center, hole.fairway_half), C_FAIRWAY)

    # Fill every piece of a hazard before stroking any of it, so the seams
    # where a creek's segments overlap stay hidden under the neighbouring fill.
    for b in hole.water_blobs:
        poly(surf, cam, b.points, C_WATER)
    for b in hole.water_blobs:
        poly(surf, cam, b.points, C_WATER_EDGE, max(1, int(cam.px(0.8))))
    for b in hole.sand_blobs:
        poly(surf, cam, b.points, C_SAND)

    circle(surf, cam, hole.green_center, hole.green_r + 4.0, C_FRINGE)
    circle(surf, cam, hole.green_center, hole.green_r, C_GREEN)
    if detail_green:
        draw_slope_field(surf, cam, hole)

    for c, r in hole.trees:
        circle(surf, cam, c, r, C_TREE)
        circle(surf, cam, (c[0] - r * 0.22, c[1] + r * 0.22), r * 0.55, C_TREE_HI)

    draw_tee(surf, cam, hole)
    draw_cup(surf, cam, hole)


def draw_tee(surf, cam: Camera, hole: Hole):
    t = hole.tee
    a, b = hole.center[0], hole.center[1]
    dx, dy = b[0] - a[0], b[1] - a[1]
    m = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / m, dx / m
    for s in (-1, 1):
        p = cam.w2s((t[0] + nx * 3.5 * s, t[1] + ny * 3.5 * s))
        r = max(2.0, cam.px(1.1))
        pygame.draw.circle(surf, (235, 235, 235), p, r)


def draw_cup(surf, cam: Camera, hole: Hole):
    # Drawn at very nearly its true radius. Anything more generous and a putt
    # that missed by an honest inch looks like it rolled through the hole.
    p = cam.w2s(hole.pin)
    pygame.draw.circle(surf, (26, 34, 26), p, max(2.0, cam.px(HOLE_R * 1.1)))
    top = (p[0], p[1] - 34)
    pygame.draw.line(surf, (245, 245, 245), p, top, 2)
    pygame.draw.polygon(
        surf, hole.flag_color, [top, (top[0] + 20, top[1] + 6), (top[0], top[1] + 13)]
    )


def slope_arrows(hole: Hole) -> list[tuple[Vec, Vec, float]]:
    """Sample the green's fall line: (tail, tip, strength) in world yards.

    Shared by both views so the break you read is the break you get.
    """
    gc, gr = hole.green_center, hole.green_r
    step = max(2.6, gr / 5.0)
    n = int(gr / step)
    out = []
    for iy in range(-n, n + 1):
        for ix in range(-n, n + 1):
            p = (gc[0] + ix * step, gc[1] + iy * step)
            if math.hypot(p[0] - gc[0], p[1] - gc[1]) > gr - step * 0.4:
                continue
            gx, gy = green_gradient(hole, p)
            mag = math.hypot(gx, gy)
            if mag < 1e-4:
                continue
            strength = min(1.0, mag / 0.05)
            dx, dy = -gx / mag, -gy / mag  # downhill
            length = (0.35 + 0.65 * strength) * step * 0.7
            tail = (p[0] - dx * length * 0.5, p[1] - dy * length * 0.5)
            tip = (p[0] + dx * length * 0.5, p[1] + dy * length * 0.5)
            out.append((tail, tip, strength))
    return out


def draw_slope_field(surf, cam: Camera, hole: Hole):
    """Little downhill arrows across the green -- the player's break read."""
    for tail, tip, strength in slope_arrows(hole):
        shade = int(60 + 160 * strength)
        arrow(surf, cam.w2s(tail), cam.w2s(tip), (shade, 250, shade), 2)


def draw_ball(surf, cam: Camera, pos: Vec, height: float = 0.0, color=C_BALL):
    sp = cam.w2s(pos)
    r = max(3.5, min(9.0, cam.px(0.9))) + min(3.0, height * 0.07)
    if height > 0.05:
        shadow = (sp[0], sp[1] + min(26.0, height * cam.scale * 0.35))
        pygame.draw.circle(surf, C_SHADOW, shadow, r * 0.8)
    pygame.draw.circle(surf, color, sp, r)
    if r >= 5:
        pygame.draw.circle(surf, (60, 80, 62), sp, r, 1)


def draw_trail(surf, cam: Camera, shots: list[list[Vec]], color=(196, 214, 198)):
    for path in shots:
        if len(path) > 1:
            pygame.draw.lines(surf, color, False, [cam.w2s(p) for p in path], 1)


def draw_minimap(size: tuple[int, int], hole: Hole, balls, aim_end=None) -> pygame.Surface:
    """The whole hole at a glance.

    The main view zooms to the shot in front of you, which is the right thing
    for aiming and useless for course management -- so the routing lives here.
    """
    surf = pygame.Surface(size, pygame.SRCALPHA)
    surf.fill((10, 22, 16, 205))
    cam = Camera(pygame.Rect(0, 0, *size))
    cam.frame(hole.center + [hole.green_center], margin=hole.rough_half + 8, snap=True)

    poly(surf, cam, corridor(hole.center, hole.rough_half), C_ROUGH)
    poly(surf, cam, corridor(hole.center, hole.fairway_half), C_FAIRWAY)
    for b in hole.water_blobs:
        poly(surf, cam, b.points, C_WATER)
    for b in hole.sand_blobs:
        poly(surf, cam, b.points, C_SAND)
    circle(surf, cam, hole.green_center, hole.green_r, C_GREEN)

    if aim_end is not None and balls:
        pygame.draw.line(surf, (255, 255, 255), cam.w2s(balls[0][0]), cam.w2s(aim_end), 1)
    pygame.draw.circle(surf, hole.flag_color, cam.w2s(hole.pin), 3)
    for pos, color in balls:
        pygame.draw.circle(surf, color, cam.w2s(pos), 3)
    pygame.draw.rect(surf, (70, 110, 78), surf.get_rect(), 1, border_radius=4)
    return surf
