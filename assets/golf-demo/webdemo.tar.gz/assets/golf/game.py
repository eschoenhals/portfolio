"""Game loop, states and HUD."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

import pygame

from . import career as CR
from . import cpu as CPU
from . import handicap as HC
from . import render as R
from . import sound
from . import store
from . import tour
from . import view3d as V
from .catalog import COURSES
from .clubs import ARCHETYPES, BAG, PUTTER_INDEX, Archetype, suggest_club
from .course import (
    LIE_NAMES,
    LIE_POWER,
    LIE_SPRAY,
    TEES,
    CourseSpec,
    Hole,
    Vec,
    build_course,
    dist,
    green_gradient,
    terrain_at,
    wind_now,
)
from .physics import (
    OVERSWING,
    deg_from_dir,
    dir_from_deg,
    expected_carry,
    putt_distance,
    shape_curve,
    simulate_putt,
    simulate_shot,
    spin_bend,
)

W, H = 1280, 820
HUD_H = 132
FPS = 60

MENU = "menu"
BOARD = "leaderboard"
INTRO = "intro"
AIM = "aim"
SWING = "swing"
FLY = "fly"
PUTT_AIM = "putt_aim"
PUTT_ROLL = "putt_roll"
HOLE_DONE = "hole_done"
CARD = "card"
CAREER = "career"
EVENT = "event"

PLAY_STATES = (INTRO, AIM, SWING, FLY, PUTT_AIM, PUTT_ROLL, HOLE_DONE)

GIMME_YARDS = 0.42  # ~15 inches
PUTT_CHARGE_TIME = 2.0  # seconds from nothing to a full-blooded putt
TWO_PUTT_RING = 1.0  # yards; the "get it inside here" circle on the green
STRIKE_STEP = 0.25  # how far one keypress moves the strike point on the face

ROUNDS = [("Front 9", 0, 9), ("Back 9", 9, 18), ("18 Holes", 0, 18)]
FORMATS = ["Stroke Play", "Match Play"]
MODES = ["Exhibition", "Match vs CPU", "Career"]
#: "Random" first so the default is a name that suits the difficulty rather than
#: whoever happens to sit at the top of the roster.
OPPONENTS = ["Random"] + tour.NAMES
VIEWS = ["Top-Down", "Behind Ball"]
SHOT_CAMS = ["Fixed", "Follow Ball"]

P_COLORS = [(250, 250, 250), (252, 214, 120)]

#: What each difficulty actually shoots, measured rather than guessed -- see the
#: tier check in `smoke_test.py`, which fails if these stop being true.
CPU_PACE = {"Amateur": "+12", "Club Pro": "+6", "Tour Pro": "+3", "Legend": "+2"}

PACE_COLORS = {
    "dead weight": (140, 226, 140),
    "firm": (250, 206, 88),
    "racing": (240, 110, 96),
    "short": (150, 176, 210),
}
PACE_HINTS = {
    "dead weight": "dies at the hole - most forgiving",
    "firm": "will run a little past",
    "racing": "through the break, and it will not stop",
    "short": "not enough to get there",
}


import os as _os

# pygbag's WASM sandbox has no system font database, so SysFont("menlo,...")
# silently falls back to a non-monospace default and every hand-positioned
# HUD element crowds together. This file is a web-build-only vendored copy;
# bundle the same DejaVu Sans Mono the desktop SysFont call already listed
# as its non-Mac fallback, and load it directly instead of looking it up.
_FONT_DIR = _os.path.join(_os.path.dirname(__file__), "webfonts")
_FONT_REGULAR = _os.path.join(_FONT_DIR, "DejaVuSansMono.ttf")
_FONT_BOLD = _os.path.join(_FONT_DIR, "DejaVuSansMono-Bold.ttf")


def font(size: int, bold: bool = False) -> pygame.font.Font:
    path = _FONT_BOLD if bold else _FONT_REGULAR
    return pygame.font.Font(path, size)


def score_name(strokes: int, par: int) -> str:
    rel = strokes - par
    if strokes == 1:
        return "Hole in One!"
    return {
        -3: "Albatross!",
        -2: "Eagle!",
        -1: "Birdie",
        0: "Par",
        1: "Bogey",
        2: "Double Bogey",
        3: "Triple Bogey",
    }.get(rel, f"{rel:+d}")


def rel_str(rel: int) -> str:
    return "E" if rel == 0 else f"{rel:+d}"


def club_sound(club) -> str:
    if club.putter:
        return "putt"
    if club.carry >= 210:
        return "drive"
    return "iron" if club.carry >= 130 else "wedge"


@dataclass
class Player:
    name: str
    color: tuple[int, int, int]
    arch: Archetype
    ball: Vec = (0.0, 0.0)
    lie: str = "tee"
    aim: float = 0.0
    # Where on the face the next ball gets struck: +x towards the toe (a fade),
    # +y above the equator (topspin). Centre is the plain, straight strike.
    strike: tuple[float, float] = (0.0, 0.0)
    club_index: int = 0
    strokes: int = 0
    holed: bool = False
    conceded: bool = False
    scores: list[int] = field(default_factory=list)
    trail: list[list[Vec]] = field(default_factory=list)
    # None means a person at the keyboard, which is every player the game had
    # before match play against the CPU existed.
    cpu: tour.Level | None = None

    def start_hole(self, tee: Vec):
        self.ball = tee
        self.lie = "tee"
        self.strike = (0.0, 0.0)
        self.strokes = 0
        self.holed = False
        self.conceded = False
        self.trail = []


class Game:
    def __init__(self, screen: pygame.Surface):
        self.screen = screen
        # The play area sits between the two HUD strips, so framing never
        # tucks the green or the ball behind them.
        self.viewport = pygame.Rect(0, 70, W, H - HUD_H - 70)
        self.cam = R.Camera(self.viewport)
        self.cam3 = V.Camera3(self.viewport)
        self.rng = random.Random()
        # The opponent rolls its decisions on its own stream, for the same reason
        # Weather does: changing how the CPU thinks must not reshuffle the rng
        # that every shot in the game is resolved from.
        self.cpu_rng = random.Random()
        self.f_sm = font(15)
        self.f_md = font(19)
        self.f_lg = font(26, True)
        self.f_xl = font(44, True)

        self.state = MENU
        self.message = ""

        # Menu selections.
        self.mode_index = 0
        self.opp_index = 0
        self.diff_index = 1
        self.course_index = 0
        self.tee_index = 0
        self.round_index = 2
        self.format_index = 0
        self.view_index = 0
        self.cam_index = 1  # follow the ball by default; it is the better watch
        self.names = ["Player 1", "Player 2"]
        self.arch_index = [0, 0]
        self.menu_col = 0
        self.menu_row = 0
        self.editing = -1
        self.board_tab = 0
        self.board_player = 0

        self.spec: CourseSpec = COURSES[0]
        self.all_holes: list[Hole] = []
        self.holes: list[Hole] = []
        self.hole_index = 0
        self.hole: Hole | None = None
        self.players: list[Player] = []
        self.turn = 0
        self.honor = 0
        self.match_up = 0
        self.match_result = ""
        self.hole_note = ""

        # Career mode. `career_round` is the flag that says the round being
        # played right now is a tournament round rather than an exhibition; it
        # is what forces stroke play over eighteen and sends the scorecard back
        # to the event instead of to the clubhouse.
        self.career: CR.Career | None = None
        self.career_round = False
        self.career_tab = 0
        self.career_row = 0
        self.confirm_wipe = False
        self.event: CR.Event | None = None
        self.ev_holes: list[Hole] = []
        self.ev_field: list[str] = []
        self.ev_scores: dict[str, list[int]] = {}
        self.ev_cut: list[str] = []
        self.ev_round = 0
        self.ev_played = 0
        self.ev_mine_played: list[int] = []
        self.ev_done = False
        self.ev_rng = random.Random()

        self.cpu_reset()
        self.reset_shot_state()

    # ------------------------------------------------------------------ properties

    @property
    def p(self) -> Player:
        return self.players[self.turn]

    @property
    def club(self):
        return BAG[self.p.club_index]

    @property
    def mode(self) -> str:
        return MODES[self.mode_index]

    @property
    def vs_cpu(self) -> bool:
        return self.mode == "Match vs CPU"

    @property
    def career_mode(self) -> bool:
        return self.mode == "Career"

    @property
    def level(self) -> tour.Level:
        return tour.LEVELS[self.diff_index]

    @property
    def match_play(self) -> bool:
        """Playing for holes rather than strokes. A CPU match always is."""
        if self.career_round:
            return False  # a tournament round is you against the card
        return self.vs_cpu or FORMATS[self.format_index] == "Match Play"

    @property
    def format_name(self) -> str:
        """What is actually being played, which is not always what the row says.

        A CPU match forces match play without touching ``format_index``, so
        reading the menu row straight out filed those rounds as "Stroke Play" --
        and the handicap adapter drops match play precisely because holes get
        conceded, so a conceded card sailed past that guard and blew up the
        moment anything tried to read it back.
        """
        if self.career_round:
            return "Stroke Play"
        return "Match Play" if self.match_play else FORMATS[self.format_index]

    @property
    def view3d(self) -> bool:
        return self.view_index == 1

    @property
    def follow_cam(self) -> bool:
        return self.cam_index == 1

    @property
    def wind(self) -> Vec:
        """The wind right now -- what the arrow shows, and what a shot struck
        this instant will get. `hole.wind` is only the average it wanders about."""
        return wind_now(self.hole, self.wind_t)

    @property
    def round_key(self) -> str:
        return "18 Holes" if self.career_round else ROUNDS[self.round_index][0]

    @property
    def tee_name(self) -> str:
        return TEES[self.tee_index][0]

    @property
    def tee_scale(self) -> float:
        return TEES[self.tee_index][1]

    # ------------------------------------------------------------------ setup

    def reset_shot_state(self):
        self.wind_t = getattr(self, "wind_t", 0.0)
        self.shot_wind: Vec = (0.0, 0.0)
        self.meter_phase = ""
        self.meter_value = 0.0
        self.meter_power = 0.0
        self.shot = None
        self.shot_origin: Vec = (0.0, 0.0)
        self.shot_aim = 0.0
        self.anim_t = 0.0
        self.anim_pts: list[tuple[Vec, float]] = []
        self.anim_roll: list[tuple[Vec, float]] = []
        self.anim_dur = 1.0
        self.flight_dur = 1.0
        self.roll_dur = 0.0
        self.anim_ease = 1.0
        self.putt = None
        self.charging = False
        self.putt_power = 0.0
        self.preview = None

    def start_round(self):
        self.spec = COURSES[self.course_index]
        self.all_holes = build_course(self.spec, self.tee_scale)
        # A tournament round is always the full eighteen, whatever the exhibition
        # menu was last set to.
        lo, hi = (0, 18) if self.career_round else ROUNDS[self.round_index][1:]
        self.holes = self.all_holes[lo:hi]
        self.hole_index = 0
        self.honor = 0
        self.match_up = 0
        self.match_result = ""
        self.players = [
            Player(
                self.names[0].strip() or "Player 1",
                P_COLORS[0],
                ARCHETYPES[self.arch_index[0]],
            )
        ]
        if self.career_round:
            pass  # a tournament round is you and the card; the field is scored
        elif self.vs_cpu:
            lv = self.level
            self.players.append(
                Player(self.opponent_name(), P_COLORS[1], tour.archetype_for(lv), cpu=lv)
            )
        elif self.match_play:
            self.players.append(
                Player(
                    self.names[1].strip() or "Player 2",
                    P_COLORS[1],
                    ARCHETYPES[self.arch_index[1]],
                )
            )
        self.begin_hole()

    # ------------------------------------------------------------------ career

    def open_career(self):
        """The clubhouse: resume the season on disk, or start one."""
        self.career = CR.load() or CR.Career(
            name=self.names[0].strip() or "Player 1",
            arch=ARCHETYPES[self.arch_index[0]].name,
            seed=random.randrange(1 << 30),
        )
        self.career_round = False
        self.confirm_wipe = False
        self.career_row = min(self.career.next_event, len(CR.schedule()) - 1)
        CR.save(self.career)
        self.state = CAREER

    def open_event(self):
        """Set up the next tournament on the schedule.

        The field and every score in it come off one rng seeded from the career
        and the event, so re-entering a tournament you have already started
        shows you the same leaderboard rather than reshuffling the world.
        """
        car = self.career
        sched = CR.schedule()
        if car.done():
            return
        self.event = sched[car.next_event]
        self.course_index = next(
            (i for i, s in enumerate(COURSES) if s.name == self.event.course), 0
        )
        self.spec = COURSES[self.course_index]
        self.ev_holes = build_course(self.spec, self.tee_scale)
        self.ev_rng = random.Random(car.seed * 1000 + car.season * 100 + car.next_event)
        self.ev_field = CR.field_for(self.event, self.ev_rng)
        self.ev_scores = {n: [] for n in self.ev_field}
        self.ev_scores[car.name] = []
        self.ev_cut = []
        self.ev_round = 0
        self.ev_played = 0
        self.ev_mine_played = []
        self.ev_done = False

        # Pick a half-finished tournament back up. The rng is re-advanced by the
        # rounds already in the book, so Saturday is drawn from where Friday left
        # off rather than from the top of the stream.
        live = car.live
        if live.get("event") == self.event.name:
            self.ev_scores.update({k: list(v) for k, v in live.get("scores", {}).items()})
            self.ev_cut = list(live.get("cut", []))
            self.ev_round = int(live.get("round", 0))
            self.ev_played = int(live.get("played", 0))
            self.ev_mine_played = list(live.get("mine", []))
            for _ in range(self.ev_round):
                CR.simulate_round(self.ev_rng, self.ev_holes, self.ev_field)
        self.state = EVENT

    def save_live_event(self):
        """Park the tournament in the save file between rounds."""
        self.career.live = {
            "event": self.event.name,
            "round": self.ev_round,
            "played": self.ev_played,
            "mine": list(self.ev_mine_played),
            "scores": {k: list(v) for k, v in self.ev_scores.items() if v},
            "cut": list(self.ev_cut),
        }
        CR.save(self.career)

    @property
    def ev_par(self) -> int:
        return sum(h.par for h in self.ev_holes)

    def ev_total(self, name: str) -> int:
        return sum(self.ev_scores.get(name, []))

    def ev_table(self) -> list[tuple[int, str, int, bool]]:
        """The leaderboard, everyone still in the tournament."""
        live = {n: sum(s) for n, s in self.ev_scores.items()
                if s and n not in self.ev_cut}
        return CR.rank(live)

    def sim_my_round(self):
        """Play a tournament round without playing it.

        The score comes from your own handicap index, so skipping a round gives
        you the round you have actually been shooting rather than a freebie.
        """
        if self.ev_done or self.career.name in self.ev_cut:
            return
        # Only rounds you actually *played* may set the rating. Feeding simulated
        # rounds back in makes the estimate a random walk with nothing anchoring
        # it: a lucky Thursday ratchets the rating up, which buys a better
        # Friday, which ratchets it again -- one simulated season came out with
        # five wins and a 43-under at St Andrews. A simulated round is drawn from
        # the estimate and therefore carries no evidence about it.
        rating = CR.rating_from_scores(self.ev_holes, self.ev_mine_played)
        if rating is None:
            rating = CR.player_rating(HC.index_for(store.rounds_for(self.career.name)))
        self.ev_scores[self.career.name].append(
            sum(CR.round_score(self.ev_rng, self.ev_holes, rating))
        )
        self.advance_event_round()

    def start_career_round(self):
        self.career_round = True
        self.round_index = 2  # the schedule plays eighteen; the row is hidden
        self.start_round()

    def advance_event_round(self):
        """Everyone else plays the round you just finished, then the cut falls."""
        car = self.career
        live = [n for n in self.ev_field if n not in self.ev_cut]
        for n, total in CR.simulate_round(self.ev_rng, self.ev_holes, live).items():
            self.ev_scores[n].append(total)
        self.ev_round += 1

        if self.ev_round == self.event.cut_after:
            totals = {n: sum(s) for n, s in self.ev_scores.items() if s}
            line = CR.cut_line(totals)
            self.ev_cut = [n for n, t in totals.items() if t > line]

        if car.name in self.ev_cut:
            # You are done, but the tournament is not: somebody still has to win
            # it, so the weekend is played out before the result is filed.
            while self.ev_round < self.event.rounds:
                live = [n for n in self.ev_field if n not in self.ev_cut]
                for n, t in CR.simulate_round(self.ev_rng, self.ev_holes, live).items():
                    self.ev_scores[n].append(t)
                self.ev_round += 1

        if self.ev_round >= self.event.rounds:
            self.finish_event()
        else:
            self.save_live_event()

    def finish_event(self):
        car, ev = self.career, self.event
        me = car.name
        table = self.ev_table()
        tied_at = {}
        for pos, _, _, _ in table:
            tied_at[pos] = tied_at.get(pos, 0) + 1

        for pos, name, total, tied in table:
            if name == me:
                continue
            car.credit(name, CR.money_for(ev, pos, tied_at[pos]),
                       CR.points_for(pos, ev.major))

        par = self.ev_par * self.event.rounds
        if me in self.ev_cut:
            res = CR.Result(ev.name, ev.course, cut=True, total=self.ev_total(me),
                            par=self.ev_par * max(1, ev.cut_after),
                            played=self.ev_played)
        else:
            pos, _, total, tied = next(r for r in table if r[1] == me)
            res = CR.Result(ev.name, ev.course, pos=pos, tied=tied, total=total,
                            par=par,
                            money=CR.money_for(ev, pos, tied_at[pos]),
                            points=CR.points_for(pos, ev.major),
                            played=self.ev_played)
        car.results.append(res)
        car.next_event += 1
        car.live = {}  # the tournament is over; nothing left to resume
        CR.save(car)
        self.ev_done = True
        if res.pos == 1 and not res.cut:
            sound.play("cheer", 0.9)

    def key_career(self, ev):
        sched = CR.schedule()
        if ev.key == pygame.K_TAB:
            self.career_tab = 1 - self.career_tab
            sound.play("menu")
        elif ev.key in (pygame.K_UP, pygame.K_w):
            self.career_row = (self.career_row - 1) % len(sched)
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.career_row = (self.career_row + 1) % len(sched)
        elif ev.key == pygame.K_r:
            # Abandoning a season is not undoable, so it takes two presses.
            if self.confirm_wipe:
                CR.erase()
                self.career = None
                self.confirm_wipe = False
                self.state = MENU
            else:
                self.confirm_wipe = True
        elif ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            self.confirm_wipe = False
            if not self.career.done():
                sound.play("select")
                self.open_event()

    def key_event(self, ev):
        if ev.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            self.state = CAREER
        elif self.ev_done:
            if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
                self.career_row = min(self.career.next_event, len(CR.schedule()) - 1)
                self.state = CAREER
        elif ev.key == pygame.K_s:
            sound.play("select")
            self.sim_my_round()
        elif ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            sound.play("select")
            self.start_career_round()

    def opponent_name(self) -> str:
        """Who you are playing. "Random" draws from the band the difficulty suits."""
        if self.opp_index == 0:
            return tour.opponent_for(self.level, self.cpu_rng)
        return OPPONENTS[self.opp_index]

    def begin_hole(self):
        self.reset_shot_state()
        self.cpu_reset()
        self.hole = self.holes[self.hole_index]
        for pl in self.players:
            pl.start_hole(self.hole.tee)
        self.turn = self.honor if self.honor < len(self.players) else 0
        self.aim_at_pin()
        self.auto_club()
        self.frame_hole(snap=True)
        self.message = ""
        self.state = INTRO

    # ------------------------------------------------------------------ helpers

    def pin_dist(self, pl: Player | None = None) -> float:
        return dist((pl or self.p).ball, self.hole.pin)

    def bearing_to(self, target: Vec, pl: Player | None = None) -> float:
        """The heading from a player's ball to a point. The CPU aims with this too."""
        b = (pl or self.p).ball
        return deg_from_dir((target[0] - b[0], target[1] - b[1]))

    def aim_at_pin(self):
        self.p.aim = self.bearing_to(self.hole.pin)

    def auto_club(self):
        p = self.p
        if p.lie in ("green", "fringe"):
            p.club_index = PUTTER_INDEX
        else:
            p.club_index = suggest_club(
                self.pin_dist(), LIE_POWER.get(p.lie, 1.0), p.arch.power
            )

    def frame_hole(self, snap=False):
        pts = [self.p.ball, self.hole.pin, self.hole.tee] + self.hole.center
        self.cam.frame(pts, margin=45, min_span=120, snap=snap)

    def frame_shot(self, snap=False):
        """Zoom to the shot in front of you, not the whole hole.

        On the tee of a 500-yarder, framing the pin as well throws away most of
        the screen.  The mini-map carries the routing instead.
        """
        p = self.p
        target = self.aim_target()
        pts = [p.ball, target]
        if dist(p.ball, self.hole.pin) <= dist(p.ball, target) * 1.25 + 20:
            pts.append(self.hole.pin)
        self.cam.frame(pts, margin=42, min_span=95, snap=snap)

    def frame_green(self, snap=False):
        self.cam.frame([self.p.ball, self.hole.pin], margin=7, min_span=22, snap=snap)

    def stock_carry(self) -> float:
        """What the club plays from this lie with this strike -- wind aside."""
        p = self.p
        return expected_carry(self.club, p.lie, p.arch, p.strike)

    def aim_target(self) -> Vec:
        """Where a clean strike finishes its carry, shape included."""
        p = self.p
        carry = self.stock_carry()
        return self.shape_line(carry)[-1]

    def shape_line(self, carry: float) -> list[Vec]:
        """The curve the current strike point promises, for the aim assist."""
        p = self.p
        bend = spin_bend(self.club, p.lie, p.strike, carry, p.arch)
        return shape_curve(p.ball, p.aim, carry, bend)

    # ------------------------------------------------------------------ input

    def handle(self, ev: pygame.event.Event) -> bool:
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_ESCAPE:
                if self.state == MENU:
                    return False
                if self.editing >= 0:
                    self.editing = -1
                elif self.state == EVENT:
                    self.state = CAREER  # back to the clubhouse, not out of it
                elif self.state in PLAY_STATES and self.career_round:
                    self.career_round = False
                    self.state = EVENT
                else:
                    self.state = MENU
                return True
            if self.state in PLAY_STATES and ev.key == pygame.K_v:
                self.view_index = 1 - self.view_index
                sound.play("menu")
                return True
            if self.state in PLAY_STATES and ev.key == pygame.K_f:
                self.cam_index = 1 - self.cam_index
                self.message = f"Shot camera: {SHOT_CAMS[self.cam_index]}"
                sound.play("menu")
                return True
            if self.state in PLAY_STATES and ev.key == pygame.K_m:
                sound.set_enabled(not sound.is_enabled())
                self.message = "Sound on" if sound.is_enabled() else "Sound off"
                return True
            # Nobody gets to play the opponent's ball for it. The view, camera
            # and sound keys above stay live because they are the watcher's.
            if self.state in (AIM, SWING, PUTT_AIM) and self.p.cpu:
                return True
            handler = {
                MENU: self.key_menu,
                BOARD: self.key_board,
                CAREER: self.key_career,
                EVENT: self.key_event,
                INTRO: self.key_intro,
                AIM: self.key_aim,
                SWING: self.key_swing,
                PUTT_AIM: self.key_putt,
                HOLE_DONE: self.key_hole_done,
                CARD: self.key_card,
            }.get(self.state)
            if handler:
                handler(ev)
        elif ev.type == pygame.KEYUP and ev.key == pygame.K_SPACE:
            if self.state == PUTT_AIM and self.charging and not self.p.cpu:
                self.strike_putt()
        return True

    # ---- menu

    def menu_columns(self) -> tuple[list[str], list[str]]:
        right = ["name0", "arch0"]
        if self.career_mode:
            # The schedule picks the course and the format, so the only choices
            # left here are the ones about you and about the camera.
            return ["mode", "tee", "view", "shotcam"], right
        if self.vs_cpu:
            return (["mode", "course", "tee", "round", "opponent", "difficulty",
                     "view", "shotcam"], right)
        left = ["mode", "course", "tee", "round", "format", "view", "shotcam"]
        if self.match_play:
            right += ["name1", "arch1"]
        return left, right

    def menu_selected(self) -> str:
        cols = self.menu_columns()
        col = cols[self.menu_col]
        return col[min(self.menu_row, len(col) - 1)]

    def key_menu(self, ev):
        if self.editing >= 0:
            if ev.key == pygame.K_BACKSPACE:
                self.names[self.editing] = self.names[self.editing][:-1]
            elif ev.key in (pygame.K_RETURN, pygame.K_TAB):
                self.editing = -1
                sound.play("select")
            elif ev.unicode and ev.unicode.isprintable() and len(self.names[self.editing]) < 14:
                self.names[self.editing] += ev.unicode
            return

        cols = self.menu_columns()
        row = self.menu_selected()

        if ev.key in (pygame.K_UP, pygame.K_w):
            self.menu_row = (self.menu_row - 1) % len(cols[self.menu_col])
            sound.play("menu")
        elif ev.key in (pygame.K_DOWN, pygame.K_s):
            self.menu_row = (self.menu_row + 1) % len(cols[self.menu_col])
            sound.play("menu")
        elif ev.key == pygame.K_TAB:
            self.menu_col = 1 - self.menu_col
            self.menu_row = min(self.menu_row, len(cols[self.menu_col]) - 1)
            sound.play("menu")
        elif ev.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
            step = -1 if ev.key in (pygame.K_LEFT, pygame.K_a) else 1
            self.cycle(row, step)
            sound.play("menu")
        elif ev.key == pygame.K_RETURN and row.startswith("name"):
            self.editing = int(row[-1])
        elif ev.key == pygame.K_SPACE:
            sound.play("select")
            if self.career_mode:
                self.open_career()
            else:
                self.career_round = False
                self.start_round()
        elif ev.key == pygame.K_l:
            self.state = BOARD

    def cycle(self, row: str, step: int):
        if row == "mode":
            self.mode_index = (self.mode_index + step) % len(MODES)
            cols = self.menu_columns()
            self.menu_col = min(self.menu_col, len(cols) - 1)
            self.menu_row = min(self.menu_row, len(cols[self.menu_col]) - 1)
        elif row == "opponent":
            self.opp_index = (self.opp_index + step) % len(OPPONENTS)
        elif row == "difficulty":
            self.diff_index = (self.diff_index + step) % len(tour.LEVELS)
        elif row == "course":
            self.course_index = (self.course_index + step) % len(COURSES)
        elif row == "tee":
            self.tee_index = (self.tee_index + step) % len(TEES)
        elif row == "round":
            self.round_index = (self.round_index + step) % len(ROUNDS)
        elif row == "format":
            self.format_index = (self.format_index + step) % len(FORMATS)
            cols = self.menu_columns()
            self.menu_row = min(self.menu_row, len(cols[self.menu_col]) - 1)
        elif row == "view":
            self.view_index = (self.view_index + step) % len(VIEWS)
        elif row == "shotcam":
            self.cam_index = (self.cam_index + step) % len(SHOT_CAMS)
        elif row.startswith("arch"):
            i = int(row[-1])
            self.arch_index[i] = (self.arch_index[i] + step) % len(ARCHETYPES)

    def key_board(self, ev):
        if ev.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_l):
            self.state = MENU
        elif ev.key == pygame.K_TAB:
            self.board_tab = 1 - self.board_tab
        elif ev.key in (pygame.K_LEFT, pygame.K_a):
            if self.board_tab:
                self.board_player -= 1
            else:
                self.course_index = (self.course_index - 1) % len(COURSES)
        elif ev.key in (pygame.K_RIGHT, pygame.K_d):
            if self.board_tab:
                self.board_player += 1
            else:
                self.course_index = (self.course_index + 1) % len(COURSES)
        elif ev.key in (pygame.K_UP, pygame.K_w, pygame.K_DOWN, pygame.K_s):
            self.round_index = (self.round_index + 1) % len(ROUNDS)

    # ---- play

    def key_intro(self, ev):
        if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            self.state = AIM
            self.frame_shot()

    def key_aim(self, ev):
        p = self.p
        # W/A/S/D are the strike point rather than club aliases: the four keys
        # sit in the same little cross the diagram draws on the ball.
        if ev.key == pygame.K_UP:
            p.club_index = max(0, p.club_index - 1)
        elif ev.key == pygame.K_DOWN:
            p.club_index = min(PUTTER_INDEX, p.club_index + 1)
        elif ev.key == pygame.K_w:
            self.nudge_strike(0, 1)
        elif ev.key == pygame.K_s:
            self.nudge_strike(0, -1)
        elif ev.key == pygame.K_a:
            self.nudge_strike(-1, 0)
        elif ev.key == pygame.K_d:
            self.nudge_strike(1, 0)
        elif ev.key == pygame.K_x:
            p.strike = (0.0, 0.0)
        elif ev.key == pygame.K_r:
            self.aim_at_pin()
        elif ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            if self.club.putter:
                if p.lie in ("green", "fringe"):
                    self.enter_putting()
                else:
                    self.message = "The putter is for the green."
            else:
                self.meter_phase = "power"
                self.meter_value = 0.0
                self.meter_power = 0.0
                self.state = SWING

    def nudge_strike(self, dx: int, dy: int):
        if self.club.putter:
            return
        sx, sy = self.p.strike
        clamp = lambda v: max(-1.0, min(1.0, v))  # noqa: E731
        self.p.strike = (clamp(sx + dx * STRIKE_STEP), clamp(sy + dy * STRIKE_STEP))
        sound.play("menu", 0.5)

    def meter_speed(self) -> float:
        """How fast the swing meter sweeps, in meter units per second."""
        return 1.20 * self.club.tempo * self.p.arch.tempo

    def power_snap(self) -> float:
        """Width of the "that was 100%" window at the top of the meter.

        The meter only moves on frame boundaries, and a driver covers 2.5% of it
        between one frame and the next -- a Bomber's 3.1% -- so exactly 1.0 is a
        value the player can physically never press on.  Without a window,
        aiming at the line is a coin flip on landing a hair past it and eating
        the full overswing miss, which reads as being punished for good timing.
        One frame of travel is precisely the precision the clock denies them, so
        that is what they get back, and :meth:`draw_meter` paints the window so
        the deal stays visible.
        """
        return self.meter_speed() / FPS * 1.15

    def key_swing(self, ev):
        if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            if self.meter_phase == "power":
                power = max(0.05, self.meter_value)
                if 1.0 < power <= 1.0 + self.power_snap():
                    power = 1.0  # they pressed on the line; the frame clock overshot it
                self.meter_power = power
                self.meter_phase = "accuracy"
            else:
                self.fire(self.meter_power, self.meter_value)

    def key_putt(self, ev):
        if ev.key == pygame.K_r:
            self.aim_at_pin()
        elif ev.key == pygame.K_c and self.p.lie == "fringe":
            self.p.club_index = PUTTER_INDEX - 1  # lob wedge
            self.state = AIM
            self.frame_shot()
        elif ev.key == pygame.K_SPACE and not self.charging:
            self.charging = True
            self.putt_power = 0.0

    def key_hole_done(self, ev):
        if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            self.hole_index += 1
            if self.hole_index >= len(self.holes) or self.match_result:
                self.finish_round()
            else:
                self.begin_hole()

    def key_card(self, ev):
        if ev.key in (pygame.K_SPACE, pygame.K_RETURN):
            if self.career_round:
                self.career_round = False
                self.state = EVENT
            else:
                self.state = MENU
        elif ev.key == pygame.K_l:
            self.state = BOARD

    def hold_keys(self, dt: float):
        if self.state not in (AIM, PUTT_AIM) or self.p.cpu:
            return
        keys = pygame.key.get_pressed()
        fine = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
        rate = (48.0 if self.state == AIM else 13.0) * (0.2 if fine else 1.0)
        if keys[pygame.K_LEFT]:
            self.p.aim -= rate * dt
        if keys[pygame.K_RIGHT]:
            self.p.aim += rate * dt

    # ------------------------------------------------------------------ shots

    def fire(self, power: float, err: float):
        p = self.p
        self.shot_origin = p.ball
        self.shot_aim = p.aim
        self.shot_wind = self.wind
        self.shot = simulate_shot(
            self.hole,
            self.spec.roll_mult,
            p.ball,
            p.aim,
            power,
            self.club,
            p.lie,
            err,
            self.rng,
            self.spec.green_friction,
            p.arch,
            p.strike,
            # Whatever the arrow read at the instant of the strike is the wind
            # the ball gets. Watching it and timing it is the point.
            self.shot_wind,
        )
        p.strokes += 1 + self.shot.penalty
        p.trail.append(list(self.shot.flight))
        # Flight and roll get their own clocks. They are sampled at wildly
        # different rates -- 46 points for the whole carry, 120 a second on the
        # ground -- so spreading one clock over the concatenation gave a long
        # run-out most of the animation and flashed the flight past in a blink.
        self.anim_pts = list(zip(self.shot.flight, self.shot.heights))
        self.anim_roll = [(q, 0.0) for q in self.shot.roll]
        self.anim_t = 0.0
        self.flight_dur = min(2.8, 0.62 + 1.35 * (max(4.0, self.shot.carry) / 260.0) ** 0.62)
        # The roll path is already in real time, so it plays at its own pace --
        # capped, or a 60-yard run-out would hold the camera for four seconds.
        self.roll_dur = min(1.2, len(self.anim_roll) / 120.0)
        self.anim_dur = self.flight_dur + self.roll_dur
        self.anim_ease = 1.25  # the ball is quickest off the face, slowest as it drops
        self.meter_phase = ""
        p.strike = (0.0, 0.0)  # back to the middle of the face for the next one

        sound.play(club_sound(self.club))
        if self.shot.overswung and self.shot.overswing > 0.03:
            sound.play("whoosh", 0.8)
            self.message = "Overswing! Extra yards, no idea where."
        elif self.shot.event == "water":
            self.message = "In the water. Penalty stroke."
        elif self.shot.event == "trees":
            self.message = "Caught the timber."
        elif abs(err) < 0.02:
            self.message = "Pured it!"
        else:
            self.message = ""

        self.state = FLY
        self.cam.frame([p.ball, self.shot.end], margin=48, min_span=95)

    def settle_shot(self):
        p = self.p
        p.ball = self.shot.end
        p.lie = self.shot.end_terrain
        if self.shot.event == "water":
            sound.play("splash")
        elif self.shot.event == "trees":
            sound.play("tree")
        elif p.lie == "sand":
            sound.play("sand")
        # Holed only if the roll engine actually captured the ball. It is the
        # one thing that knows whether the ball was inside the cup *and* slow
        # enough to drop, and it tests the closest approach of each step, so a
        # quick one cannot skip the hole. Anything looser here scores a chip-in
        # for a ball that raced past the cup and finished twenty yards away.
        if self.shot.holed:
            p.holed = True
            sound.play("holed")
            self.message = f"{p.name} holed it from off the green!"
        self.advance_turn()

    def enter_putting(self):
        p = self.p
        p.club_index = PUTTER_INDEX
        self.charging = False
        self.putt_power = 0.0
        self.preview = None
        self.aim_at_pin()
        if self.pin_dist() <= GIMME_YARDS:
            p.strokes += 1
            p.holed = True
            sound.play("holed", 0.7)
            self.message = f"{p.name}: gimme, that's good."
            self.advance_turn()
            return
        self.state = PUTT_AIM
        self.frame_green()

    def strike_putt(self):
        p = self.p
        if self.putt_power < 0.04:
            self.charging = False
            self.message = "Too soft to count -- try again."
            return
        self.charging = False
        self.shot_origin = p.ball
        self.shot_aim = p.aim
        self.putt = simulate_putt(
            self.hole,
            self.spec.green_friction,
            p.ball,
            p.aim,
            self.putt_power,
            self.rng,
            p.arch.putting,
        )
        p.strokes += 1
        p.trail.append(list(self.putt.path))
        self.anim_pts = [(q, 0.0) for q in self.putt.path]
        self.anim_roll = []
        self.anim_t = 0.0
        # A putt is all roll and already sampled in real time, so it plays
        # straight through at an even pace -- no easing, no second phase.
        self.anim_dur = self.flight_dur = max(0.5, len(self.putt.path) / 120.0 * 0.8)
        self.roll_dur = 0.0
        self.anim_ease = 1.0
        self.preview = None
        sound.play("putt")
        self.state = PUTT_ROLL

    def settle_putt(self):
        p = self.p
        if self.putt.holed:
            p.holed = True
            sound.play("holed")
            self.message = f"{p.name}: {score_name(p.strokes, self.hole.par)}"
        else:
            p.ball = self.putt.end
            p.lie = terrain_at(self.hole, p.ball)
            if self.putt.lipped:
                self.message = "Lipped out!"
            elif self.putt.burned:
                sound.play("lip", 0.8)
                self.message = "Burned the edge -- too much pace."
            else:
                self.message = ""
        self.advance_turn()

    # ------------------------------------------------------------------ turn order

    def next_to_play(self) -> int | None:
        """Whose shot it is, by the rules of golf.

        Everyone plays from the tee in honour order; after that the ball
        farthest from the hole is up.  In match play a hole ends the moment the
        opponent can no longer match the score already in the cup.
        """
        holed = [pl for pl in self.players if pl.holed]
        if holed and self.match_play:
            best = min(pl.strokes for pl in holed)
            for pl in self.players:
                if not pl.holed and pl.strokes >= best:
                    pl.conceded = True

        live = [i for i, pl in enumerate(self.players) if not (pl.holed or pl.conceded)]
        if not live:
            return None
        untee = [i for i in live if self.players[i].strokes == 0]
        if untee:
            return self.honor if self.honor in untee else untee[0]
        return max(live, key=lambda i: dist(self.players[i].ball, self.hole.pin))

    # ------------------------------------------------------------------ the opponent

    def cpu_reset(self):
        self.cpu_t = 0.0
        self.cpu_plan = None

    def cpu_step(self, dt: float):
        """Drive a CPU player.

        It goes through ``fire`` and ``strike_putt`` and nothing else -- the same
        two doors the keyboard uses.  The plan is worked out on the first frame
        of its turn so the HUD can show the club and the aim line while it stands
        over the ball, and only executed once it has taken its time about it.
        """
        p = self.p
        if self.cpu_plan is None:
            if self.state == AIM:
                ci, aim, power, err = CPU.pick_shot(self, self.cpu_rng)
                p.club_index, p.aim = ci, aim
                self.cpu_plan = ("shot", power, err)
            else:
                aim, power = CPU.pick_putt(self, self.cpu_rng)
                p.aim = aim
                # Setting the power now rather than at the strike means the
                # preview line on the green is the putt it is about to hit.
                self.putt_power = power
                self.cpu_plan = ("putt", power, 0.0)
            self.message = CPU.shot_note(self)

        self.cpu_t += dt
        if self.cpu_t < CPU.think_time(self.state):
            return
        kind, power, err = self.cpu_plan
        self.cpu_reset()
        if kind == "shot":
            self.fire(power, err)
        else:
            self.charging = False
            self.strike_putt()

    def advance_turn(self):
        nxt = self.next_to_play()
        if nxt is None:
            self.finish_hole()
            return
        self.turn = nxt
        self.cpu_reset()
        p = self.p
        self.aim_at_pin()
        if p.lie in ("green", "fringe"):
            self.enter_putting()
        else:
            self.auto_club()
            self.state = AIM
            self.frame_shot()

    # ------------------------------------------------------------------ hole / round

    def finish_hole(self):
        for pl in self.players:
            pl.scores.append(pl.strokes if pl.holed else pl.strokes + 1)

        best_rel = min(pl.scores[-1] - self.hole.par for pl in self.players)
        if best_rel <= -1:
            sound.play("cheer", 0.8)

        if self.match_play:
            a, b = self.players
            sa = a.scores[-1] if a.holed else 99
            sb = b.scores[-1] if b.holed else 99
            if sa < sb:
                self.match_up += 1
                self.honor = 0
                self.hole_note = f"{a.name} wins the hole"
            elif sb < sa:
                self.match_up -= 1
                self.honor = 1
                self.hole_note = f"{b.name} wins the hole"
            else:
                self.hole_note = "Hole halved"
            remaining = len(self.holes) - (self.hole_index + 1)
            if abs(self.match_up) > remaining:
                lead = abs(self.match_up)
                winner = self.players[0 if self.match_up > 0 else 1]
                self.match_result = (
                    f"{winner.name} wins {lead} & {remaining}"
                    if remaining
                    else f"{winner.name} wins {lead} UP"
                )
            elif remaining == 0:
                self.match_result = (
                    "Match halved"
                    if self.match_up == 0
                    else f"{self.players[0 if self.match_up > 0 else 1].name} wins 1 UP"
                )
        else:
            self.hole_note = ""
        self.state = HOLE_DONE

    def finish_round(self):
        par = sum(h.par for h in self.holes)
        yards = sum(h.yardage for h in self.holes)
        fmt = self.format_name
        for pl in self.players:
            # A match that closes out 5 & 4 leaves four holes unplayed. That is
            # not a round anybody can post: the total is not comparable with a
            # full one, and the row it wrote -- fourteen scores against eighteen
            # pars -- made `adjusted_gross` raise the moment the handicap page
            # tried to read it back.
            if len(pl.scores) < len(self.holes):
                continue
            store.record(
                self.spec.name,
                self.round_key,
                fmt,
                pl.name,
                sum(pl.scores),
                par,
                holes=len(self.holes),
                yards=yards,
                tee=self.tee_name,
                archetype=pl.arch.name,
                hole_scores=list(pl.scores),
                pars=[h.par for h in self.holes],
            )
        # A career round you actually played is a real round: it posts to the
        # leaderboard above like any other, *and* it goes on the tournament card.
        if self.career_round:
            total = sum(self.players[0].scores)
            self.ev_scores[self.career.name].append(total)
            self.ev_mine_played.append(total)
            self.ev_played += 1
            self.advance_event_round()
        self.state = CARD

    # ------------------------------------------------------------------ update

    def update(self, dt: float):
        self.hold_keys(dt)
        if self.state in PLAY_STATES:
            self.wind_t += dt

        # The opponent plays here rather than in a key handler, because it has no
        # keys. It can change the state -- a fired shot leaves AIM for FLY -- so
        # the chain below sees whatever it decided this frame.
        if self.state in (AIM, PUTT_AIM) and self.p.cpu:
            self.cpu_step(dt)

        if self.state == SWING:
            # The meter is brisk: timing it is the swing. A Bomber's runs away
            # from them, a Dinker's is the slowest in the field.
            speed = self.meter_speed()
            if self.meter_phase == "power":
                self.meter_value += speed * dt
                if self.meter_value >= OVERSWING:
                    self.meter_value = OVERSWING
                    self.meter_power = OVERSWING
                    self.meter_phase = "accuracy"
            elif self.meter_phase == "accuracy":
                self.meter_value -= speed * dt
                if self.meter_value <= -0.18:
                    self.fire(self.meter_power, -0.18)

        elif self.state in (FLY, PUTT_ROLL):
            self.anim_t += dt
            if self.state == FLY:
                pts = [self.shot_origin, self.shot.end]
                if dist(self.shot.end, self.hole.pin) < 130:
                    pts.append(self.hole.pin)
                self.cam.frame(pts, margin=48, min_span=95)
            if self.anim_t >= self.anim_dur:
                if self.state == FLY:
                    self.settle_shot()
                else:
                    self.settle_putt()

        elif self.state == PUTT_AIM:
            if self.charging:
                keys = pygame.key.get_pressed()
                # Shift halves the charge rate: delicate putts need a slow hand.
                fine = 0.45 if (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]) else 1.0
                self.putt_power = min(1.0, self.putt_power + dt * fine / PUTT_CHARGE_TIME)
            self.preview = simulate_putt(
                self.hole,
                self.spec.green_friction,
                self.p.ball,
                self.p.aim,
                max(0.04, self.putt_power),
            )
            self.frame_green()

        elif self.state == AIM:
            self.frame_shot()

        self.cam.update(dt)

    def flight_frac(self) -> float:
        """How much of the flight has been drawn, easing included."""
        u = min(1.0, self.anim_t / max(1e-6, self.flight_dur))
        return 1.0 - (1.0 - u) ** self.anim_ease

    def anim_point(self) -> tuple[Vec, float]:
        if not self.anim_pts:
            return self.p.ball, 0.0
        if self.anim_t < self.flight_dur or not self.anim_roll:
            return self._along(self.anim_pts, self.flight_frac())
        u = min(1.0, (self.anim_t - self.flight_dur) / max(1e-6, self.roll_dur))
        return self._along(self.anim_roll, u)

    @staticmethod
    def _along(pts: list[tuple[Vec, float]], u: float) -> tuple[Vec, float]:
        idx = max(0.0, min(1.0, u)) * (len(pts) - 1)
        i = int(idx)
        j = min(len(pts) - 1, i + 1)
        t = idx - i
        (p0, h0), (p1, h1) = pts[i], pts[j]
        return (p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t), h0 + (h1 - h0) * t

    # ------------------------------------------------------------------ drawing

    def draw(self):
        if self.state == MENU:
            self.draw_menu()
            return
        if self.state == BOARD:
            self.draw_board()
            return
        if self.state == CAREER:
            self.draw_career()
            return
        if self.state == EVENT:
            self.draw_event()
            return
        if self.state == CARD:
            self.draw_card()
            return

        if self.view3d:
            self.draw_scene_3d()
        else:
            self.draw_scene_2d()

        self.draw_hud()
        if self.state == INTRO:
            self.draw_intro()
        elif self.state == HOLE_DONE:
            self.draw_hole_done()

    def putting_now(self) -> bool:
        return self.state in (PUTT_AIM, PUTT_ROLL) or (
            self.state in (AIM, SWING) and self.p.lie in ("green", "fringe")
        )

    def draw_scene_2d(self):
        detail = self.putting_now()
        R.draw_hole(self.screen, self.cam, self.hole, detail_green=detail)
        for pl in self.players:
            R.draw_trail(self.screen, self.cam, pl.trail)

        if self.state in (AIM, SWING):
            self.draw_aim_assist_2d()
        if self.state in (PUTT_AIM, PUTT_ROLL):
            R.circle(self.screen, self.cam, self.hole.pin, TWO_PUTT_RING, (215, 235, 205), 1)
        if self.state == PUTT_AIM:
            self.draw_putt_assist_2d()

        for i, pl in enumerate(self.players):
            if i == self.turn and self.state in (FLY, PUTT_ROLL):
                continue
            R.draw_ball(self.screen, self.cam, pl.ball, color=pl.color)
        if self.state in (FLY, PUTT_ROLL):
            pos, h = self.anim_point()
            R.draw_ball(self.screen, self.cam, pos, h, color=self.p.color)

    def draw_aim_assist_2d(self):
        line = self.shape_line(self.stock_carry())
        target = line[-1]
        # Dots the whole way down the shape the strike point buys, not just the
        # chord: they are the player's yardage ruler and have to reach the end.
        R.dotted_path(self.screen, self.cam, line, R.C_AIM)
        spread = self.club.curve * 0.55 * LIE_SPRAY.get(self.p.lie, 1.0) * self.p.arch.spray_for(
            self.club
        )
        R.circle(self.screen, self.cam, target, spread, (255, 255, 255), 1)
        sp = self.cam.w2s(target)
        txt = self.f_sm.render(f"{int(dist(self.p.ball, target))}y", True, R.C_TEXT)
        self.screen.blit(txt, (sp[0] + 8, sp[1] - 8))

    def draw_putt_assist_2d(self):
        if self.preview and len(self.preview.path) > 2:
            pts = self.preview.path
            col = PACE_COLORS.get(self.preview.pace, (255, 255, 255))
            for i in range(0, len(pts), max(1, len(pts) // 90)):
                pygame.draw.circle(self.screen, col, self.cam.w2s(pts[i]), 2)
            if not self.preview.holed:
                R.circle(self.screen, self.cam, self.preview.end, 0.35, col, 2)
        d = dir_from_deg(self.p.aim)
        far = (self.p.ball[0] + d[0] * 2.0, self.p.ball[1] + d[1] * 2.0)
        pygame.draw.line(
            self.screen, R.C_ACCENT, self.cam.w2s(self.p.ball), self.cam.w2s(far), 2
        )

    # ---- behind-the-ball

    def draw_scene_3d(self):
        putting = self.putting_now()
        if self.state == FLY and self.follow_cam:
            pos, h = self.anim_point()
            V.place_follow(self.cam3, pos, h + V.surface_z(self.hole, pos), self.shot_aim)
        elif self.state in (FLY, PUTT_ROLL):
            V.place_behind(
                self.cam3, self.shot_origin, self.shot_aim,
                putting=(self.state == PUTT_ROLL), flying=(self.state == FLY),
                # Slide out to the broadcast angle over the first half second
                # instead of cutting to it the instant the club moves.
                ease=self.anim_t / 0.5,
            )
        else:
            V.place_behind(self.cam3, self.p.ball, self.p.aim, putting=putting)

        V.draw_world(self.screen, self.cam3, self.hole, show_slope=putting)

        if self.state in (AIM, SWING):
            line = self.shape_line(self.stock_carry())
            target = line[-1]
            V.dotted_path(self.screen, self.cam3, line, R.C_AIM, hole=self.hole)
            spread = self.club.curve * 0.55 * LIE_SPRAY.get(
                self.p.lie, 1.0
            ) * self.p.arch.spray_for(self.club)
            V.fill_poly3(
                self.screen, self.cam3,
                V.surface_poly(self.hole, V.circle_poly(target, spread)),
                (255, 255, 255), width=2,
            )
        if putting:
            V.fill_poly3(
                self.screen, self.cam3,
                V.surface_poly(self.hole, V.circle_poly(self.hole.pin, TWO_PUTT_RING)),
                (215, 235, 205), width=1,
            )
        if self.state == PUTT_AIM and self.preview and len(self.preview.path) > 2:
            V.ground_line(
                self.screen, self.cam3, self.preview.path,
                PACE_COLORS.get(self.preview.pace, (255, 255, 255)), 2, hole=self.hole,
            )

        for i, pl in enumerate(self.players):
            if i == self.turn and self.state in (FLY, PUTT_ROLL):
                continue
            V.draw_ball(self.screen, self.cam3, pl.ball, color=pl.color,
                        ground=V.surface_z(self.hole, pl.ball))

        if self.state == FLY:
            V.draw_tracer(
                self.screen, self.cam3, self.shot.flight, self.shot.heights,
                int(self.flight_frac() * len(self.shot.flight)) + 1, hole=self.hole,
            )
        if self.state in (FLY, PUTT_ROLL):
            pos, h = self.anim_point()
            V.draw_ball(self.screen, self.cam3, pos, h, color=self.p.color,
                        ground=V.surface_z(self.hole, pos))

        # The keys are already on the hint line; all this has to say is which
        # camera you are looking through.
        self.text(f"cam: {SHOT_CAMS[self.cam_index]}", (16, self.viewport.bottom - 26),
                  self.f_sm, (206, 222, 208))

    # ------------------------------------------------------------------ HUD

    def draw_hud(self):
        h = self.hole
        p = self.p

        strip = pygame.Surface((W, 70), pygame.SRCALPHA)
        strip.fill((10, 22, 16, 165))
        self.screen.blit(strip, (0, 0))

        title = f"Hole {h.number}   Par {h.par}   {h.yardage}y"
        if h.name:
            title += f"   ·   {h.name}"
        self.text(f"{self.spec.name}  ·  {self.tee_name} tees", (16, 8), self.f_sm, R.C_DIM)
        self.text(title, (16, 28), self.f_lg, R.C_TEXT)
        self.text(self.status_line(), (W - 16, 8), self.f_sm, R.C_DIM, right=True)
        self.text(
            f"{p.name} ({p.arch.name})  ·  stroke {p.strokes + 1}",
            (W - 16, 28), self.f_lg, p.color, right=True,
        )

        hud = pygame.Rect(0, H - HUD_H, W, HUD_H)
        pygame.draw.rect(self.screen, R.C_PANEL, hud)
        pygame.draw.line(self.screen, (60, 90, 66), (0, hud.top), (W, hud.top), 2)

        y = hud.top + 14
        self.text("CLUB  [up/down]", (18, y), self.f_sm, R.C_DIM)
        self.text(self.club.name, (18, y + 20), self.f_lg, R.C_ACCENT)
        if self.club.putter:
            self.text("on the green", (18, y + 52), self.f_md, R.C_TEXT)
        else:
            # The stock number for this club and lie. The wind is deliberately
            # not folded in: reading it is the player's job.
            self.text(f"plays {int(self.stock_carry())}y", (18, y + 52), self.f_md, R.C_TEXT)

        x = 262
        pd = self.pin_dist()
        self.text("TO PIN", (x, y), self.f_sm, R.C_DIM)
        self.text(f"{pd * 3:.1f} ft" if pd < 12 else f"{int(pd)} y", (x, y + 20), self.f_lg,
                  R.C_TEXT)
        self.text(f"Lie: {LIE_NAMES.get(p.lie, p.lie)}", (x, y + 52), self.f_md, R.C_TEXT)

        self.draw_wind(pygame.Rect(432, y, 120, 96))

        if self.state in (SWING, AIM):
            self.draw_meter(pygame.Rect(590, y + 26, 460, 32))
            if not self.club.putter:
                self.draw_strike(pygame.Rect(1075, y + 22, 190, 76))
        elif self.state == PUTT_AIM:
            self.draw_putt_meter(pygame.Rect(590, y + 20, 460, 32))

        caps: list[tuple[str, tuple[int, int, int]]] = []
        if self.state == PUTT_AIM:
            caps.append((self.putt_read(), R.C_ACCENT))
            if self.preview:
                caps.append((PACE_HINTS.get(self.preview.pace, ""),
                             PACE_COLORS.get(self.preview.pace, R.C_TEXT)))
        if self.message:
            caps.append((self.message, R.C_ACCENT))
        self.caption(caps)

        self.text(self.controls_hint(), (W // 2, H - 26), self.f_sm, R.C_DIM, center=True)
        self.draw_minimap()

    def caption(self, lines: list[tuple[str, tuple[int, int, int]]]):
        """Centred lines on a dark plate just above the HUD strip.

        Everything the game says mid-shot goes here.  It used to be scattered:
        the message right-aligned into whatever the HUD's last panel was, the
        break read floating over the sky in a colour the sky swallowed.  One
        plate is legible over any terrain and gives the player one place to look.
        """
        surfs = [self.f_md.render(s, True, c) for s, c in lines if s]
        if not surfs:
            return
        w = max(s.get_width() for s in surfs) + 44
        h = sum(s.get_height() for s in surfs) + 14
        rect = pygame.Rect(W // 2 - w // 2, H - HUD_H - h - 14, w, h)
        plate = pygame.Surface(rect.size, pygame.SRCALPHA)
        plate.fill((8, 18, 13, 185))
        self.screen.blit(plate, rect.topleft)
        pygame.draw.rect(self.screen, (70, 110, 78), rect, 1, border_radius=6)
        yy = rect.y + 7
        for s in surfs:
            self.screen.blit(s, (rect.centerx - s.get_width() // 2, yy))
            yy += s.get_height()

    def draw_minimap(self):
        if self.state == INTRO:
            return  # the main view is already showing the whole hole
        aim_end = self.aim_target() if self.state in (AIM, SWING) else None
        balls = [(pl.ball, pl.color) for pl in [self.p] + [
            q for q in self.players if q is not self.p
        ]]
        mm = R.draw_minimap((150, 300), self.hole, balls, aim_end)
        self.screen.blit(mm, (W - 166, 84))

    def status_line(self) -> str:
        if self.match_play:
            a, b = self.players
            if self.match_up == 0:
                return f"Match: ALL SQUARE  ({a.name} v {b.name})"
            lead = self.players[0 if self.match_up > 0 else 1]
            return f"Match: {lead.name} {abs(self.match_up)} UP"
        if self.career_round:
            played = len(self.p.scores)
            rel = sum(self.p.scores) - sum(self.holes[i].par for i in range(played))
            rd = len(self.ev_scores[self.career.name]) + 1
            return (f"{self.event.name}  ·  R{rd} of {self.event.rounds}  ·  "
                    f"thru {played}  ·  {rel_str(rel)}")
        played = len(self.p.scores)
        rel = sum(self.p.scores) - sum(self.holes[i].par for i in range(played))
        return f"{self.round_key}  ·  thru {played}  ·  {rel_str(rel)}"

    def controls_hint(self) -> str:
        base = "V view   F shot cam   M mute   ESC menu"
        if self.p.cpu and self.state in (AIM, SWING, PUTT_AIM, FLY, PUTT_ROLL):
            return f"{self.p.name} to play   ·   {base}"
        if self.state == AIM:
            return (
                "left/right aim (Shift = fine)   up/down club   WASD strike (X centres)   "
                f"R re-aim   SPACE swing   {base}"
            )
        if self.state == SWING:
            return f"SPACE sets power, SPACE again at the white line   {base}"
        if self.state == PUTT_AIM:
            chip = "   C chip" if self.p.lie == "fringe" else ""
            return (
                "left/right aim   HOLD SPACE (Shift = slow) then release   "
                f"R re-aim{chip}   {base}"
            )
        if self.state == INTRO:
            return f"SPACE to play   {base}"
        return base

    def draw_wind(self, rect: pygame.Rect):
        wx, wy = self.wind
        speed = math.hypot(wx, wy)
        self.text("WIND", (rect.x, rect.y), self.f_sm, R.C_DIM)
        cx, cy = rect.x + 34, rect.y + 56
        pygame.draw.circle(self.screen, (54, 82, 60), (cx, cy), 28, 1)
        if speed > 0.2:
            ux, uy = wx / speed, wy / speed
            L = 12 + 14 * min(1.0, speed / 20.0)
            R.arrow(
                self.screen,
                (cx - ux * L, cy + uy * L),
                (cx + ux * L, cy - uy * L),
                R.C_ACCENT,
                4,
                head=11,
            )
        self.text(f"{speed:.0f}", (rect.x + 74, rect.y + 40), self.f_lg, R.C_TEXT)
        self.text("mph", (rect.x + 76, rect.y + 68), self.f_sm, R.C_DIM)
        # On a swirling hole the arrow is an average, not a promise -- say so,
        # or the player has no way to know the gust is coming.
        if self.hole.swirl > 0.5:
            self.text("SWIRLING", (rect.x, rect.y + 92), self.f_sm, (240, 150, 90))

    def draw_strike(self, rect: pygame.Rect):
        """The ball face, and where on it this swing is going to land.

        Centre is the plain strike. Off to the side is sidespin, which curves
        the ball; above or below the equator trades height for run.
        """
        sx, sy = self.p.strike
        self.text("STRIKE  [WASD]", (rect.x, rect.y), self.f_sm, R.C_DIM)
        cx, cy = rect.x + 26, rect.y + 48
        r = 22
        pygame.draw.circle(self.screen, (240, 244, 238), (cx, cy), r)
        pygame.draw.circle(self.screen, (120, 140, 122), (cx, cy), r, 1)
        pygame.draw.line(self.screen, (196, 208, 196), (cx - r, cy), (cx + r, cy), 1)
        pygame.draw.line(self.screen, (196, 208, 196), (cx, cy - r), (cx, cy + r), 1)
        dot = (cx + sx * (r - 5), cy - sy * (r - 5))
        pygame.draw.circle(self.screen, (206, 60, 56), dot, 5)

        side = "fade" if sx > 0.1 else "draw" if sx < -0.1 else "straight"
        vert = "topspin" if sy > 0.1 else "backspin" if sy < -0.1 else "flush"
        col = R.C_TEXT if side == "straight" and vert == "flush" else R.C_ACCENT
        self.text(side, (rect.x + 58, rect.y + 26), self.f_md, col)
        self.text(vert, (rect.x + 58, rect.y + 50), self.f_md, col)

    def draw_meter(self, rect: pygame.Rect):
        lo, hi = -0.18, OVERSWING

        def vx(v: float) -> float:
            return rect.x + (v - lo) / (hi - lo) * rect.width

        pygame.draw.rect(self.screen, (34, 52, 40), rect, border_radius=4)
        pygame.draw.rect(self.screen, (128, 52, 52),
                         pygame.Rect(rect.x, rect.y, vx(0.0) - rect.x, rect.height),
                         border_radius=4)
        # Past the top window is the overswing zone: more distance, no idea
        # where it goes. It starts where the penalty starts, not at 1.0, or the
        # meter would be drawing a deal the swing does not honour.
        over_x = vx(1.0 + self.power_snap())
        pygame.draw.rect(self.screen, (150, 44, 40),
                         pygame.Rect(over_x, rect.y, rect.right - over_x, rect.height),
                         border_radius=4)

        power = self.meter_value if self.meter_phase == "power" else self.meter_power
        if power > 0:
            col = ((110, 200, 110) if power < 0.75 else
                   (240, 190, 80) if power < 0.93 else
                   (232, 96, 80) if power <= 1.0 else (255, 60, 60))
            pygame.draw.rect(self.screen, col,
                             pygame.Rect(vx(0.0), rect.y + 4, vx(power) - vx(0.0),
                                         rect.height - 8), border_radius=3)
        pygame.draw.line(self.screen, (250, 250, 250),
                         (vx(0.0), rect.y - 6), (vx(0.0), rect.bottom + 6), 2)
        # The 100% "line" is as wide as the window that plays as 100%, because a
        # one-pixel line asks for timing the frame clock will not give.
        pygame.draw.rect(self.screen, (255, 240, 200),
                         pygame.Rect(vx(1.0), rect.y - 4, max(3.0, over_x - vx(1.0)),
                                     rect.height + 8))
        if self.meter_phase:
            nx = vx(self.meter_value)
            pygame.draw.line(self.screen, R.C_ACCENT, (nx, rect.y - 9), (nx, rect.bottom + 9), 3)
        pygame.draw.rect(self.screen, (80, 110, 86), rect, 1, border_radius=4)

        label = {"power": "POWER -- press SPACE",
                 "accuracy": "ACCURACY -- press SPACE at the white line"}.get(
            self.meter_phase, "SWING")
        self.text(label, (rect.x, rect.y - 24), self.f_sm, R.C_DIM)
        if power > 0:
            col = (255, 120, 110) if power > 1.0 else R.C_TEXT
            self.text(f"{int(power * 100)}%", (rect.right, rect.y - 24), self.f_sm, col,
                      right=True)
        self.text("hook", (rect.x + 2, rect.bottom + 8), self.f_sm, (216, 130, 130))
        self.text("slice", (vx(0.16), rect.bottom + 8), self.f_sm, (216, 130, 130))
        self.text("OVER", (over_x + 3, rect.bottom + 8), self.f_sm, (255, 120, 110))

    def draw_putt_meter(self, rect: pygame.Rect):
        self.text("PUTT POWER -- hold SPACE", (rect.x, rect.y - 24), self.f_sm, R.C_DIM)
        pygame.draw.rect(self.screen, (34, 52, 40), rect, border_radius=4)
        w = rect.width * self.putt_power
        if w > 2:
            pygame.draw.rect(
                self.screen,
                PACE_COLORS.get(self.preview.pace if self.preview else "", (110, 200, 110)),
                pygame.Rect(rect.x + 3, rect.y + 3, max(1, w - 6), rect.height - 6),
                border_radius=3,
            )
        pygame.draw.rect(self.screen, (80, 110, 86), rect, 1, border_radius=4)

        roll_ft = putt_distance(self.spec.green_friction, self.putt_power) * 3
        self.text(f"rolls {roll_ft:4.1f} ft", (rect.x, rect.bottom + 8), self.f_md, R.C_TEXT)
        self.text(f"pin {self.pin_dist() * 3:.1f} ft", (rect.right, rect.bottom + 8),
                  self.f_md, R.C_DIM, right=True)

        # The pace verdict is the whole putting game: it is what decides how
        # forgiving the stroke will be, so the player must see it before hitting.
        # The wordier half of it lives on the caption plate, where it is legible.
        if self.preview:
            pace = self.preview.pace
            self.text(pace.upper(), (rect.centerx, rect.bottom + 6), self.f_md,
                      PACE_COLORS.get(pace, R.C_ACCENT), center=True)

    def putt_read(self) -> str:
        """The break under the ball, in words -- the player's read."""
        gx, gy = green_gradient(self.hole, self.p.ball)
        d = dir_from_deg(self.p.aim)
        grade = math.hypot(gx, gy) * 100
        if grade <= 0.3:
            return "dead flat"
        lean = "breaks right" if gx * d[1] - gy * d[0] > 0 else "breaks left"
        up = "uphill" if gx * d[0] + gy * d[1] > 0 else "downhill"
        return f"{lean}  ·  {up} {grade:.1f}%"

    # ------------------------------------------------------------------ overlays

    def panel(self, rect: pygame.Rect, alpha=225):
        s = pygame.Surface(rect.size, pygame.SRCALPHA)
        s.fill((10, 22, 16, alpha))
        self.screen.blit(s, rect.topleft)
        pygame.draw.rect(self.screen, (70, 110, 78), rect, 2, border_radius=6)

    def draw_intro(self):
        h = self.hole
        tall = 200 if h.note else 172
        r = pygame.Rect(W // 2 - 300, 150, 600, tall)
        self.panel(r)
        head = f"HOLE {h.number}" + (f" - {h.name}" if h.name else "")
        self.text(head, (r.centerx, r.y + 18), self.f_lg if h.name else self.f_xl, R.C_TEXT,
                  center=True)
        self.text(f"Par {h.par}   ·   {h.yardage} yards", (r.centerx, r.y + 56), self.f_xl,
                  R.C_ACCENT, center=True)
        yy = r.y + 108
        if h.note:
            self.text(h.note, (r.centerx, yy), self.f_sm, R.C_TEXT, center=True)
            yy += 26
        swirl = ", swirling" if h.swirl > 0.5 else ""
        self.text(
            f"Wind {math.hypot(*h.wind):.0f} mph{swirl}   ·   Greens {self.green_speed_word()}",
            (r.centerx, yy), self.f_md, R.C_DIM, center=True)
        self.text(f"{self.p.name} has the honour  ·  SPACE to play", (r.centerx, yy + 30),
                  self.f_md, R.C_TEXT, center=True)

    def green_speed_word(self) -> str:
        f = self.spec.green_friction
        return "lightning" if f < 1.1 else "quick" if f < 1.45 else "slow"

    def draw_hole_done(self):
        r = pygame.Rect(W // 2 - 260, 160, 520, 210)
        self.panel(r)
        if self.match_play:
            self.text("HOLE " + str(self.hole.number), (r.centerx, r.y + 16), self.f_lg,
                      R.C_DIM, center=True)
            for i, pl in enumerate(self.players):
                s = pl.scores[-1]
                label = f"{pl.name}   {s}" + ("" if pl.holed else "  (conceded)")
                self.text(label, (r.centerx, r.y + 54 + i * 30), self.f_md, pl.color, center=True)
            self.text(self.hole_note, (r.centerx, r.y + 122), self.f_lg, R.C_ACCENT, center=True)
            state = ("ALL SQUARE" if self.match_up == 0 else
                     f"{self.players[0 if self.match_up > 0 else 1].name} "
                     f"{abs(self.match_up)} UP")
            self.text(self.match_result or state, (r.centerx, r.y + 156), self.f_md, R.C_TEXT,
                      center=True)
        else:
            pl = self.players[0]
            name = score_name(pl.scores[-1], self.hole.par)
            self.text(name, (r.centerx, r.y + 30), self.f_xl, R.C_ACCENT, center=True)
            self.text(f"{pl.scores[-1]} strokes on a par {self.hole.par}",
                      (r.centerx, r.y + 92), self.f_md, R.C_TEXT, center=True)
            if self.message:
                self.text(self.message, (r.centerx, r.y + 122), self.f_sm, R.C_DIM, center=True)
        last = self.hole_index >= len(self.holes) - 1 or self.match_result
        self.text("SPACE for the scorecard" if last else "SPACE for the next tee",
                  (r.centerx, r.y + 178), self.f_md, R.C_TEXT, center=True)

    # ------------------------------------------------------------------ menu

    MENU_LABELS = {
        "mode": "MODE",
        "opponent": "OPPONENT",
        "difficulty": "DIFFICULTY",
        "course": "COURSE",
        "tee": "TEES",
        "round": "HOLES",
        "format": "FORMAT",
        "view": "VIEW",
        "shotcam": "SHOT CAM",
        "name0": "PLAYER 1",
        "arch0": "P1 STYLE",
        "name1": "PLAYER 2",
        "arch1": "P2 STYLE",
    }

    def menu_value(self, row: str) -> str:
        spec = COURSES[self.course_index]
        if row == "mode":
            return self.mode
        if row == "opponent":
            return OPPONENTS[self.opp_index]
        if row == "difficulty":
            return self.level.name
        if row == "course":
            return spec.name
        if row == "tee":
            return self.tee_name
        if row == "round":
            return self.round_key
        if row == "format":
            return FORMATS[self.format_index]
        if row == "view":
            return VIEWS[self.view_index]
        if row == "shotcam":
            return SHOT_CAMS[self.cam_index]
        if row.startswith("name"):
            return self.names[int(row[-1])]
        return ARCHETYPES[self.arch_index[int(row[-1])]].name

    def draw_menu(self):
        self.screen.fill(R.C_BG)
        self.text("GOLF", (W // 2, 18), font(58, True), R.C_TEXT, center=True)

        left, right = self.menu_columns()
        for ci, (col, title, x) in enumerate(
            ((left, "THE ROUND", 60), (right, "THE PLAYERS", 660))
        ):
            self.text(title, (x, 96), self.f_sm, R.C_ACCENT if ci == self.menu_col else R.C_DIM)
            for i, row in enumerate(col):
                r = pygame.Rect(x, 120 + i * 50, 540, 42)
                sel = ci == self.menu_col and i == self.menu_row
                self.panel(r, alpha=195 if sel else 105)
                if sel:
                    pygame.draw.rect(self.screen, R.C_ACCENT, r, 2, border_radius=6)
                self.text(self.MENU_LABELS[row], (r.x + 16, r.y + 13), self.f_sm, R.C_DIM)
                value = self.menu_value(row)
                if row.startswith("name") and self.editing == int(row[-1]):
                    value += "_"
                editable = not row.startswith("name")
                self.text(value, (r.right - (34 if editable else 16), r.y + 9), self.f_lg,
                          R.C_ACCENT if sel else R.C_TEXT, right=True)
                if sel and editable:
                    self.text("<", (r.x + 130, r.y + 9), self.f_lg, R.C_ACCENT)
                    self.text(">", (r.right - 26, r.y + 9), self.f_lg, R.C_ACCENT)

        # A context card that explains whatever is selected. This is the part
        # that makes the menu navigable: you never have to guess what a row does.
        # It starts below the longest column -- a fixed top used to be buried by
        # the last row -- and it is only as tall as the lines it holds, because a
        # card of empty panel reads as a bug rather than as breathing room.
        lines = self.menu_help()
        top = 120 + max(len(left), len(right)) * 50 + 16
        info = pygame.Rect(60, top, 1140, min(H - 120 - top, 34 + len(lines) * 26))
        self.panel(info, alpha=130)
        for j, line in enumerate(lines):
            col = R.C_ACCENT if j == 0 else R.C_DIM
            self.text(line, (info.x + 22, info.y + 14 + j * 26), self.f_md if j == 0 else
                      self.f_sm, col)

        btn = pygame.Rect(W // 2 - 200, H - 96, 400, 46)
        self.panel(btn, alpha=210)
        pygame.draw.rect(self.screen, R.C_ACCENT, btn, 2, border_radius=6)
        self.text("SPACE  -  TEE IT UP", (btn.centerx, btn.y + 10), self.f_lg, R.C_ACCENT,
                  center=True)
        self.text("up/down row   TAB column   left/right change   ENTER edit name   "
                  "L leaderboard   ESC quit",
                  (W // 2, H - 36), self.f_sm, R.C_DIM, center=True)

    def menu_help(self) -> list[str]:
        row = self.menu_selected()
        spec = COURSES[self.course_index]
        _, lo, hi = ROUNDS[self.round_index]
        if row == "mode":
            if self.career_mode:
                car = CR.load()
                lines = ["Career",
                         "A season of tournaments against the tour, one event per course.",
                         "Play a round or simulate it; four-round events cut after two.",
                         "Rounds you actually play still count on the leaderboard and",
                         "towards your handicap.", ""]
                if car:
                    ev = CR.schedule()[min(car.next_event, len(CR.schedule()) - 1)]
                    lines.append(
                        f"in progress: {car.name}  ·  season {car.season}  ·  "
                        f"event {min(car.next_event + 1, len(CR.schedule()))} of "
                        f"{len(CR.schedule())}  ·  ${car.money:,}"
                    )
                    lines.append(f"next up: {ev.name} at {ev.course}")
                else:
                    lines.append("no career started -- SPACE opens the clubhouse")
                return lines
            if self.vs_cpu:
                return ["Match vs CPU",
                        "One hole at a time against an opponent that plays a real ball:",
                        "you watch every shot it hits, and it is playing the same physics",
                        "you are. Always match play -- holes won, not strokes."]
            return ["Exhibition",
                    "A one-off round. Stroke play against the card, or match play",
                    "against a friend on the same keyboard."]
        if row == "opponent":
            return ["Opponent",
                    "Who you are playing. Random picks a name that suits the",
                    "difficulty; anyone else on the list you can call out by name.",
                    "The name is who it is -- the difficulty is how well they play."]
        if row == "difficulty":
            lv = self.level
            lines = [f"{lv.name}"] + lv.blurb.split("\n") + [""]
            for other in tour.LEVELS:
                mark = " <" if other is lv else ""
                lines.append(f"  {other.name:12s} shoots about "
                             f"{CPU_PACE[other.name]} at Augusta{mark}")
            return lines
        if row == "course":
            holes = build_course(spec, self.tee_scale)
            par = sum(h.par for h in holes[lo:hi])
            yards = sum(h.yardage for h in holes[lo:hi])
            best = store.top(spec.name, self.round_key, 1)
            # One line of facts rather than four: the round, the tees and the
            # course name are already spelled out in the rows just above, so
            # repeating them here was noise the eye had to wade through.
            lines = [spec.name] + spec.blurb.split("\n")
            lines.append("")
            lines.append(
                f"par {par}  ·  {yards:,} yards  ·  greens {self.green_speed_word()}  ·  "
                f"{'real course' if spec.real else 'procedurally generated'}"
            )
            if best:
                lines.append(f"course record: {best[0]['name']} {best[0]['strokes']}")
            return lines
        if row == "tee":
            lines = ["Tee boxes", "A forward tee walks the tee up the fairway. The hazards and",
                     "the green do not move, so you face a different shot, not an easier hole.",
                     ""]
            for name, scale in TEES:
                holes = build_course(spec, scale)
                yards = sum(h.yardage for h in holes[lo:hi])
                mark = " <" if name == self.tee_name else ""
                lines.append(f"  {name:14s} {yards:5d} yards{mark}")
            return lines
        if row == "round":
            return ["Holes",
                    "Front 9, back 9, or the full eighteen. Every course has 18 holes.",
                    "Nine-hole rounds still post to the leaderboard and to your handicap."]
        if row == "format":
            if self.match_play:
                return ["Match play (1v1)",
                        "Scored by holes won, not strokes. The winner of the last hole has",
                        "the honour; after that whoever is farthest from the cup plays.",
                        "A hole ends as soon as your opponent cannot match the score in the",
                        "cup, and the match closes out when the lead exceeds the holes left."]
            return ["Stroke play",
                    "One player against the card. Your total posts to the leaderboard",
                    "and counts towards your handicap index."]
        if row == "view":
            if self.view3d:
                return ["Behind-ball view",
                        "A perspective camera behind the player looking down the aim line.",
                        "Shows the shot tracer with real elevation, and the green's slope",
                        "arrows in perspective. Toggle any time in play with V."]
            return ["Top-down view",
                    "The classic plan view, with a mini-map of the hole in the corner.",
                    "Toggle to the behind-ball camera any time in play with V."]
        if row == "shotcam":
            if self.follow_cam:
                return ["Follow ball",
                        "The camera goes with the ball, holding it in the middle of the",
                        "frame, which is the only way to see where a long drive is really",
                        "going. Behind-ball view only. Switch any time in play with F."]
            return ["Fixed camera",
                    "The camera stays at the tee and watches the shot leave, sliding back",
                    "and up as the ball climbs so the whole arc stays in frame.",
                    "Behind-ball view only. Switch any time in play with F."]
        if row.startswith("name"):
            i = int(row[-1])
            name = self.names[i].strip() or f"Player {i + 1}"
            lines = ["Player name", "ENTER to edit, then type. Scores post under this name.", ""]
            idx = HC.index_for(store.rounds_for(name))
            lines.append(
                f"Handicap index for {name}: {HC.format_index(idx)}" if idx is not None
                else f"{name} has no handicap index yet (3 rounds needed)."
            )
            return lines
        if not row.startswith("arch"):
            # Everything else falls to here, and used to fall into the archetype
            # branch below, where `int(row[-1])` on a row like "shotcam" took the
            # whole game down. A row nobody wrote a card for gets a bare heading.
            return [self.MENU_LABELS.get(row, row)]
        arch = ARCHETYPES[self.arch_index[int(row[-1])]]
        lines = [f"{arch.name}"] + arch.blurb.split("\n") + [""]
        lines.append(
            f"  carry x{arch.power:.2f}   dispersion x{arch.spray:.2f}   "
            f"tempo x{arch.tempo:.2f}"
        )
        lines.append(
            f"  short game x{arch.short_game:.2f}   putting x{arch.putting:.2f}   "
            f"recovery x{arch.recovery:.2f}"
        )
        lines.append("  (dispersion, short game and putting are error scales: lower is better)")
        return lines

    # ------------------------------------------------------------------ leaderboard

    def draw_board(self):
        self.screen.fill(R.C_BG)
        tabs = ("SCORES", "HANDICAPS")
        for i, t in enumerate(tabs):
            r = pygame.Rect(W // 2 - 200 + i * 200, 22, 190, 36)
            self.panel(r, alpha=200 if i == self.board_tab else 110)
            if i == self.board_tab:
                pygame.draw.rect(self.screen, R.C_ACCENT, r, 2, border_radius=6)
            self.text(t, (r.centerx, r.y + 8), self.f_md,
                      R.C_ACCENT if i == self.board_tab else R.C_DIM, center=True)
        if self.board_tab == 0:
            self.draw_board_scores()
        else:
            self.draw_board_handicaps()
        self.text("TAB switch page   left/right change   up/down round   SPACE back",
                  (W // 2, H - 40), self.f_sm, R.C_DIM, center=True)

    def draw_board_scores(self):
        spec = COURSES[self.course_index]
        self.text(f"{spec.name}   ·   {self.round_key}", (W // 2, 76), self.f_lg, R.C_ACCENT,
                  center=True)
        rows = store.top(spec.name, self.round_key, 12)
        if not rows:
            self.text("No rounds posted here yet.", (W // 2, 200), self.f_md, R.C_DIM,
                      center=True)
        for i, row in enumerate(rows):
            y = 150 + i * 34
            rel = row["strokes"] - row.get("par", 0)
            self.text(f"{i + 1:2d}", (W // 2 - 380, y), self.f_md, R.C_DIM)
            self.text(row["name"], (W // 2 - 320, y), self.f_md, R.C_TEXT)
            self.text(row.get("tee", ""), (W // 2 - 70, y), self.f_sm, R.C_DIM)
            self.text(row.get("archetype", ""), (W // 2 + 60, y), self.f_sm, R.C_DIM)
            self.text(str(row["strokes"]), (W // 2 + 240, y), self.f_md, R.C_TEXT, right=True)
            self.text(rel_str(rel), (W // 2 + 320, y), self.f_md,
                      R.C_ACCENT if rel <= 0 else R.C_DIM, right=True)
            self.text(row.get("date", ""), (W // 2 + 460, y), self.f_sm, R.C_DIM, right=True)

    def draw_board_handicaps(self):
        names = store.players()
        if not names:
            self.text("No rounds posted yet.", (W // 2, 200), self.f_md, R.C_DIM, center=True)
            return
        self.board_player %= len(names)
        name = names[self.board_player]
        rounds = store.rounds_for(name)
        summary = HC.summary(rounds)

        self.text(f"{name}", (W // 2, 76), self.f_xl, R.C_TEXT, center=True)
        idx = summary["index"]
        self.text(
            f"HANDICAP INDEX  {HC.format_index(idx)}",
            (W // 2, 130), font(34, True), R.C_ACCENT, center=True,
        )
        self.text(
            f"{summary['used']} of the lowest differentials from the last "
            f"{summary['considered']} rounds"
            if idx is not None
            else f"{len(rounds)} round(s) posted. A handicap needs 3.",
            (W // 2, 176), self.f_sm, R.C_DIM, center=True,
        )
        if summary["low_index"] is not None and idx is not None:
            self.text(f"Low index (365 days): {HC.format_index(summary['low_index'])}", (W // 2, 200),
                      self.f_sm, R.C_DIM, center=True)

        y = 240
        self.text("ROUND", (200, y), self.f_sm, R.C_DIM)
        self.text("SCORE", (640, y), self.f_sm, R.C_DIM, right=True)
        self.text("AGS", (720, y), self.f_sm, R.C_DIM, right=True)
        self.text("CR / SLOPE", (880, y), self.f_sm, R.C_DIM, right=True)
        self.text("DIFF", (980, y), self.f_sm, R.C_DIM, right=True)
        for i, row in enumerate(summary["rows"][:13]):
            yy = y + 28 + i * 28
            used = row["counted"]
            col = R.C_ACCENT if used else R.C_DIM
            label = f"{row['course']} · {row['round']} · {row['tee'] or '-'}"
            self.text(label[:44], (200, yy), self.f_sm, col)
            self.text(str(row["strokes"]), (640, yy), self.f_sm, col, right=True)
            self.text(str(row["ags"]), (720, yy), self.f_sm, col, right=True)
            self.text(f"{row['cr']:.1f} / {row['slope']:.0f}", (880, yy), self.f_sm, col,
                      right=True)
            self.text(f"{row['diff']:+.1f}", (980, yy), self.f_sm, col, right=True)
            if used:
                self.text("counted", (1060, yy), self.f_sm, R.C_ACCENT)
        self.text("left/right switch player", (W // 2, H - 66), self.f_sm, R.C_DIM, center=True)

    # ------------------------------------------------------------------ scorecard

    # ------------------------------------------------------------------ career

    def draw_career(self):
        """The clubhouse: the schedule on one tab, the money list on the other."""
        car = self.career
        sched = CR.schedule()
        self.screen.fill(R.C_BG)
        self.text("CAREER", (W // 2, 18), font(46, True), R.C_TEXT, center=True)
        self.text(
            f"{car.name}   ·   season {car.season}   ·   {car.arch}   ·   "
            f"${car.money:,}   ·   {car.points} pts   ·   #{car.rank()} on the list",
            (W // 2, 72), self.f_md, R.C_DIM, center=True,
        )
        for i, (label, tab) in enumerate((("SCHEDULE", 0), ("MONEY LIST", 1))):
            x = W // 2 - 160 + i * 200
            self.text(label, (x, 104), self.f_sm,
                      R.C_ACCENT if self.career_tab == tab else R.C_DIM, center=True)

        if self.career_tab == 0:
            self.draw_career_schedule(sched)
        else:
            self.draw_career_money()

        hint = ("R again to abandon this season" if self.confirm_wipe else
                "SPACE next event   ·   TAB tabs   ·   R abandon season   ·   ESC clubhouse")
        self.text(hint, (W // 2, H - 40), self.f_md,
                  (226, 140, 140) if self.confirm_wipe else R.C_TEXT, center=True)

    def draw_career_schedule(self, sched):
        car = self.career
        done = {r.event: r for r in car.results}
        x0, y = 150, 140
        cols = ((0, "EVENT"), (330, "COURSE"), (620, "ROUNDS"), (740, "RESULT"),
                (900, "MONEY"))
        for dx, label in cols:
            self.text(label, (x0 + dx, y), self.f_sm, R.C_DIM)
        for i, ev in enumerate(sched):
            ry = y + 30 + i * 42
            nxt = i == car.next_event
            r = done.get(ev.name)
            if nxt or i == self.career_row:
                box = pygame.Rect(x0 - 14, ry - 6, 1010, 38)
                self.panel(box, alpha=180 if nxt else 110)
                if i == self.career_row:
                    pygame.draw.rect(self.screen, R.C_ACCENT, box, 2, border_radius=6)
            col = R.C_TEXT if (nxt or r) else R.C_DIM
            self.text(ev.name + ("  *" if ev.major else ""), (x0, ry), self.f_md, col)
            self.text(ev.course, (x0 + 330, ry + 2), self.f_sm, R.C_DIM)
            self.text(str(ev.rounds), (x0 + 620, ry + 2), self.f_sm, R.C_DIM)
            if r is None:
                self.text("NEXT" if nxt else "—", (x0 + 740, ry + 2), self.f_sm,
                          R.C_ACCENT if nxt else R.C_DIM)
            elif r.cut:
                self.text("MC", (x0 + 740, ry), self.f_md, (208, 150, 150))
            else:
                self.text(f"{'T' if r.tied else ''}{r.pos}", (x0 + 740, ry), self.f_md,
                          (250, 206, 88) if r.pos == 1 else R.C_TEXT)
                self.text(f"{r.total - r.par:+d}", (x0 + 810, ry + 2), self.f_sm, R.C_DIM)
            if r and r.money:
                self.text(f"${r.money:,}", (x0 + 900, ry + 2), self.f_sm, R.C_DIM)

        if car.done():
            self.text(f"Season {car.season} complete — {car.wins} win(s), "
                      f"{car.cuts_made} cuts made",
                      (W // 2, y + 30 + len(sched) * 42 + 24), self.f_md, R.C_ACCENT,
                      center=True)

    def draw_career_money(self):
        car = self.career
        rows = car.standings()[:18]
        x0, y = 330, 140
        for dx, label in ((0, "#"), (60, "PLAYER"), (400, "MONEY"), (560, "POINTS")):
            self.text(label, (x0 + dx, y), self.f_sm, R.C_DIM)
        for i, (name, money, points) in enumerate(rows):
            ry = y + 30 + i * 32
            me = name == car.name
            if me:
                self.panel(pygame.Rect(x0 - 14, ry - 4, 680, 30), alpha=180)
            col = R.C_ACCENT if me else R.C_TEXT
            self.text(str(i + 1), (x0, ry), self.f_sm, R.C_DIM)
            self.text(name, (x0 + 60, ry), self.f_sm, col)
            self.text(f"${money:,}", (x0 + 400, ry), self.f_sm, col)
            self.text(str(points), (x0 + 560, ry), self.f_sm, R.C_DIM)

    def draw_event(self):
        ev, car = self.event, self.career
        self.screen.fill(R.C_BG)
        self.text(ev.name, (W // 2, 16), font(42, True), R.C_TEXT, center=True)
        played = len(self.ev_scores.get(car.name, []))
        head = (f"{ev.course}   ·   par {self.ev_par * ev.rounds}   ·   "
                f"${ev.purse:,}   ·   {len(self.ev_field) + 1} players")
        self.text(head, (W // 2, 66), self.f_md, R.C_DIM, center=True)
        if self.ev_done:
            sub = "FINAL"
        elif played >= ev.rounds:
            sub = "complete"
        else:
            sub = f"ROUND {played + 1} OF {ev.rounds}"
            if ev.cut_after and played == ev.cut_after:
                sub += "   ·   the cut has fallen"
        self.text(sub, (W // 2, 98), self.f_md, R.C_ACCENT, center=True)

        table = self.ev_table()
        rounds_in = max((len(s) for s in self.ev_scores.values()), default=0)
        x0, y = 250, 138
        self.text("POS", (x0, y), self.f_sm, R.C_DIM)
        self.text("PLAYER", (x0 + 70, y), self.f_sm, R.C_DIM)
        self.text("TO PAR", (x0 + 380, y), self.f_sm, R.C_DIM)
        for k in range(rounds_in):
            self.text(f"R{k + 1}", (x0 + 490 + k * 62, y), self.f_sm, R.C_DIM)
        self.text("TOTAL", (x0 + 490 + rounds_in * 62 + 20, y), self.f_sm, R.C_DIM)

        me = car.name
        shown = [r for r in table[:14]]
        if me not in [r[1] for r in shown]:
            mine = next((r for r in table if r[1] == me), None)
            if mine:
                shown = shown[:13] + [mine]
        for i, (pos, name, total, tied) in enumerate(shown):
            ry = y + 28 + i * 32
            mine = name == me
            if mine:
                self.panel(pygame.Rect(x0 - 14, ry - 4, 840, 30), alpha=190)
            col = R.C_ACCENT if mine else R.C_TEXT
            rel = total - self.ev_par * len(self.ev_scores[name])
            self.text(f"{'T' if tied else ''}{pos}", (x0, ry), self.f_sm, R.C_DIM)
            self.text(name, (x0 + 70, ry), self.f_sm, col)
            self.text(rel_str(rel), (x0 + 380, ry), self.f_sm,
                      (250, 206, 88) if rel < 0 else col)
            for k, s in enumerate(self.ev_scores[name]):
                self.text(str(s), (x0 + 490 + k * 62, ry), self.f_sm, R.C_DIM)
            self.text(str(total), (x0 + 490 + rounds_in * 62 + 20, ry), self.f_sm, col)

        if self.ev_cut:
            self.text(f"{len(self.ev_cut)} missed the cut", (W // 2, H - 116),
                      self.f_sm, R.C_DIM, center=True)

        if self.ev_done:
            res = car.results[-1]
            if res.cut:
                line = "Missed the cut."
            elif res.pos == 1:
                line = f"WINNER — ${res.money:,}"
            else:
                line = (f"Finished {'T' if res.tied else ''}{res.pos}"
                        f"   ·   ${res.money:,}   ·   {res.points} pts")
            self.text(line, (W // 2, H - 96), font(30, True), R.C_ACCENT, center=True)
            hint = "SPACE  -  back to the clubhouse"
        elif me in self.ev_cut:
            hint = "SPACE  -  back to the clubhouse"
        else:
            hint = "SPACE  play this round   ·   S  simulate it   ·   ESC clubhouse"
        self.text(hint, (W // 2, H - 44), self.f_md, R.C_TEXT, center=True)

    def draw_card(self):
        self.screen.fill(R.C_BG)
        self.text(self.spec.name, (W // 2, 20), self.f_xl, R.C_TEXT, center=True)
        self.text(
            f"{self.round_key}   ·   {self.format_name}   ·   {self.tee_name} tees",
            (W // 2, 74), self.f_md, R.C_DIM, center=True,
        )

        n = len(self.holes)
        blocks = [(0, 9)] if n == 9 else [(0, 9), (9, 18)]
        cw, x0 = 58, W // 2 - 350
        y = 130
        for bi, (lo, hi) in enumerate(blocks):
            sub = "OUT" if bi == 0 else "IN"
            self.text("HOLE", (x0, y), self.f_sm, R.C_DIM)
            for c, hole in enumerate(self.holes[lo:hi]):
                self.text(str(hole.number), (x0 + 110 + c * cw + cw // 2, y), self.f_md,
                          R.C_DIM, center=True)
            self.text(sub, (x0 + 110 + 9 * cw + cw // 2, y), self.f_md, R.C_ACCENT, center=True)

            self.text("PAR", (x0, y + 30), self.f_sm, R.C_DIM)
            for c, hole in enumerate(self.holes[lo:hi]):
                self.text(str(hole.par), (x0 + 110 + c * cw + cw // 2, y + 30), self.f_md,
                          R.C_DIM, center=True)
            self.text(str(sum(h.par for h in self.holes[lo:hi])),
                      (x0 + 110 + 9 * cw + cw // 2, y + 30), self.f_md, R.C_DIM, center=True)

            for pi, pl in enumerate(self.players):
                ry = y + 64 + pi * 38
                self.text(pl.name[:9], (x0, ry + 4), self.f_sm, pl.color)
                for c in range(lo, min(hi, len(pl.scores))):
                    cx = x0 + 110 + (c - lo) * cw + cw // 2
                    rel = pl.scores[c] - self.holes[c].par
                    # One ring per stroke under par and one box per stroke past
                    # bogey, the way a real card is marked: a birdie wears one
                    # circle, an eagle two, an albatross three.
                    for k in range(min(3, max(0, -rel))):
                        pygame.draw.circle(self.screen, (250, 206, 88), (cx, ry + 12),
                                           15 + k * 4, 2)
                    for k in range(min(3, max(0, rel - 1))):
                        s = 30 + k * 7
                        pygame.draw.rect(self.screen, (208, 150, 150),
                                         pygame.Rect(cx - s // 2, ry + 12 - s // 2, s, s), 2)
                    col = ((250, 206, 88) if rel < 0 else R.C_TEXT if rel <= 0
                           else (208, 150, 150))
                    self.text(str(pl.scores[c]), (cx, ry), self.f_lg, col, center=True)
                seg = pl.scores[lo:hi]
                if seg:
                    self.text(str(sum(seg)), (x0 + 110 + 9 * cw + cw // 2, ry), self.f_lg,
                              R.C_ACCENT, center=True)
            y += 64 + 38 * len(self.players) + 26

        par = sum(h.par for h in self.holes)
        yy = y + 6
        if self.match_play:
            self.text(self.match_result or "Match complete", (W // 2, yy), font(38, True),
                      R.C_ACCENT, center=True)
        else:
            pl = self.players[0]
            total = sum(pl.scores)
            self.text(f"TOTAL  {total}   ({rel_str(total - par)})", (W // 2, yy),
                      font(38, True), R.C_ACCENT, center=True)
            idx = HC.index_for(store.rounds_for(pl.name))
            note = ""
            best = store.best_for(self.spec.name, self.round_key, pl.name)
            if best is not None and total <= best:
                note = "New personal best!"
            elif best is not None:
                note = f"Your best here: {best}"
            if idx is not None:
                note += f"    Handicap index: {HC.format_index(idx)}"
            self.text(note, (W // 2, yy + 46), self.f_md, R.C_DIM, center=True)
        self.text("SPACE clubhouse   ·   L leaderboard", (W // 2, H - 40), self.f_md,
                  R.C_TEXT, center=True)

    # ------------------------------------------------------------------ text

    def text(self, s: str, pos, f: pygame.font.Font, color, center=False, right=False):
        surf = f.render(s, True, color)
        r = surf.get_rect()
        if center:
            r.midtop = pos
        elif right:
            r.topright = pos
        else:
            r.topleft = pos
        self.screen.blit(surf, r)


def main():
    pygame.init()
    pygame.display.set_caption("Golf")
    screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()
    sound.init()
    game = Game(screen)

    running = True
    while running:
        dt = min(0.05, clock.tick(FPS) / 1000.0)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif not game.handle(ev):
                running = False
        game.update(dt)
        game.draw()
        pygame.display.flip()
    pygame.quit()


if __name__ == "__main__":
    main()
