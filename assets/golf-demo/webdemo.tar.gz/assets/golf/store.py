"""Persistent leaderboard.

One flat JSON file of completed rounds in the user's home directory, so scores
survive between sessions without the game needing a database or a network.
Anything unreadable is treated as an empty board rather than crashing a round
that has already been played.
"""

from __future__ import annotations

import datetime as _dt
import json
from pathlib import Path

PATH = Path.home() / ".golf_game" / "leaderboard.json"


def _load() -> list[dict]:
    try:
        data = json.loads(PATH.read_text())
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def record(
    course: str,
    round_key: str,
    fmt: str,
    name: str,
    strokes: int,
    par: int,
    *,
    holes: int = 18,
    yards: int = 0,
    tee: str = "",
    archetype: str = "",
    hole_scores: list[int] | None = None,
    pars: list[int] | None = None,
) -> None:
    """Post a completed round.

    The extra fields exist for the handicap page: the World Handicap System
    needs the hole-by-hole scores (to cap each hole at net double bogey) and the
    length played (to estimate a course rating), not just the total.
    """
    rows = _load()
    rows.append(
        {
            "course": course,
            "round": round_key,
            "format": fmt,
            "name": name.strip() or "Guest",
            "strokes": strokes,
            "par": par,
            "holes": holes,
            "yards": yards,
            "tee": tee,
            "archetype": archetype,
            "hole_scores": hole_scores or [],
            "pars": pars or [],
            "date": _dt.date.today().isoformat(),
        }
    )
    try:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        PATH.write_text(json.dumps(rows, indent=1))
    except OSError:
        pass  # a leaderboard is not worth losing a round over


def rounds_for(name: str) -> list[dict]:
    """Every round a player has posted, newest first -- the handicap record."""
    rows = [r for r in _load() if r.get("name") == name]
    rows.sort(key=lambda r: r.get("date", ""), reverse=True)
    return rows


def players() -> list[str]:
    seen: dict[str, int] = {}
    for r in _load():
        seen[r.get("name", "Guest")] = seen.get(r.get("name", "Guest"), 0) + 1
    return sorted(seen, key=lambda n: -seen[n])


def top(course: str, round_key: str, limit: int = 10) -> list[dict]:
    rows = [r for r in _load() if r.get("course") == course and r.get("round") == round_key]
    rows.sort(key=lambda r: (r.get("strokes", 999), r.get("date", "")))
    return rows[:limit]


def best_for(course: str, round_key: str, name: str) -> int | None:
    scores = [
        r["strokes"]
        for r in _load()
        if r.get("course") == course and r.get("round") == round_key and r.get("name") == name
    ]
    return min(scores) if scores else None
