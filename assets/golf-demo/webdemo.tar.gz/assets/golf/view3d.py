"""A behind-the-ball test view.

This is not a 3D engine.  It is a pinhole camera sitting a few yards behind
the ball, looking down the aim line, projecting the same flat world the
top-down view draws.  Everything is still circles and corridors -- they just
get perspective now, and the ball has a real height, which is the whole point:
you can finally see the shot's elevation and watch the tracer climb and fall.

Toggle it with V, or set it as the default from the main menu.
"""

from __future__ import annotations

import math

import pygame

from . import render as R
from .course import TREE_HEIGHT, Hole, Vec, dist, green_height
from .physics import HOLE_R, deg_from_dir, dir_from_deg

NEAR = 0.6  # yards; nothing closer than this can be drawn

C_SKY_TOP = (96, 142, 196)
C_SKY_LOW = (188, 214, 234)
C_HAZE = (150, 178, 156)
C_TRUNK = (72, 54, 38)


class Camera3:
    """Pinhole camera: yaw around the world's up axis, plus a downward pitch."""

    def __init__(self, viewport: pygame.Rect, fov: float = 58.0):
        self.viewport = viewport
        self.focal = viewport.height / (2.0 * math.tan(math.radians(fov) / 2.0))
        self.eye: Vec = (0.0, 0.0)
        self.height = 7.0
        self.yaw = 0.0
        self.pitch = math.radians(9.0)

    def place(self, eye: Vec, height: float, yaw_deg: float, pitch_deg: float):
        self.eye = eye
        self.height = height
        self.yaw = math.radians(yaw_deg)
        self.pitch = math.radians(pitch_deg)

    def cam_space(self, p: Vec, z: float = 0.0) -> tuple[float, float, float]:
        """(right, depth, up) in camera axes."""
        fx, fy = math.sin(self.yaw), math.cos(self.yaw)
        rx, ry = fy, -fx
        dx, dy = p[0] - self.eye[0], p[1] - self.eye[1]
        f = dx * fx + dy * fy
        r = dx * rx + dy * ry
        u = z - self.height
        cp, sp = math.cos(self.pitch), math.sin(self.pitch)
        return r, f * cp - u * sp, f * sp + u * cp

    def project_cs(self, cs) -> tuple[float, float]:
        r, depth, up = cs
        k = self.focal / max(NEAR, depth)
        return self.viewport.centerx + r * k, self.viewport.centery - up * k

    def project(self, p: Vec, z: float = 0.0):
        cs = self.cam_space(p, z)
        if cs[1] < NEAR:
            return None
        return self.project_cs(cs)

    def depth(self, p: Vec) -> float:
        return self.cam_space(p)[1]

    @property
    def horizon_y(self) -> float:
        return self.viewport.centery - self.focal * math.tan(self.pitch)

    def px_per_yard(self, depth: float) -> float:
        return self.focal / max(NEAR, depth)


def place_behind(
    cam: Camera3,
    ball: Vec,
    aim_deg: float,
    *,
    putting: bool,
    flying: bool = False,
    ease: float = 1.0,
):
    """Put the camera behind the ball, or on the flight if ``flying``.

    The flight camera pulls back and lifts so the whole arc fits in frame.
    ``ease`` is how far into that move we are: cutting to it at impact was a
    jolt, so the shot camera slides out of the address one instead.
    """
    d = dir_from_deg(aim_deg)
    back = 4.5 if putting else 17.0
    height = 1.8 if putting else 7.5
    pitch = 6.5 if putting else 9.0
    if flying:
        e = max(0.0, min(1.0, ease))
        e = e * e * (3.0 - 2.0 * e)  # smoothstep, so the move starts and stops gently
        # Straight back and up the line -- no lateral step at all, so the camera
        # stays on the shot line the player aimed and the tracer is not skewed.
        back += (24.0 - back) * e
        height += (8.5 - height) * e
        pitch += (11.0 - pitch) * e
        eye = (ball[0] - d[0] * back, ball[1] - d[1] * back)
        yaw = aim_deg
    else:
        eye = (ball[0] - d[0] * back, ball[1] - d[1] * back)
        yaw = aim_deg
    cam.place(eye, height, yaw, pitch)


def place_follow(cam: Camera3, ball: Vec, z: float, aim_deg: float, back: float = 24.0):
    """Chase the ball: a camera trailing it down the line, ball centred.

    The fixed camera watches the shot leave; this one goes with it, which is
    the only way to see where a 300-yard drive is actually going to land.  The
    eye sits ``back`` yards behind the ball along the aim line and a little
    above it, and the pitch is solved so the ball holds the middle of the frame.
    """
    d = dir_from_deg(aim_deg)
    lift = 5.0
    height = max(2.5, z + lift)
    eye = (ball[0] - d[0] * back, ball[1] - d[1] * back)
    cam.place(eye, height, aim_deg, math.degrees(math.atan2(height - z, back)))


# --------------------------------------------------------------------------- elevation


def surface_z(hole: Hole, p: Vec) -> float:
    """Ground height at ``p``.

    Only the green and its collar have one -- everywhere else the game has no
    elevation model at all, so pretending otherwise would tilt flat fairways.
    """
    if dist(p, hole.green_center) < hole.green_r + 4.0:
        return green_height(hole, p)
    return 0.0


def surface_poly(hole: Hole, world: list[Vec]) -> list[tuple[Vec, float]]:
    """Lift a world outline onto the ground it sits on."""
    return [(p, surface_z(hole, p)) for p in world]


# --------------------------------------------------------------------------- clipping


def _clip_near(pts: list[tuple[float, float, float]]) -> list[tuple[float, float, float]]:
    """Sutherland-Hodgman against the near plane, in camera space."""
    out = []
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        ain, bin_ = a[1] >= NEAR, b[1] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[1]) / (b[1] - a[1])
            out.append(
                (a[0] + (b[0] - a[0]) * t, NEAR, a[2] + (b[2] - a[2]) * t)
            )
    return out


def fill_poly(surf, cam: Camera3, world: list[Vec], color, z: float = 0.0, width: int = 0):
    cs = _clip_near([cam.cam_space(p, z) for p in world])
    if len(cs) < 3:
        return
    pygame.draw.polygon(surf, color, [cam.project_cs(c) for c in cs], width)


def fill_poly3(surf, cam: Camera3, pts3: list[tuple[Vec, float]], color, width: int = 0):
    """Like :func:`fill_poly`, but every corner carries its own height."""
    cs = _clip_near([cam.cam_space(p, z) for p, z in pts3])
    if len(cs) < 3:
        return
    pygame.draw.polygon(surf, color, [cam.project_cs(c) for c in cs], width)


def circle_poly(c: Vec, r: float, n: int = 26) -> list[Vec]:
    return [
        (c[0] + math.cos(i / n * math.tau) * r, c[1] + math.sin(i / n * math.tau) * r)
        for i in range(n)
    ]


def fill_circle(surf, cam: Camera3, c: Vec, r: float, color, width: int = 0):
    fill_poly(surf, cam, circle_poly(c, r), color, width=width)


def ground_line(surf, cam: Camera3, pts: list[Vec], color, width=2, z=0.0, hole: Hole | None = None):
    """Draw a world path on the ground, splitting it where it crosses behind.

    Pass ``hole`` to lay the path on the terrain instead of on z=0, which is
    what makes a putt's preview line climb and fall with the green.
    """
    run: list[tuple[float, float]] = []
    for p in pts:
        sp = cam.project(p, z + (surface_z(hole, p) if hole else 0.0))
        if sp is None:
            if len(run) > 1:
                pygame.draw.lines(surf, color, False, run, width)
            run = []
        else:
            run.append(sp)
    if len(run) > 1:
        pygame.draw.lines(surf, color, False, run, width)


# --------------------------------------------------------------------------- scene


def draw_sky(surf, cam: Camera3):
    # Painted over the whole surface, not just the viewport, so the HUD strips
    # sit on sky and turf rather than on stale pixels.
    vp = surf.get_rect()
    horizon = max(vp.top, min(vp.bottom, cam.horizon_y))
    bands = 28
    top = vp.top
    for i in range(bands):
        t = i / (bands - 1)
        col = (
            int(C_SKY_TOP[0] + (C_SKY_LOW[0] - C_SKY_TOP[0]) * t),
            int(C_SKY_TOP[1] + (C_SKY_LOW[1] - C_SKY_TOP[1]) * t),
            int(C_SKY_TOP[2] + (C_SKY_LOW[2] - C_SKY_TOP[2]) * t),
        )
        y0 = top + (horizon - top) * i / bands
        y1 = top + (horizon - top) * (i + 1) / bands
        pygame.draw.rect(surf, col, pygame.Rect(vp.left, y0, vp.width, y1 - y0 + 1))
    pygame.draw.rect(
        surf, R.C_DEEP, pygame.Rect(vp.left, horizon, vp.width, vp.bottom - horizon)
    )
    # A soft treeline sitting on the horizon so the world has an edge.
    pygame.draw.rect(surf, C_HAZE, pygame.Rect(vp.left, horizon - 5, vp.width, 7))


def draw_world(surf, cam: Camera3, hole: Hole, *, show_slope: bool):
    draw_sky(surf, cam)
    fill_poly(surf, cam, R.corridor(hole.center, hole.rough_half), R.C_ROUGH)
    fill_poly(surf, cam, R.corridor(hole.center, hole.fairway_half), R.C_FAIRWAY)

    for b in hole.water_blobs:
        fill_poly(surf, cam, b.points, R.C_WATER)
    for b in hole.sand_blobs:
        fill_poly(surf, cam, b.points, R.C_SAND)

    draw_green_surface(surf, cam, hole)

    if show_slope:
        for tail, tip, strength in R.slope_arrows(hole):
            a = cam.project(tail, surface_z(hole, tail))
            b = cam.project(tip, surface_z(hole, tip))
            if a and b:
                shade = int(60 + 160 * strength)
                R.arrow(surf, a, b, (shade, 250, shade), 2)

    for c, r in sorted(hole.trees, key=lambda t: -cam.depth(t[0])):
        draw_tree(surf, cam, c, r)

    draw_flag(surf, cam, hole)


def draw_green_surface(surf, cam: Camera3, hole: Hole, rings: int = 5, sectors: int = 22):
    """The putting surface as a real surface, with its tilt and its bumps.

    The green is the one piece of terrain the game gives a height, so it is the
    one piece that can be drawn as anything other than flat.  Patches are
    painted far to near and shaded by how high they sit, which is what turns a
    flat disc into something you can read a break off from behind the ball.
    """
    gc, gr = hole.green_center, hole.green_r
    edge = gr + 4.0
    patches = []
    for i in range(rings + 1):
        r0 = edge * i / (rings + 1) if i else 0.0
        r1 = edge * (i + 1) / (rings + 1)
        base = R.C_FRINGE if r1 > gr else R.C_GREEN
        for j in range(sectors):
            a0, a1 = j / sectors * math.tau, (j + 1) / sectors * math.tau
            quad = [
                (gc[0] + math.cos(a) * rr, gc[1] + math.sin(a) * rr)
                for rr, a in ((r0, a0), (r0, a1), (r1, a1), (r1, a0))
            ]
            mid = ((r0 + r1) * 0.5, (a0 + a1) * 0.5)
            centre = (gc[0] + math.cos(mid[1]) * mid[0], gc[1] + math.sin(mid[1]) * mid[0])
            lift = green_height(hole, centre)
            shade = max(0.78, min(1.24, 1.0 + lift * 0.42))
            col = tuple(min(255, int(c * shade)) for c in base)
            patches.append((cam.depth(centre), surface_poly(hole, quad), col))
    for _, quad, col in sorted(patches, key=lambda q: -q[0]):
        fill_poly3(surf, cam, quad, col)


def draw_tree(surf, cam: Camera3, c: Vec, r: float):
    base = cam.project(c, 0.0)
    if base is None:
        return
    depth = cam.depth(c)
    scale = cam.px_per_yard(depth)
    trunk_top = cam.project(c, TREE_HEIGHT * 0.45)
    if trunk_top:
        pygame.draw.line(surf, C_TRUNK, base, trunk_top, max(2, int(r * 0.12 * scale)))
    for z, rad, col in (
        (TREE_HEIGHT * 0.62, r * 0.95, R.C_TREE),
        (TREE_HEIGHT * 0.86, r * 0.70, R.C_TREE_HI),
    ):
        p = cam.project(c, z)
        if p:
            pygame.draw.circle(surf, col, p, max(2.0, rad * scale))


def draw_flag(surf, cam: Camera3, hole: Hole):
    z = surface_z(hole, hole.pin)  # the cup sits on the green, not under it
    base = cam.project(hole.pin, z)
    top = cam.project(hole.pin, z + 2.4)
    if base is None or top is None:
        return
    scale = cam.px_per_yard(cam.depth(hole.pin))
    # True cup size, for the same reason the top-down view uses one: an
    # oversized hole makes every burned edge look like a bug.
    fill_poly3(surf, cam, surface_poly(hole, circle_poly(hole.pin, HOLE_R * 1.15)), (26, 34, 26))
    # The flag stays legible from 500 yards; a true-to-scale one would vanish.
    top = (top[0], min(top[1], base[1] - 16))
    pygame.draw.line(surf, (245, 245, 245), base, top, max(2, int(0.09 * scale)))
    flag = max(9.0, 1.1 * scale)
    pygame.draw.polygon(
        surf,
        hole.flag_color,
        [top, (top[0] + flag, top[1] + flag * 0.32), (top[0], top[1] + flag * 0.62)],
    )


def draw_tracer(
    surf, cam: Camera3, path: list[Vec], heights: list[float], upto: int, hole: Hole | None = None
):
    """The shot tracer: the arc, its shadow, and rungs joining the two."""
    n = min(upto, len(path))
    if n < 2:
        return

    def ground(i: int) -> float:
        return surface_z(hole, path[i]) if hole else 0.0

    air = []
    for i in range(n):
        sp = cam.project(path[i], ground(i) + heights[i])
        if sp:
            air.append((i, sp))
    ground_line(surf, cam, path[:n], (70, 96, 76), 2, hole=hole)
    for i, sp in air[:: max(1, n // 14)]:
        gp = cam.project(path[i], ground(i))
        if gp:
            pygame.draw.line(surf, (150, 170, 155), gp, sp, 1)
    if len(air) > 1:
        pygame.draw.lines(surf, (255, 246, 210), False, [sp for _, sp in air], 3)


def draw_ball(surf, cam: Camera3, pos: Vec, height: float = 0.0, color=R.C_BALL, ground: float = 0.0):
    """Draw the ball ``height`` yards above ``ground``, which the caller sets
    to the terrain height so a ball on a tilted green sits on the surface."""
    sp = cam.project(pos, ground + height)
    if sp is None:
        return
    depth = max(NEAR, cam.depth(pos))
    r = max(3.0, min(11.0, cam.px_per_yard(depth) * 0.08))
    shadow = cam.project(pos, ground)
    if shadow and height > 0.2:
        pygame.draw.ellipse(
            surf,
            (34, 62, 42),
            pygame.Rect(shadow[0] - r, shadow[1] - r * 0.45, r * 2, r * 0.9),
        )
    pygame.draw.circle(surf, color, sp, r)
    if r >= 5:
        pygame.draw.circle(surf, (60, 80, 62), sp, r, 1)


def dotted_path(
    surf, cam: Camera3, pts: list[Vec], color, spacing: float = 6.0, hole: Hole | None = None
):
    """Ground dots every ``spacing`` yards along a whole path.

    The curved cousin of :func:`draw_dotted`, and a distance ruler either way.
    Pass ``hole`` to lay the dots on the terrain rather than on z=0.
    """
    left = spacing
    for a, b in zip(pts, pts[1:]):
        seg = math.dist(a, b)
        if seg < 1e-9:
            continue
        at = 0.0
        while at + left <= seg:
            at += left
            left = spacing
            t = at / seg
            p = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            sp = cam.project(p, surface_z(hole, p) if hole else 0.0)
            if sp:
                pygame.draw.circle(
                    surf, color, sp, max(1.5, cam.px_per_yard(cam.depth(p)) * 0.18)
                )
        left -= seg - at


def draw_dotted(surf, cam: Camera3, a: Vec, b: Vec, color, spacing: float = 6.0):
    """Ground dots every ``spacing`` yards -- doubles as a distance ruler."""
    total = math.dist(a, b)
    if total < 1e-3:
        return
    n = max(2, int(total / spacing))
    for i in range(n + 1):
        t = i / n
        p = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        sp = cam.project(p)
        if sp:
            rad = max(1.5, cam.px_per_yard(cam.depth(p)) * 0.18)
            pygame.draw.circle(surf, color, sp, rad)
