"""The bag.

Every club is described by what the player actually feels: how far it flies,
how high (which drives wind sensitivity and whether trees are in play), how
much it runs out, how badly a mishit curves, and how fast its power meter
sweeps.  Longer clubs sweep faster, so they are genuinely harder to time.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Club:
    name: str
    short: str
    carry: float  # yards of carry at 100% power from a clean lie
    apex: float  # peak height in yards at 100% power
    roll: float  # run-out as a fraction of carry, on fairway
    curve: float  # how violently a mishit bends the ball
    tempo: float  # power-meter speed multiplier
    putter: bool = False

    @property
    def label(self) -> str:
        return self.name if self.putter else f"{self.name}  ~{int(self.carry)}y"


BAG: list[Club] = [
    Club("Driver", "Dr", 255, 28, 0.16, 16.0, 1.26),
    Club("3 Wood", "3W", 232, 26, 0.13, 14.0, 1.19),
    Club("5 Wood", "5W", 212, 27, 0.11, 13.0, 1.14),
    Club("4 Iron", "4i", 195, 26, 0.10, 12.0, 1.10),
    Club("5 Iron", "5i", 182, 27, 0.09, 11.0, 1.06),
    Club("6 Iron", "6i", 170, 28, 0.08, 10.0, 1.03),
    Club("7 Iron", "7i", 158, 29, 0.06, 9.5, 1.00),
    Club("8 Iron", "8i", 146, 29, 0.05, 9.0, 0.98),
    Club("9 Iron", "9i", 134, 30, 0.04, 8.5, 0.95),
    Club("Pitching Wedge", "PW", 120, 30, 0.03, 8.0, 0.92),
    Club("Gap Wedge", "GW", 104, 30, 0.025, 7.5, 0.90),
    Club("Sand Wedge", "SW", 88, 29, 0.02, 7.0, 0.88),
    Club("Lob Wedge", "LW", 68, 28, 0.015, 6.5, 0.85),
    Club("Putter", "Pt", 0, 0, 0.0, 0.0, 0.70, putter=True),
]

PUTTER_INDEX = len(BAG) - 1


@dataclass(frozen=True)
class Archetype:
    """A player's game.

    Every multiplier is relative to Balanced, and the set is meant to be a
    trade, not an upgrade: length is paid for with dispersion and touch, and
    accuracy is paid for with yardage.  ``short_game`` and ``putting`` are
    error scales, so lower is better; the rest are gains, so higher is more.
    """

    name: str
    blurb: str
    power: float  # full-swing carry
    spray: float  # how far a mishit bends
    tempo: float  # power-meter speed -- faster is harder to time
    short_game: float  # dispersion on wedges and short irons
    putting: float  # putting error scale
    recovery: float  # power out of rough, sand and trees

    def spray_for(self, club: Club) -> float:
        """Dispersion scale, weighting the short game separately from the long."""
        return self.spray * (self.short_game if club.carry <= 135 else 1.0)


ARCHETYPES: list[Archetype] = [
    Archetype(
        "Balanced",
        "No weaknesses and no free yards. Every part of the bag is average,\nwhich makes it the honest baseline.",
        power=1.00, spray=1.00, tempo=1.00, short_game=1.00, putting=1.00, recovery=1.00,
    ),
    Archetype(
        "Bomber",
        "Overpowers a course: about 9% more carry and enough strength to gouge\nit out of anything. Sprays it, and the meter runs away from you.",
        power=1.09, spray=1.34, tempo=1.22, short_game=1.24, putting=1.22, recovery=1.10,
    ),
    Archetype(
        "Dinker",
        "Short but never crooked, with the slowest meter, a superb short game\nand the best putter of the three. Expect a lot of long irons.",
        power=0.905, spray=0.74, tempo=0.86, short_game=0.74, putting=0.80, recovery=0.94,
    ),
]

BALANCED = ARCHETYPES[0]


def suggest_club(distance_yards: float, lie_power: float, power: float = 1.0) -> int:
    """Index of the club whose full swing best covers ``distance_yards``.

    Picking the club that flies *just past* the target is what a real player
    does, so we look for the shortest club that still reaches.
    """
    best = 0
    for i, club in enumerate(BAG):
        if club.putter:
            continue
        if club.carry * power * lie_power * (1 + club.roll) >= distance_yards:
            best = i
    return best
