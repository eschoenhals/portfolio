"""Ball flight and roll.

Full swings are resolved analytically: we know the carry, the shape of the
curve and the wind drift up front, then sample a parabola so the animation has
something to follow.

Everything that happens *on the ground* goes through one stepped integrator,
``roll_ball``.  Putts obviously need it -- lip-outs, break and dying-at-the-hole
only come out of an honest simulation -- but so does the run-out of a full
shot, because an approach that lands on a tilted green should feed with the
slope exactly like a putt does.  Sharing the engine is what makes those two
agree, and it means a 7-iron can trundle in from off the green.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from .clubs import BALANCED, Archetype, Club
from .course import (
    LANDING_ROLL,
    LIE_POWER,
    LIE_SPRAY,
    TREE_HEIGHT,
    Hole,
    Vec,
    dist,
    green_gradient,
    nearest_dry,
    terrain_at,
    tree_escape_distance,
)

G = 10.7  # gravity in yards/s^2
HOLE_R = 0.118  # 4.25 inches, in yards
CAPTURE_SPEED = 1.9  # yd/s -- above this the ball just lips out
LIP_SPEED = 3.1
MAX_PUTT_YARDS = 32.0
OVERSWING = 1.16  # how far past 100% the power meter will travel
OVERSWING_MISS = 0.62  # the miss a full-blooded 116% lash earns
OVERSWING_MISS_MIN = 0.24  # ... and the one a hair past the line still earns

# Striking the ball off the middle of the face. The offsets are in [-1, 1]:
# +x is towards the toe (a slice), +y is above the equator (topspin).
SPIN_BEND = 0.17  # mishit-equivalent sideways curve at a full-width strike
SPIN_APEX = 0.28  # how much backspin balloons the flight
SPIN_CARRY = 0.06  # carry topspin buys, backspin gives back
SPIN_RUN = 0.90  # run-out topspin buys, backspin kills
NO_SPIN: tuple[float, float] = (0.0, 0.0)

# Rolling resistance in yards/s^2. Green and fringe are driven by the course's
# green speed instead; everything else is a property of the turf, not the mow.
TURF_FRICTION = {
    "tee": 3.2,
    "fairway": 3.2,
    "rough": 7.0,
    "deep": 14.0,
    "sand": 10.0,
    "trees": 12.0,
    "water": 9.0,
}
FAIRWAY_FRICTION = TURF_FRICTION["fairway"]


def surface_friction(green_friction: float, terrain: str) -> float:
    if terrain == "green":
        return green_friction
    if terrain == "fringe":
        return green_friction * 2.4
    return TURF_FRICTION.get(terrain, 7.0)


def dir_from_deg(deg: float) -> Vec:
    r = math.radians(deg)
    return math.sin(r), math.cos(r)


def deg_from_dir(v: Vec) -> float:
    return math.degrees(math.atan2(v[0], v[1]))


# --------------------------------------------------------------------------- the roll


@dataclass
class RollResult:
    path: list[Vec] = field(default_factory=list)
    end: Vec = (0.0, 0.0)
    holed: bool = False
    lipped: bool = False
    burned: bool = False  # crossed the cup too fast to be caught
    cup_speed: float = 0.0  # speed at the closest approach to the cup
    closest: float = 1e9  # how near the cup it got, in yards


def roll_ball(
    hole: Hole,
    green_friction: float,
    start: Vec,
    vel: tuple[float, float],
    *,
    max_steps: int = 2600,
) -> RollResult:
    """Roll a ball to a stop, or into the cup.

    Slope is only applied on the putting surface and its collar.  Elsewhere the
    game has no elevation model, so pretending otherwise would send balls
    wandering across flat fairways.
    """
    pos = (float(start[0]), float(start[1]))
    v = [float(vel[0]), float(vel[1])]
    res = RollResult(path=[pos])
    dt = 1.0 / 120.0
    # The ball meets the cup once per crossing. At lip speed a step is a fifth
    # of the hole wide, so testing every step inside the radius deflects the
    # ball eight or nine times over -- which can curl it into an orbit it never
    # leaves, and a putt that never comes to rest hangs the hole.
    in_cup = False

    for _ in range(max_steps):
        here = terrain_at(hole, pos)
        f = surface_friction(green_friction, here)
        grad = green_gradient(hole, pos) if here in ("green", "fringe") else (0.0, 0.0)

        sp = math.hypot(*v)
        if sp < 1e-5:
            break
        ax = -v[0] / sp * f - grad[0] * G
        ay = -v[1] / sp * f - grad[1] * G
        nvx, nvy = v[0] + ax * dt, v[1] + ay * dt
        # Friction must not reverse the ball; only slope may do that.
        if nvx * v[0] + nvy * v[1] < 0 and math.hypot(*grad) * G < f:
            nvx = nvy = 0.0
        npos = (pos[0] + nvx * dt, pos[1] + nvy * dt)

        near, cp = _closest_to_cup(pos, npos, hole.pin)
        if near < res.closest:
            res.closest = near
            res.cup_speed = math.hypot(nvx, nvy)
        if near >= HOLE_R:
            in_cup = False
        elif not in_cup:
            in_cup = True
            speed_now = math.hypot(nvx, nvy)
            if speed_now < CAPTURE_SPEED:
                res.path.append(cp)
                res.end = cp
                res.holed = True
                return res
            if speed_now < LIP_SPEED:
                # Caught the lip and spun out.
                res.lipped = True
                ang = math.atan2(nvy, nvx) + (0.9 if (nvx + nvy) > 0 else -0.9)
                sp2 = speed_now * 0.5
                nvx, nvy = math.cos(ang) * sp2, math.sin(ang) * sp2
                npos = cp
            else:
                # Too fast to be caught, so it crosses the cup, lands on the far
                # lip and is thrown a little off line and off pace. Without this
                # the ball rolls dead straight over the hole, which reads as the
                # cup not being there at all. It is still a miss.
                res.burned = True
                cup = hole.pin
                away = -1.0 if (nvx * (cup[1] - pos[1]) - nvy * (cup[0] - pos[0])) > 0 else 1.0
                ang = math.atan2(nvy, nvx) + away * 0.16 * (near / HOLE_R)
                sp2 = speed_now * 0.86
                nvx, nvy = math.cos(ang) * sp2, math.sin(ang) * sp2

        v = [nvx, nvy]
        pos = npos
        res.path.append(pos)
        if math.hypot(*v) < 0.06 and math.hypot(*grad) * G < f:
            break

    res.end = nearest_dry(hole, pos)
    return res


def _closest_to_cup(a: Vec, b: Vec, pin: Vec) -> tuple[float, Vec]:
    """Closest approach of one step to the cup, so fast balls cannot skip it."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    denom = dx * dx + dy * dy
    if denom < 1e-12:
        return dist(a, pin), a
    t = max(0.0, min(1.0, ((pin[0] - a[0]) * dx + (pin[1] - a[1]) * dy) / denom))
    cp = (a[0] + dx * t, a[1] + dy * t)
    return dist(cp, pin), cp


# --------------------------------------------------------------------------- full swings


@dataclass
class ShotResult:
    flight: list[Vec] = field(default_factory=list)
    heights: list[float] = field(default_factory=list)
    roll: list[Vec] = field(default_factory=list)
    end: Vec = (0.0, 0.0)
    end_terrain: str = "fairway"
    penalty: int = 0
    carry: float = 0.0
    total: float = 0.0
    event: str = ""  # "water" | "trees" | ""
    overswung: bool = False
    overswing: float = 0.0  # how far past 100% the meter got, 0..OVERSWING-1
    holed: bool = False


def spin_carry(spin: Vec) -> float:
    """Carry multiplier for a strike off the middle of the face.

    Topspin buys a few yards, backspin gives them back, and any sideways
    strike costs a little of both -- a curving ball flies shorter.
    """
    return 1.0 + SPIN_CARRY * spin[1] - 0.045 * abs(spin[0])


def expected_carry(
    club: Club, lie: str, arch: Archetype = BALANCED, spin: Vec = NO_SPIN
) -> float:
    """The stock carry for this club, lie and strike -- no wind, no mishit.

    Wind is deliberately *not* in here.  Folding the head/tail component into
    the number on the HUD handed the player the answer; reading the flag and
    playing for it is the game.  Wind still decides where the ball actually
    finishes, in :func:`simulate_shot`.
    """
    if club.putter:
        return 0.0
    lie_power = LIE_POWER.get(lie, 1.0)
    if lie in ("rough", "deep", "sand", "trees"):
        lie_power *= arch.recovery
    return max(5.0, club.carry * arch.power * lie_power * spin_carry(spin))


def spin_bend(
    club: Club, lie: str, spin: Vec, carry: float, arch: Archetype = BALANCED
) -> float:
    """Sideways yards the chosen strike point promises, mishits aside.

    Same expression :func:`simulate_shot` uses for ``bend``, so the shape the
    aim line draws is the shape a clean strike delivers.
    """
    spray = LIE_SPRAY.get(lie, 1.0) * arch.spray_for(club)
    return SPIN_BEND * spin[0] * club.curve * spray * (carry / 100.0) * 3.0


def shape_curve(
    start: Vec, aim_deg: float, carry: float, bend: float, steps: int = 14
) -> list[Vec]:
    """Ground track of a shot with this much shape on it, for the aim line."""
    fdir = dir_from_deg(aim_deg)
    perp = (fdir[1], -fdir[0])
    out = []
    for i in range(steps + 1):
        t = i / steps
        along, lateral = carry * t, bend * t * t
        out.append(
            (
                start[0] + fdir[0] * along + perp[0] * lateral,
                start[1] + fdir[1] * along + perp[1] * lateral,
            )
        )
    return out


def check_back(club: Club, spin: Vec, terrain: str) -> float:
    """Yards a heavily cut shot walks *back* after it pitches.

    A wedge struck low on the face lands, checks, and comes back down the
    slope; the run-out multiplier alone can only ever stop the ball, never
    return it.  A long iron cannot generate this no matter where you strike it,
    so the bite is scaled by loft, and only receptive ground accepts it.
    """
    back = max(0.0, -spin[1])
    bite = max(0.0, 1.0 - club.carry / 200.0)
    if back < 0.25 or bite <= 0.0 or terrain not in ("green", "fringe"):
        return 0.0
    return 13.0 * (back - 0.20) * bite * (1.0 if terrain == "green" else 0.55)


def gust(hole: Hole, rng: random.Random) -> Vec:
    """The wind this particular shot gets.

    ``hole.wind`` is the day's wind here; ``hole.swirl`` is how much the hole's
    shelter and funnelling move it about while the ball is in the air.  On a
    swirling hole the arrow on the HUD is a hint rather than a promise, which
    is the whole point of Golden Bell.
    """
    speed = math.hypot(*hole.wind)
    if hole.swirl <= 0.0 or speed < 0.2:
        return hole.wind
    ang = math.atan2(hole.wind[0], hole.wind[1]) + rng.gauss(0.0, hole.swirl * 0.85)
    speed = max(0.0, speed * rng.gauss(1.0, hole.swirl * 0.40))
    return (math.sin(ang) * speed, math.cos(ang) * speed)


def simulate_shot(
    hole: Hole,
    roll_mult: float,
    start: Vec,
    aim_deg: float,
    power: float,
    club: Club,
    lie: str,
    err: float,
    rng: random.Random,
    green_friction: float = 1.2,
    arch: Archetype = BALANCED,
    spin: Vec = NO_SPIN,
    wind: Vec | None = None,
) -> ShotResult:
    """Resolve one full swing.

    ``err`` is the accuracy-meter miss in roughly [-0.18, 0.4]; negative is a
    hook, positive a slice.  It both bends the ball and, because a mishit is
    also a fat or thin strike, costs a little distance.

    ``power`` above 1.0 is an overswing: real extra distance bought with a miss
    in a direction you do not get to choose, growing from nothing at exactly
    100% to unplayable at the top of the meter.

    ``spin`` is where on the face the ball was struck, and it composes with
    ``err`` rather than replacing it: sideways offset feeds the same ``bend``
    term a mishit does, vertical offset trades apex against carry and run.

    ``wind`` is the wind at the moment of the strike, which the game locks in
    from the arrow the player was watching.  Left out, the hole's own swirl
    picks one instead.
    """
    res = ShotResult()
    spray = LIE_SPRAY.get(lie, 1.0) * arch.spray_for(club)
    lie_power = LIE_POWER.get(lie, 1.0)
    if lie in ("rough", "deep", "sand", "trees"):
        lie_power *= arch.recovery

    # Strike quality comes from the player's own timing only. An overswing is
    # a full-blooded lash -- it goes further, it just goes somewhere else.
    strike = 1.0 - min(0.22, abs(err) * 0.55)
    pure = abs(err) < 0.02
    # Topping the meter out without spilling over is the best strike available.
    flush = 0.985 <= power <= 1.0
    if power > 1.0:
        over = min(OVERSWING, power) - 1.0
        power = 1.0 + over * 1.25
        # Crossing the line at all is a miss -- that is the deal the overswing
        # zone offers. How *big* a miss is the part that scales: a hair past
        # costs OVERSWING_MISS_MIN, the top of the meter costs nearly triple.
        past = over / (OVERSWING - 1.0)
        wild = OVERSWING_MISS_MIN + (OVERSWING_MISS - OVERSWING_MISS_MIN) * past**1.15
        err += rng.choice((-1.0, 1.0)) * wild
        res.overswung = True
        res.overswing = over
        pure = False

    carry = club.carry * arch.power * power * lie_power * strike * rng.uniform(0.985, 1.015)
    if pure:
        carry *= 1.02
    if flush:
        carry *= 1.015
    carry *= spin_carry(spin)
    carry = max(4.0, carry)

    # Backspin balloons the flight, topspin flattens it -- which also decides
    # how long the wind has to work on the ball, and whether trees are in play.
    apex = max(1.5, club.apex * (0.45 + 0.55 * power) * (1.0 - SPIN_APEX * spin[1]))

    # Wind: helps or hurts the carry, and pushes the ball sideways in
    # proportion to how long it hangs up there. It is the wind at the instant of
    # the strike, not the hole's average, so a swirling hole has to be timed.
    if wind is None:
        wind = gust(hole, rng)
    fdir = dir_from_deg(aim_deg + rng.uniform(-0.9, 0.9) * spray)
    perp = (fdir[1], -fdir[0])
    hang = apex / 26.0
    head = wind[0] * fdir[0] + wind[1] * fdir[1]
    carry = max(4.0, carry + head * hang * 0.9)
    cross = wind[0] * perp[0] + wind[1] * perp[1]
    drift = cross * hang * 0.95

    bend = (err + SPIN_BEND * spin[0]) * club.curve * spray * (carry / 100.0) * 3.0

    # A ball already sitting in the trees always gets a gap to punch through,
    # otherwise it would collide with its own tree and never escape.
    grace = tree_escape_distance(hole, start)

    steps = 46
    hit_tree = False
    for i in range(steps + 1):
        t = i / steps
        along = carry * t
        lateral = bend * t * t + drift * (t**1.7)
        p = (
            start[0] + fdir[0] * along + perp[0] * lateral,
            start[1] + fdir[1] * along + perp[1] * lateral,
        )
        h = 4.0 * apex * t * (1.0 - t)
        res.flight.append(p)
        res.heights.append(h)
        if i and along > grace and h < TREE_HEIGHT and any(
            dist(p, c) < r for c, r in hole.trees
        ):
            hit_tree = True
            break

    res.carry = dist(start, res.flight[-1])
    land = res.flight[-1]
    land_terrain = terrain_at(hole, land)

    if hit_tree:
        res.event = "trees"
        res.heights[-1] = 0.0
        res.end = nearest_dry(hole, land)
        res.end_terrain = terrain_at(hole, res.end)
        res.total = res.carry
        return res

    if land_terrain == "water":
        res.event = "water"
        res.penalty = 1
        res.end = _drop_point(hole, res.flight)
        res.end_terrain = terrain_at(hole, res.end)
        res.total = res.carry
        return res

    # Run-out. `run_ref` is how far the ball would chase on a fairway; the
    # landing surface then decides how much of that speed survives the bounce,
    # and the roll engine takes it from there -- including the green's slope.
    # Spin lives on in the run-out: topspin chases, backspin checks up.
    run_ref = (
        carry * club.roll * roll_mult * (0.55 + 0.75 * power)
        * max(0.08, 1.0 + SPIN_RUN * spin[1])
    )
    check = check_back(club, spin, land_terrain)
    if run_ref > 0.4 or check > 0.1:
        a = res.flight[-2]
        rd = (land[0] - a[0], land[1] - a[1])
        mag = math.hypot(*rd) or 1.0
        if check > 0.1:
            # The bite eats the forward hop and sends it back up the line, then
            # the roll engine takes over -- so it walks back with the slope.
            speed = -math.sqrt(2.0 * green_friction * check)
        else:
            keep = math.sqrt(
                max(0.0, LANDING_ROLL.get(land_terrain, 0.5))
                * surface_friction(green_friction, land_terrain)
                / FAIRWAY_FRICTION
            )
            speed = math.sqrt(2.0 * FAIRWAY_FRICTION * run_ref) * keep
        rr = roll_ball(
            hole, green_friction, land, (rd[0] / mag * speed, rd[1] / mag * speed)
        )
        res.roll = rr.path
        res.end = rr.end
        res.holed = rr.holed
        if terrain_at(hole, rr.end) == "water" or any(
            terrain_at(hole, q) == "water" for q in rr.path[-2:]
        ):
            res.event = "water"
            res.penalty = 1
            res.end = _drop_point(hole, rr.path)
    else:
        # Too soft to run anywhere, so the roll engine -- the only thing that
        # knows about the cup -- never sees this shot. A pitch that lands in the
        # hole and stays there is still holed.
        res.end = land
        res.holed = dist(land, hole.pin) < HOLE_R

    res.end = nearest_dry(hole, res.end)  # a ball never rests in a hazard
    res.end_terrain = terrain_at(hole, res.end)
    res.total = dist(start, res.end)
    return res


def _drop_point(hole: Hole, path: list[Vec]) -> Vec:
    """Where you play from after a water ball.

    Walk back up the line of flight to the last dry sample.  On a hole where
    the ball never touched dry land -- a forced carry, say -- fall back to the
    nearest playable ground to the entry point.
    """
    idx = -1
    for i, p in enumerate(path):
        if terrain_at(hole, p) == "water":
            break
        idx = i
    if idx < 0:
        return nearest_dry(hole, path[0])
    return nearest_dry(hole, path[idx])


# --------------------------------------------------------------------------- putting


@dataclass
class PuttResult:
    path: list[Vec] = field(default_factory=list)
    end: Vec = (0.0, 0.0)
    holed: bool = False
    lipped: bool = False
    burned: bool = False
    pace: str = ""  # "short" | "dead weight" | "firm" | "racing"


def max_putt_speed(friction: float) -> float:
    return math.sqrt(2.0 * friction * MAX_PUTT_YARDS)


def putt_distance(friction: float, power: float) -> float:
    """Flat-ground roll-out for a given power, in yards. Used by the HUD."""
    v = power * max_putt_speed(friction)
    return v * v / (2.0 * friction)


def pace_of(roll: RollResult, pin_dist: float) -> tuple[str, float]:
    """Classify a putt's pace and return the error multiplier it earns.

    This is the heart of the putting game.  Distance control is entirely the
    player's -- the power they charge is the power the ball gets.  What varies
    is *how forgiving* the stroke is, and that is decided by pace: a putt dying
    at the hole barely wanders, a putt rammed through it is a coin flip on
    line.  Real golf works this way, and it means every miss is traceable to a
    decision the player made rather than to a dice roll.
    """
    # "Did it get there" has to be judged on geometry, not on speed: the roll
    # loop stops the ball at 0.06 yd/s, so any speed-based test for a putt that
    # died short reads as "dead weight" and hands out the forgiving multiplier.
    travelled = dist(roll.path[0], roll.end)
    if roll.closest > 0.45 and travelled < pin_dist * 0.98:
        # Being short is its own punishment, so keep the line penalty mild.
        short_by = max(0.0, pin_dist - travelled)
        return "short", min(0.9, 0.25 + short_by / 4.0)
    s = roll.cup_speed
    if s < 1.0:
        return "dead weight", 0.16
    if s < 2.0:
        return "firm", 0.16 + (s - 1.0) * 0.62
    return "racing", min(1.9, 0.78 + (s - 2.0) * 0.55)


def simulate_putt(
    hole: Hole,
    friction: float,
    start: Vec,
    aim_deg: float,
    power: float,
    rng: random.Random | None = None,
    skill: float = 1.0,
) -> PuttResult:
    """Roll a putt.

    Called without ``rng`` this is the noiseless read the preview line draws.
    Called with one, the pace of that same read decides how much the stroke is
    allowed to wander -- see :func:`pace_of`.
    """
    speed = max(0.05, power) * max_putt_speed(friction)
    d = dir_from_deg(aim_deg)
    ideal = roll_ball(hole, friction, start, (d[0] * speed, d[1] * speed))
    pace, penalty = pace_of(ideal, dist(start, hole.pin))

    if rng is None:
        return PuttResult(
            path=ideal.path, end=ideal.end, holed=ideal.holed, lipped=ideal.lipped,
            burned=ideal.burned, pace=pace,
        )

    aim_sigma = (0.30 + 1.45 * penalty) * skill
    speed_sigma = (0.005 + 0.020 * penalty) * skill
    aim = aim_deg + rng.gauss(0.0, aim_sigma)
    v = speed * rng.gauss(1.0, speed_sigma)
    d = dir_from_deg(aim)
    real = roll_ball(hole, friction, start, (d[0] * v, d[1] * v))
    return PuttResult(
        path=real.path, end=real.end, holed=real.holed, lipped=real.lipped,
        burned=real.burned, pace=pace,
    )
