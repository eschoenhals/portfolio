"""Career mode: a season of tournaments against a simulated field.

Three things live here, in the order the game needs them.

**Scoring a field.**  A tournament field is scored, never played.  Sixty balls
through the physics engine would take minutes and nobody would watch it, so a
CPU in a tournament gets a card drawn from a distribution instead.  The one
rule that keeps this from feeling arbitrary is that the distribution is built
from the *real generated hole* -- its yardage against its par, the water that is
actually in play, how small the green actually is.  Nothing is authored per
hole, which is exactly why adding a course to the catalog adds a tournament
that scores sensibly without anyone writing scoring data for it.

**A season.**  One event per course, so the schedule grows on its own.  Events
are keyed by course *name*, never by index, for the same reason ``smoke_test``
looks courses up that way: inserting a course must not silently repoint an
event at a different venue.

**A save file.**  The same tolerant-JSON shape as :mod:`golf.store`: anything
unreadable is a fresh career rather than a crash, and a write that fails never
costs you the round you just played.
"""

from __future__ import annotations

import datetime as _dt
import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path

from .catalog import COURSES
from .course import Hole, dist
from .tour import ROSTER, find

PATH = Path.home() / ".golf_game" / "career.json"

# --------------------------------------------------------------------- scoring a hole

#: What a rating-0 tour player shoots on a reference-length hole of each par.
#: Par 5s are birdie holes at this level and par 3s are not, which is most of
#: why a tour scoring average sits a shade over par rather than well under it.
PAR_BASE = {3: 0.08, 4: 0.02, 5: -0.32}

#: The yardage each par is "meant" to be, and what a yard either side is worth.
#: Length hurts a short hole more than a long one -- 40 yards added to a par 3
#: changes the club by two, 40 added to a par 5 changes nothing but the lay-up.
PAR_REF = {3: 180.0, 4: 440.0, 5: 555.0}
PAR_SLOPE = {3: 0.0028, 4: 0.0022, 5: 0.0016}

#: Scores are drawn about the expected score with this spread, and the bad half
#: of the draw is stretched by ``SKEW``.  Golf is one-sided: there is a floor at
#: an eagle and no ceiling at all, so a symmetric bell hands a tour field as many
#: eagles as doubles.  Stretching only the positive tail is what puts the odd 7
#: on a card without making birdies rare.
#: The stretch is *cubic* so that it only bites in the far tail.  Scaling the
#: whole bad half instead turns every ordinary bogey into a bogey-and-a-bit,
#: which quietly costs the field a third of its birdies -- the shape came out at
#: 9% birdies against a real tour's 16%.  A disaster should be rare and large,
#: not a tax on every miss.
SCORE_SIGMA = 0.52
SCORE_SKEW = 0.055

#: Stretching the tail drags the mean up with it: E[z^3 | z>0] is about 0.80 for
#: a standard normal.  Taking that back off means ``difficulty`` keeps saying
#: what it claims to say -- the average score on the hole.
SCORE_BIAS = SCORE_SIGMA * SCORE_SKEW * 0.798

#: How much a player's whole day moves, on top of hole-by-hole noise.  Holes
#: drawn independently make a round far too predictable: eighteen coin flips
#: average out, so nobody ever shoots 64 and nobody ever shoots 78.  One draw
#: per round, applied to every hole in it, is what a hot or cold day actually is
#: -- and it is why the leaderboard has players running away with it rather than
#: everyone finishing within three of each other.
FORM_SIGMA = 1.50


def hole_difficulty(hole: Hole) -> float:
    """Strokes over par a rating-0 tour player averages on this hole.

    Derived from the built hole rather than authored, so procedural courses and
    any course added later are scored on the same terms as Augusta.
    """
    par = hole.par if hole.par in PAR_REF else 4
    d = PAR_BASE[par] + (hole.yardage - PAR_REF[par]) * PAR_SLOPE[par]

    # Water is the only hazard that costs a whole shot, and only when it is
    # somewhere the ball has to go: a pond behind the tee is scenery.
    wet = 0.0
    for centre, r in hole.water:
        near_pin = dist(centre, hole.pin) - r
        if near_pin < 45.0:
            wet += 0.25 * (1.0 - max(0.0, near_pin) / 45.0)
        elif min(dist(centre, c) - r for c in hole.center) < 30.0:
            wet += 0.06
    d += min(0.30, wet)

    # Sand and timber are half-shot-ish problems at worst, and they saturate:
    # the eighth bunker round a green does not make it harder than the fourth.
    d += min(0.14, 0.02 * len(hole.bunkers))
    d += min(0.10, 0.012 * sum(1 for c, r in hole.trees
                               if min(dist(c, q) for q in hole.center) < r + 25.0))

    # A small green is a hard green: it is the one number that decides whether a
    # good iron shot finishes on the putting surface or in the chipping area.
    d += (16.0 - hole.green_r) * 0.018

    return max(-0.55, min(0.95, d))


def hole_score(rng: random.Random, par: int, difficulty: float, skill: float) -> int:
    """One player's score on one hole.

    ``skill`` is strokes per hole better than the field, i.e. a
    :attr:`golf.tour.Pro.rating` divided by eighteen.
    """
    mu = par + difficulty - skill - SCORE_BIAS
    z = rng.gauss(0.0, 1.0)
    if z > 0:
        z += SCORE_SKEW * z * z * z
    score = int(round(mu + SCORE_SIGMA * z))
    return max(max(1, par - 3), min(par + 6, score))


def round_score(rng: random.Random, holes: list[Hole], rating: float) -> list[int]:
    """Eighteen holes for one player, as a card.

    The day's form is drawn once and spread across all eighteen holes, so a
    round hangs together the way a real one does.
    """
    skill = (rating + rng.gauss(0.0, FORM_SIGMA)) / 18.0
    return [hole_score(rng, h.par, hole_difficulty(h), skill) for h in holes]


def expected_round(holes: list[Hole], rating: float) -> float:
    """What that player averages round here -- used to sanity-check the model."""
    return sum(h.par + hole_difficulty(h) for h in holes) - rating


def simulate_round(
    rng: random.Random, holes: list[Hole], names: list[str]
) -> dict[str, int]:
    """One round of a tournament: a total for every player in the field."""
    return {n: sum(round_score(rng, holes, find(n).rating)) for n in names}


# --------------------------------------------------------------------- the schedule


@dataclass(frozen=True)
class Event:
    name: str
    course: str  # a CourseSpec name -- looked up by name, never by index
    rounds: int  # 1, 2 or 4
    purse: int
    field: int
    strength: float  # 0..1, how far up the roster the field is drawn from
    major: bool = False

    @property
    def cut_after(self) -> int:
        """The round the cut falls after, or 0 for an event that does not cut."""
        return 2 if self.rounds >= 4 else 0


#: Authored events, keyed by course name.  A course with no entry still gets a
#: tournament -- see :func:`schedule` -- so the catalog can grow without this
#: table having to keep up.
EVENTS: dict[str, Event] = {
    "Augusta National": Event(
        "The Masters", "Augusta National", 4, 20_000_000, 90, 1.00, major=True),
    "St Andrews Old": Event(
        "The Open Championship", "St Andrews Old", 4, 17_000_000, 96, 1.00, major=True),
    "Pinehurst No. 2": Event(
        "U.S. Open", "Pinehurst No. 2", 4, 21_500_000, 96, 1.00, major=True),
    "Old Town Club": Event(
        "Old Town Invitational", "Old Town Club", 2, 9_000_000, 64, 0.72),
    "Tobacco Road": Event(
        "Sandhills Classic", "Tobacco Road", 2, 8_200_000, 72, 0.60),
    "Pebble Pines": Event(
        "Pebble Pines Open", "Pebble Pines", 4, 9_500_000, 80, 0.65),
    "Highland Links": Event(
        "Highland Links Championship", "Highland Links", 2, 8_800_000, 72, 0.70),
    "Palm Cay": Event(
        "Palm Cay Classic", "Palm Cay", 1, 7_400_000, 64, 0.50),
}


def schedule() -> list[Event]:
    """The season, one event per course in the catalog.

    Courses without an authored event get a generated one rather than being
    left off the schedule, because the thing that must never happen is adding a
    course and finding you cannot play a tournament on it.
    """
    out = []
    for spec in COURSES:
        ev = EVENTS.get(spec.name)
        if ev is None:
            ev = Event(f"{spec.name} Open", spec.name, 2, 7_000_000, 64, 0.55)
        out.append(ev)
    return out


def event_for(course: str) -> Event | None:
    return next((e for e in schedule() if e.course == course), None)


def field_for(ev: Event, rng: random.Random) -> list[str]:
    """Who shows up.

    A major draws the whole top of the roster; a lesser event is weighted
    towards the players who need the money.  Either way the field is sampled
    without replacement, so nobody tees off twice.
    """
    n = min(ev.field, len(ROSTER)) - 1  # one seat is the player's
    weights = [
        math.exp(-((i / max(1.0, len(ROSTER) - 1.0)) ** 2) / max(0.05, ev.strength))
        for i in range(len(ROSTER))
    ]
    pool = list(range(len(ROSTER)))
    picked: list[str] = []
    for _ in range(max(0, n)):
        total = sum(weights[i] for i in pool)
        if total <= 0:
            break
        r, acc = rng.random() * total, 0.0
        for i in pool:
            acc += weights[i]
            if acc >= r:
                picked.append(ROSTER[i].name)
                pool.remove(i)
                break
    return picked


# --------------------------------------------------------------------- standings


#: Share of the purse by finishing position.  The real tables run to 65 places;
#: this is the shape of one -- a winner-takes-plenty curve -- and anything past
#: the end of it decays smoothly rather than falling to nothing.
PURSE_SHARE = [
    0.180, 0.109, 0.069, 0.049, 0.041, 0.036, 0.0335, 0.031, 0.029, 0.027,
    0.025, 0.023, 0.021, 0.020, 0.019, 0.018, 0.017, 0.016, 0.0155, 0.015,
]
POINTS = [500, 300, 190, 135, 110, 100, 90, 85, 80, 75]


def purse_share(pos: int) -> float:
    if pos <= len(PURSE_SHARE):
        return PURSE_SHARE[pos - 1]
    return PURSE_SHARE[-1] * (0.92 ** (pos - len(PURSE_SHARE)))


def points_for(pos: int, major: bool = False) -> int:
    base = POINTS[pos - 1] if pos <= len(POINTS) else max(1, int(75 * 0.93 ** (pos - 10)))
    return int(base * (1.5 if major else 1.0))


def rank(totals: dict[str, int]) -> list[tuple[int, str, int, bool]]:
    """(position, name, total, tied) sorted low score first, ties sharing a spot."""
    order = sorted(totals.items(), key=lambda kv: (kv[1], kv[0]))
    out: list[tuple[int, str, int, bool]] = []
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and order[j + 1][1] == order[i][1]:
            j += 1
        for k in range(i, j + 1):
            out.append((i + 1, order[k][0], order[k][1], j > i))
        i = j + 1
    return out


#: The real rule is "top 65 and ties", which works because a real field is about
#: 156.  Applied to a field the size of this roster it keeps everybody, so the
#: cut is taken as the same *proportion* instead -- otherwise the weekend of a
#: major has no teeth at all.
CUT_FRACTION = 0.45


def cut_size(field: int) -> int:
    return max(10, min(65, round(field * CUT_FRACTION)))


def cut_line(totals: dict[str, int], keep: int | None = None) -> int:
    """The score you have to beat to play the weekend -- top ``keep`` and ties."""
    scores = sorted(totals.values())
    if not scores:
        return 0
    if keep is None:
        keep = cut_size(len(scores))
    return scores[-1] if len(scores) <= keep else scores[keep - 1]


def money_for(ev: Event, pos: int, tied_with: int) -> int:
    """Prize money, with a tie splitting the places it covers evenly."""
    share = sum(purse_share(pos + k) for k in range(tied_with)) / tied_with
    return int(ev.purse * share)


# --------------------------------------------------------------------- the save file


@dataclass
class Result:
    event: str
    course: str
    pos: int = 0
    tied: bool = False
    total: int = 0
    par: int = 0
    money: int = 0
    points: int = 0
    cut: bool = False  # True means missed the cut
    played: int = 0  # rounds you actually played rather than simulated

    def as_dict(self) -> dict:
        return dict(vars(self))


@dataclass
class Career:
    name: str = "Player 1"
    arch: str = "Balanced"
    season: int = 1
    next_event: int = 0
    results: list[Result] = field(default_factory=list)
    rivals: dict[str, list[int]] = field(default_factory=dict)  # name -> [money, points]
    started: str = ""
    #: Seeds every field and every simulated score in the season.  Stored rather
    #: than derived so that leaving a tournament and coming back to it shows the
    #: same leaderboard instead of quietly re-drawing the world.
    seed: int = 1
    #: The tournament in progress, if there is one:
    #: ``{"event", "round", "played", "scores", "cut"}``.  Without this, walking
    #: away from a four-round major after Thursday throws Thursday away -- and
    #: an eighteen-hole round is an hour of somebody's evening.
    live: dict = field(default_factory=dict)

    # -- derived

    @property
    def money(self) -> int:
        return sum(r.money for r in self.results)

    @property
    def points(self) -> int:
        return sum(r.points for r in self.results)

    @property
    def wins(self) -> int:
        return sum(1 for r in self.results if r.pos == 1 and not r.cut)

    @property
    def cuts_made(self) -> int:
        return sum(1 for r in self.results if not r.cut)

    def done(self) -> bool:
        return self.next_event >= len(schedule())

    def standings(self) -> list[tuple[str, int, int]]:
        """The money list: (name, money, points), richest first, you included."""
        rows = [(n, m, p) for n, (m, p) in
                ((k, (v[0], v[1])) for k, v in self.rivals.items())]
        rows.append((self.name, self.money, self.points))
        rows.sort(key=lambda r: (-r[1], -r[2], r[0]))
        return rows

    def rank(self) -> int:
        return next(i + 1 for i, r in enumerate(self.standings()) if r[0] == self.name)

    def credit(self, name: str, money: int, points: int) -> None:
        row = self.rivals.setdefault(name, [0, 0])
        row[0] += money
        row[1] += points

    # -- persistence

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "arch": self.arch,
            "season": self.season,
            "next_event": self.next_event,
            "results": [r.as_dict() for r in self.results],
            "rivals": self.rivals,
            "started": self.started or _dt.date.today().isoformat(),
            "seed": self.seed,
            "live": self.live,
        }


def load() -> Career | None:
    """The career in progress, or None if there is not one.

    Anything unreadable is treated as "no career" rather than raising: a corrupt
    save should offer you a fresh season, not a traceback on the menu screen.
    """
    try:
        data = json.loads(PATH.read_text())
        if not isinstance(data, dict) or not data.get("name"):
            return None
        return Career(
            name=data.get("name", "Player 1"),
            arch=data.get("arch", "Balanced"),
            season=int(data.get("season", 1)),
            next_event=int(data.get("next_event", 0)),
            results=[Result(**r) for r in data.get("results", [])],
            rivals={k: [int(v[0]), int(v[1])] for k, v in data.get("rivals", {}).items()},
            started=data.get("started", ""),
            seed=int(data.get("seed", 1)),
            live=data.get("live") or {},
        )
    except (OSError, ValueError, TypeError, KeyError, IndexError):
        return None


def save(career: Career) -> None:
    try:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        PATH.write_text(json.dumps(career.as_dict(), indent=1))
    except OSError:
        pass  # a season is not worth losing the round you just played over


def erase() -> None:
    try:
        PATH.unlink()
    except OSError:
        pass


# --------------------------------------------------------------------- simulating you


#: A scratch amateur against a tour field.  Used only when there is nothing at
#: all to go on -- no handicap index and no round played in the event yet.
SCRATCH = -4.0


def player_rating(index: float | None) -> float:
    """Turn a handicap index into a tour rating, for rounds you choose to sim.

    A scratch amateur is about four shots a round worse than the tour's field
    average, and each stroke of handicap is worth about another one.  It means a
    simulated round is as good as you have actually been playing, which is the
    only honest way to skip a round in a career.
    """
    return SCRATCH if index is None else SCRATCH - index


def rating_from_scores(holes: list[Hole], totals: list[int]) -> float | None:
    """Your rating read straight off rounds you have already played here.

    The World Handicap System needs three rounds before it will give an index,
    which leaves the most common case in a career -- played Thursday, want to
    sim Friday -- with nothing but the scratch default.  But a round on this
    course against this field is the rating, by definition: it is what the field
    was expected to shoot minus what you actually did.
    """
    if not totals:
        return None
    return expected_round(holes, 0.0) - sum(totals) / len(totals)
