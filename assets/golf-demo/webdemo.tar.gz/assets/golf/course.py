"""Hole geometry, terrain and course construction.

A hole is a centreline walked out from the tee: each segment turns a little,
so doglegs fall out naturally.  Fairway and rough are corridors around that
line, and hazards are circles placed relative to it.  Everything is in yards,
with +y running "up" the hole from the tee.

Courses come in two flavours.  Procedural ones are described by a personality
(wind, firmness, green speed, how much water and timber they own) plus a seed,
so "Highland Links" is the same eighteen every time.  Real ones are authored
hole by hole with :class:`HoleSpec`, which is the same vocabulary the generator
uses -- a bend, a width, and a handful of hazards placed off the centreline.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from .shapes import MAX_WOBBLE, Blob, make_blob, make_hazard_blobs

Vec = tuple[float, float]

# Terrain keys used everywhere else in the game.
TERRAINS = ("tee", "fairway", "green", "fringe", "rough", "deep", "sand", "water", "trees")

# How much of a full swing survives each lie.
LIE_POWER = {
    "tee": 1.00,
    "fairway": 1.00,
    "green": 1.00,
    "fringe": 0.96,
    "rough": 0.82,
    "deep": 0.62,
    "sand": 0.66,
    "trees": 0.60,
    "water": 0.80,
}

# How wildly a lie amplifies a mishit.
LIE_SPRAY = {
    "tee": 1.0,
    "fairway": 1.0,
    "green": 1.0,
    "fringe": 1.05,
    "rough": 1.35,
    "deep": 1.9,
    "sand": 1.5,
    "trees": 1.5,
    "water": 1.2,
}

# How much the ball runs after it lands here.
LANDING_ROLL = {
    "tee": 1.0,
    "fairway": 1.0,
    "green": 0.55,
    "fringe": 0.7,
    "rough": 0.45,
    "deep": 0.2,
    "sand": 0.08,
    "trees": 0.15,
    "water": 0.0,
}

LIE_NAMES = {
    "tee": "Tee Box",
    "fairway": "Fairway",
    "green": "Green",
    "fringe": "Fringe",
    "rough": "Rough",
    "deep": "Deep Rough",
    "sand": "Bunker",
    "trees": "In the Trees",
    "water": "Water",
}

TREE_HEIGHT = 13.0  # yards; the ball must clear this to fly over timber


# --------------------------------------------------------------------------- authoring


@dataclass(frozen=True)
class GBunker:
    """Greenside sand. ``bearing`` is degrees off the approach line:
    0 is long, 180 is short, +90 is right of the green."""

    bearing: float
    gap: float = 2.0
    r: float = 8.0


@dataclass(frozen=True)
class FBunker:
    """Fairway sand at ``frac`` along the hole, ``side`` yards off centre."""

    frac: float
    side: float
    r: float = 9.0


@dataclass(frozen=True)
class Pond:
    frac: float
    side: float
    r: float = 22.0


@dataclass(frozen=True)
class FrontWater:
    """Creek or pond guarding the green, ``gap`` yards short of its edge."""

    gap: float = 8.0
    r: float = 20.0
    side: float = 0.0


@dataclass(frozen=True)
class CarryWater:
    """Water spanning the line between two points on the hole."""

    frac_a: float
    frac_b: float
    half: float = 22.0
    side: float = 0.0


@dataclass(frozen=True)
class Grove:
    """A stand of trees at ``frac`` along the hole, ``side`` yards off centre."""

    frac: float
    side: float
    r: float = 9.0


Hazard = GBunker | FBunker | Pond | FrontWater | CarryWater | Grove


@dataclass(frozen=True)
class HoleSpec:
    number: int
    name: str
    par: int
    yards: int
    bend: float = 0.0  # total dogleg in degrees, + turns right
    bend_at: float = 0.5  # where along the hole the turn happens
    fairway_half: float = 26.0
    green_r: float = 15.0
    slope_dir: float = 0.0  # bearing the green falls towards, degrees
    slope_grade: float = 0.02
    hazards: tuple[Hazard, ...] = ()
    note: str = ""
    swirl: float = 0.15  # how much this hole moves the day's wind about
    crown: float = 0.0  # yards of dome on the green -- a Pinehurst turtleback


#: Tee boxes, as a fraction of the full playing length. Forward tees walk the
#: tee up the centreline rather than shrinking the hole, so the hazards and the
#: green stay exactly where they are -- which is what moving up actually does.
TEES: list[tuple[str, float]] = [
    ("Championship", 1.000),
    ("Members", 0.925),
    ("Forward", 0.840),
]

FLAG_RED = (226, 72, 72)
FLAG_YELLOW = (250, 214, 60)


@dataclass(frozen=True)
class CourseSpec:
    name: str
    blurb: str
    seed: int
    wind_max: float  # mph
    roll_mult: float  # firmness of the turf
    green_friction: float  # yd/s^2 -- lower is a faster green
    slope_max: float  # steepest green grade
    water_chance: float = 0.3
    tree_density: float = 1.0
    bunkers: tuple[int, int] = (1, 3)  # greenside bunker count range
    dogleg: float = 0.55  # radians of total turn available
    fairway_half: float = 28.0
    scripted: tuple[HoleSpec, ...] | None = None
    real: bool = False
    flag_color: tuple[int, int, int] = FLAG_RED


@dataclass
class Hole:
    number: int
    par: int
    center: list[Vec]  # centreline, tee first
    fairway_half: float
    rough_half: float
    green_center: Vec
    green_r: float
    pin: Vec
    green_slope: Vec  # uphill gradient of the green's tilt plane
    bumps: list[tuple[Vec, float, float]]  # (centre, amplitude, sigma)
    bunkers: list[tuple[Vec, float]]
    water: list[tuple[Vec, float]]
    trees: list[tuple[Vec, float]]
    wind: Vec  # mph, world coordinates -- the day's average on this hole
    swirl: float = 0.0  # 0 = the arrow is the truth, 1 = Golden Bell
    yardage: int = 0
    name: str = ""
    note: str = ""
    flag_color: tuple[int, int, int] = FLAG_RED
    bounds: tuple[float, float, float, float] = field(default=(0, 0, 0, 0))
    # Irregular outlines derived from the circles above. The circles remain the
    # authoring vocabulary -- easy to place and reason about -- while these are
    # what the player actually sees and what `terrain_at` tests against.
    sand_blobs: list[Blob] = field(default_factory=list)
    water_blobs: list[Blob] = field(default_factory=list)

    @property
    def tee(self) -> Vec:
        return self.center[0]


# --------------------------------------------------------------------------- geometry


def dist(a: Vec, b: Vec) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def dist_to_segment(p: Vec, a: Vec, b: Vec) -> float:
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    denom = dx * dx + dy * dy
    if denom < 1e-9:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def dist_to_polyline(p: Vec, pts: list[Vec]) -> float:
    return min(dist_to_segment(p, pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def point_along(pts: list[Vec], frac: float) -> tuple[Vec, Vec]:
    """Point at ``frac`` of the way along the polyline, plus the unit heading."""
    lengths = [dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    total = sum(lengths)
    target = max(0.0, min(1.0, frac)) * total
    run = 0.0
    for i, seg in enumerate(lengths):
        if run + seg >= target or i == len(lengths) - 1:
            t = (target - run) / seg if seg > 1e-6 else 0.0
            a, b = pts[i], pts[i + 1]
            pos = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            heading = ((b[0] - a[0]) / seg, (b[1] - a[1]) / seg) if seg > 1e-6 else (0.0, 1.0)
            return pos, heading
        run += seg
    return pts[-1], (0.0, 1.0)


def polyline_length(pts: list[Vec]) -> float:
    return sum(dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def offset(p: Vec, heading: Vec, side: float, ahead: float = 0.0) -> Vec:
    """Step ``side`` yards right of the heading and ``ahead`` yards along it."""
    return (
        p[0] - heading[1] * side + heading[0] * ahead,
        p[1] + heading[0] * side + heading[1] * ahead,
    )


# --------------------------------------------------------------------------- terrain


def terrain_at(hole: Hole, p: Vec) -> str:
    for b in hole.water_blobs:
        if b.contains(p):
            return "water"
    for b in hole.sand_blobs:
        if b.contains(p):
            return "sand"
    dg = dist(p, hole.green_center)
    if dg < hole.green_r:
        return "green"
    if dg < hole.green_r + 4.0:
        return "fringe"
    for c, r in hole.trees:
        if dist(p, c) < r:
            return "trees"
    d = dist_to_polyline(p, hole.center)
    if d < hole.fairway_half:
        return "fairway"
    if d < hole.rough_half:
        return "rough"
    return "deep"


def nearest_dry(hole: Hole, p: Vec) -> Vec:
    """The closest spot to ``p`` that is not in a hazard -- i.e. the drop.

    Searching outward in rings and preferring the point nearest the pin gives
    the same answer a player would reach: get out of the water, no closer to
    the hole than you have to be.  Without this, a ball that finds a pond whose
    whole margin is wet would be dropped straight back into it, forever.
    """
    if terrain_at(hole, p) != "water":
        return p
    for radius in range(4, 120, 4):
        best: tuple[float, Vec] | None = None
        for k in range(24):
            a = k / 24 * math.tau
            q = (p[0] + math.cos(a) * radius, p[1] + math.sin(a) * radius)
            if terrain_at(hole, q) != "water":
                d = dist(q, hole.pin)
                if best is None or d < best[0]:
                    best = (d, q)
        if best is not None:
            return best[1]
    return hole.tee


def tree_escape_distance(hole: Hole, p: Vec) -> float:
    """How far a shot from ``p`` must travel before timber matters again.

    A ball resting among trees is not lodged in a trunk -- you can always find
    a gap and punch out.  Without this the ball would re-collide with the very
    tree it is sitting in, one yard into every escape attempt, and the hole
    would never end.
    """
    grace = 0.0
    for c, r in hole.trees:
        d = dist(p, c)
        if d < r + 1.0:
            grace = max(grace, (r - d) + r + 6.0)
    return min(grace, 42.0)


def green_height(hole: Hole, p: Vec) -> float:
    """Elevation of the putting surface at ``p``, in yards above its centre.

    The putting surface is the only ground the game gives a height to -- a tilt
    plane plus a couple of gaussians -- and this is the function
    :func:`green_gradient` differentiates, so the surface the behind-ball view
    draws is the surface the roll integrator rolls on.  (The gradient is capped
    to keep putts stoppable; the height is not, so a fierce bump reads a hair
    steeper on screen than it plays.)
    """
    gx, gy = hole.green_slope
    z = gx * (p[0] - hole.green_center[0]) + gy * (p[1] - hole.green_center[1])
    for (cx, cy), amp, sigma in hole.bumps:
        dx, dy = p[0] - cx, p[1] - cy
        z += amp * math.exp(-(dx * dx + dy * dy) / (2 * sigma * sigma))
    return z


def green_gradient(hole: Hole, p: Vec) -> Vec:
    """Uphill gradient of the putting surface at ``p`` (rise per unit run)."""
    gx, gy = hole.green_slope
    for (cx, cy), amp, sigma in hole.bumps:
        dx, dy = p[0] - cx, p[1] - cy
        r2 = dx * dx + dy * dy
        s2 = sigma * sigma
        f = amp * math.exp(-r2 / (2 * s2)) / s2
        gx -= f * dx
        gy -= f * dy
    mag = math.hypot(gx, gy)
    limit = 0.058  # keep the surface puttable: friction must beat gravity
    if mag > limit:
        gx, gy = gx / mag * limit, gy / mag * limit
    return gx, gy


# --------------------------------------------------------------------------- building


def _bent_centerline(length: float, bend_deg: float, bend_at: float, segs: int = 6) -> list[Vec]:
    """Walk out a centreline whose turn is concentrated around ``bend_at``."""
    weights = [
        math.exp(-(((i + 0.5) / segs - bend_at) ** 2) / (2 * 0.17**2)) for i in range(segs)
    ]
    wsum = sum(weights) or 1.0
    bend = math.radians(bend_deg)
    heading = -bend * 0.35  # start aimed into the turn, as a real tee shot is
    pts: list[Vec] = [(0.0, 0.0)]
    step = length / segs
    for i in range(segs):
        heading += bend * weights[i] / wsum
        x, y = pts[-1]
        pts.append((x + math.sin(heading) * step, y + math.cos(heading) * step))
    return pts


def _green_detail(hole: Hole, rng: random.Random, crown: float = 0.0) -> None:
    gc, gr = hole.green_center, hole.green_r
    if crown > 0.0:
        # A turtleback: one broad dome over the whole green, so a ball that
        # pitches anywhere but the middle is shrugged off towards the collar.
        # This is Pinehurst's entire defence, and the reason it needs no water.
        # Kept wide (sigma ~0.78r) so the gradient stays under the cap in
        # `green_gradient` -- a dome the ball cannot stop on is a hole that
        # never ends, not a hard hole.
        hole.bumps.append((gc, crown, gr * 0.78))
    for _ in range(rng.randint(1, 2)):
        ang = rng.uniform(0, math.tau)
        d = rng.uniform(0.0, gr * 0.7)
        hole.bumps.append(
            (
                (gc[0] + math.sin(ang) * d, gc[1] + math.cos(ang) * d),
                rng.uniform(-0.55, 0.55),
                rng.uniform(4.5, 8.0),
            )
        )
    ang = rng.uniform(0, math.tau)
    d = rng.uniform(0.0, gr * 0.55)
    hole.pin = (gc[0] + math.sin(ang) * d, gc[1] + math.cos(ang) * d)


#: A blob's lobes can push out to this multiple of its circle's radius, so
#: green clearance has to be computed against the lobes, not the circle.
BLOB_REACH = 1.0 + MAX_WOBBLE


def _shove_clear(gc: Vec, gr: float, circles: list[tuple[Vec, float]]) -> list[tuple[Vec, float]]:
    """Push each circle out until its blob cannot reach the putting surface.

    Shoving rather than dropping matters: a creek authored to guard a green sits
    exactly as close to it as it dares, so a drop rule silently deleted the
    feature the hole is famous for -- Rae's Creek in front of 13 was gone -- and
    the hole then played as an ordinary approach.  A yard or two further out
    costs the design nothing and keeps the water.
    """
    out = []
    for c, r in circles:
        d = dist(c, gc)
        need = gr + r * BLOB_REACH + 0.5
        if d < need:
            if d < 1e-6:
                continue  # dead concentric with the green: no direction to push
            k = need / d
            c = (gc[0] + (c[0] - gc[0]) * k, gc[1] + (c[1] - gc[1]) * k)
        out.append((c, r))
    return out


def _protect_green(hole: Hole) -> None:
    """Nothing may sit on the putting surface.

    ``terrain_at`` tests hazards before the green, so a stray shape would turn
    part of the green into water or sand.  Both get shoved back out to the
    collar they were meant to hug; only timber, which has no business near a
    green at all, gets dropped.
    """
    gc, gr = hole.green_center, hole.green_r
    hole.water = _shove_clear(gc, gr, hole.water)
    hole.bunkers = _shove_clear(gc, gr, hole.bunkers)
    hole.trees = [(c, r) for c, r in hole.trees if dist(c, gc) > gr + r + 4]


def _cluster(circles: list[tuple[Vec, float]]) -> list[list[tuple[Vec, float]]]:
    """Group circles that touch, so each pond or creek becomes one outline."""
    remaining = list(circles)
    groups: list[list[tuple[Vec, float]]] = []
    while remaining:
        run = [remaining.pop(0)]
        changed = True
        while changed:
            changed = False
            for cand in list(remaining):
                if any(dist(cand[0], c) < cand[1] + r for c, r in run):
                    run.append(cand)
                    remaining.remove(cand)
                    changed = True
        groups.append(run)
    return groups


def _shape_hazards(hole: Hole) -> None:
    """Turn the authored circles into the irregular shapes the player sees."""
    seed = hole.number * 7717 + 13
    hole.sand_blobs = [
        make_blob(
            c,
            r,
            seed + i * 31,
            lobes=3,
            roughness=0.20,
            squash=1.0 + (i % 3) * 0.35,
            angle=(i * 1.1) % math.pi,
        )
        for i, (c, r) in enumerate(hole.bunkers)
    ]
    hole.water_blobs = []
    for gi, group in enumerate(_cluster(hole.water)):
        hole.water_blobs += make_hazard_blobs(group, seed + 977 + gi * 53)


def move_tee_up(hole: Hole, scale: float) -> None:
    """Play the hole from a forward tee.

    The tee walks up the existing centreline and everything else stays put, so
    a shorter tee changes the shot you face without redesigning the hole.
    """
    if scale >= 0.999:
        return
    total = polyline_length(hole.center)
    drop = total * (1.0 - scale)
    run = 0.0
    for i in range(len(hole.center) - 1):
        seg = dist(hole.center[i], hole.center[i + 1])
        if run + seg >= drop:
            t = (drop - run) / seg if seg > 1e-6 else 0.0
            a, b = hole.center[i], hole.center[i + 1]
            new_tee = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            hole.center = [new_tee] + hole.center[i + 1 :]
            break
        run += seg
    if len(hole.center) < 3:  # keep the corridor builder happy on short holes
        mid = (
            (hole.center[0][0] + hole.center[-1][0]) / 2,
            (hole.center[0][1] + hole.center[-1][1]) / 2,
        )
        hole.center = [hole.center[0], mid, hole.center[-1]]
    hole.yardage = int(round(polyline_length(hole.center)))


def _finish(hole: Hole) -> None:
    _protect_green(hole)
    _shape_hazards(hole)
    xs = [p[0] for p in hole.center] + [hole.green_center[0]]
    ys = [p[1] for p in hole.center] + [hole.green_center[1]]
    for c, r in hole.trees:
        xs += [c[0] - r, c[0] + r]
        ys += [c[1] - r, c[1] + r]
    for b in hole.sand_blobs + hole.water_blobs:
        xs += [b.bounds[0], b.bounds[2]]
        ys += [b.bounds[1], b.bounds[3]]
    pad = hole.rough_half + 20
    hole.bounds = (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)


class Weather:
    """One day's wind, walked from hole to hole.

    Drawing a fresh random vector per hole made the wind teleport -- twelve
    into your face on 6, dead calm on 7 -- which reads as eighteen different
    afternoons.  Instead a single wind is drawn for the round and then takes a
    small step each hole: it backs and veers, freshens and drops, but
    consecutive holes belong to the same day.

    ``swirl`` is a property of the hole rather than the day: how much shelter
    and funnelling move the wind about while the ball is up there.
    """

    DRIFT_DEG = 18.0  # how far the bearing wanders per hole
    DRIFT_FRAC = 0.24  # speed wander per hole, as a fraction of wind_max

    def __init__(self, spec: CourseSpec, rng: random.Random):
        self.spec = spec
        self.rng = rng
        self.bearing = rng.uniform(0.0, 360.0)
        self.speed = rng.uniform(spec.wind_max * 0.22, spec.wind_max * 0.95)

    def step(self) -> tuple[Vec, float]:
        """The wind on the next hole, one drift on from the last, plus a swirl."""
        self.bearing += self.rng.gauss(0.0, self.DRIFT_DEG)
        lo, hi = self.spec.wind_max * 0.06, self.spec.wind_max
        self.speed = min(
            hi, max(lo, self.speed + self.rng.gauss(0.0, self.spec.wind_max * self.DRIFT_FRAC))
        )
        r = math.radians(self.bearing)
        wind = (math.sin(r) * self.speed, math.cos(r) * self.speed)
        # Timber is what makes a hole swirl, so let the course's own density say.
        swirl = self.rng.uniform(0.06, 0.30) * min(1.6, self.spec.tree_density)
        return wind, swirl


def wind_now(hole: Hole, t: float) -> Vec:
    """The wind on this hole at time ``t`` seconds.

    A hole's wind is never still: the bearing wanders and the speed breathes,
    so the arrow the player is watching moves -- and whatever it reads at the
    instant they strike is the wind the ball gets.  Two out-of-phase sines are
    enough to read as weather, and unlike a per-frame random walk they are
    smooth, so the player can actually time them.  ``swirl`` sets the range: a
    sheltered hole barely moves, Golden Bell swings through forty degrees.
    """
    speed = math.hypot(*hole.wind)
    if speed < 0.05:
        return hole.wind
    ph = hole.number * 1.7  # every hole breathes on its own phase
    swing = math.radians(6.0 + 45.0 * hole.swirl)
    ang = math.atan2(hole.wind[0], hole.wind[1]) + swing * (
        0.62 * math.sin(t * 0.55 + ph) + 0.38 * math.sin(t * 1.27 + ph * 2.1)
    )
    breath = 0.10 + 0.45 * hole.swirl
    speed = max(
        0.0,
        speed
        * (
            1.0
            + breath * (0.6 * math.sin(t * 0.47 + ph * 1.3) + 0.4 * math.sin(t * 1.06 + ph * 0.7))
        ),
    )
    return (math.sin(ang) * speed, math.cos(ang) * speed)


# ---- authored holes


def _apply_hazard(hole: Hole, hz: Hazard) -> None:
    center = hole.center
    gc, gr = hole.green_center, hole.green_r
    _, approach = point_along(center, 1.0)

    if isinstance(hz, GBunker):
        a = math.radians(hz.bearing)
        # Rotate the approach heading by the bearing (0 = beyond the green).
        dx = approach[0] * math.cos(a) - approach[1] * math.sin(a)
        dy = approach[0] * math.sin(a) + approach[1] * math.cos(a)
        d = gr + hz.r + hz.gap
        hole.bunkers.append(((gc[0] + dx * d, gc[1] + dy * d), hz.r))
    elif isinstance(hz, FBunker):
        p, h = point_along(center, hz.frac)
        hole.bunkers.append((offset(p, h, hz.side), hz.r))
    elif isinstance(hz, Pond):
        p, h = point_along(center, hz.frac)
        hole.water.append((offset(p, h, hz.side), hz.r))
    elif isinstance(hz, FrontWater):
        back = gr + hz.r + hz.gap
        hole.water.append(
            (
                (gc[0] - approach[0] * back - approach[1] * hz.side,
                 gc[1] - approach[1] * back + approach[0] * hz.side),
                hz.r,
            )
        )
    elif isinstance(hz, CarryWater):
        span = polyline_length(center) * (hz.frac_b - hz.frac_a)
        n = max(1, int(span / (hz.half * 1.15)))
        for i in range(n + 1):
            f = hz.frac_a + (hz.frac_b - hz.frac_a) * (i / n if n else 0)
            p, h = point_along(center, f)
            hole.water.append((offset(p, h, hz.side), hz.half))
    elif isinstance(hz, Grove):
        p, h = point_along(center, hz.frac)
        hole.trees.append((offset(p, h, hz.side), hz.r))


def build_scripted_hole(
    spec: CourseSpec,
    hs: HoleSpec,
    rng: random.Random,
    tee_scale: float = 1.0,
    wind: Vec | None = None,
    swirl: float | None = None,
) -> Hole:
    center = _bent_centerline(float(hs.yards), hs.bend, hs.bend_at)
    grade = hs.slope_grade
    sa = math.radians(hs.slope_dir)
    hole = Hole(
        number=hs.number,
        par=hs.par,
        center=center,
        fairway_half=hs.fairway_half,
        rough_half=hs.fairway_half + 22.0,
        green_center=center[-1],
        green_r=hs.green_r,
        pin=center[-1],
        # Stored as the uphill gradient, so the ball rolls towards slope_dir.
        green_slope=(-math.sin(sa) * grade, -math.cos(sa) * grade),
        bumps=[],
        bunkers=[],
        water=[],
        trees=[],
        wind=wind if wind is not None else Weather(spec, rng).step()[0],
        swirl=hs.swirl if swirl is None else swirl,
        yardage=hs.yards,
        name=hs.name,
        note=hs.note,
        flag_color=spec.flag_color,
    )
    _green_detail(hole, random.Random(spec.seed * 131 + hs.number), hs.crown)
    for hz in hs.hazards:
        _apply_hazard(hole, hz)
    _line_the_hole_with_trees(hole, spec, rng)
    move_tee_up(hole, tee_scale)
    _finish(hole)
    return hole


def _line_the_hole_with_trees(hole: Hole, spec: CourseSpec, rng: random.Random) -> None:
    """Scatter timber outside the rough line, clear of the hazards."""
    count = int(round(spec.tree_density * rng.uniform(4, 9)))
    for _ in range(count):
        p, h = point_along(hole.center, rng.uniform(0.1, 0.95))
        r = rng.uniform(6.0, 12.0)
        side = rng.choice((-1, 1)) * (hole.rough_half + r * 0.4 + rng.uniform(0.0, 26.0))
        c = offset(p, h, side)
        if dist(c, hole.green_center) < hole.green_r + r + 8:
            continue
        if any(dist(c, wc) < wr + r for wc, wr in hole.water):
            continue
        if any(dist(c, bc) < br + r for bc, br in hole.bunkers):
            continue
        hole.trees.append((c, r))


# ---- procedural holes


PAR_ROUTINGS = [
    [4, 5, 3, 4, 4, 3, 5, 4, 4, 4, 3, 5, 4, 4, 4, 3, 5, 4],
    [4, 3, 5, 4, 4, 4, 3, 5, 4, 5, 4, 3, 4, 5, 3, 4, 4, 4],
    [5, 4, 3, 4, 5, 3, 4, 4, 4, 4, 4, 3, 5, 4, 3, 4, 5, 4],
]


def _hole_length(par: int, rng: random.Random) -> float:
    if par == 3:
        return rng.uniform(135, 218)
    if par == 4:
        return rng.uniform(325, 452)
    return rng.uniform(485, 578)


def _place_hazards(hole: Hole, spec: CourseSpec, rng: random.Random) -> None:
    gc, gr = hole.green_center, hole.green_r

    for _ in range(rng.randint(*spec.bunkers)):
        _apply_hazard(hole, GBunker(bearing=rng.uniform(0, 360), gap=rng.uniform(0.5, 6.0),
                                    r=rng.uniform(6.0, 11.0)))

    if hole.par >= 4:
        for _ in range(rng.randint(0, 2)):
            side = rng.choice((-1, 1)) * (hole.fairway_half + rng.uniform(-5.0, 8.0))
            hz = FBunker(frac=rng.uniform(0.42, 0.78), side=side, r=rng.uniform(7.0, 12.0))
            p, h = point_along(hole.center, hz.frac)
            if dist(offset(p, h, hz.side), gc) > gr + hz.r + 12:
                _apply_hazard(hole, hz)

    if rng.random() < spec.water_chance:
        if rng.random() < 0.45:
            _apply_hazard(hole, FrontWater(gap=rng.uniform(4.0, 14.0), r=rng.uniform(16.0, 26.0)))
        else:
            r = rng.uniform(18.0, 32.0)
            side = rng.choice((-1, 1)) * (hole.fairway_half + r * 0.55 + rng.uniform(-4.0, 10.0))
            hz = Pond(frac=rng.uniform(0.45, 0.85), side=side, r=r)
            p, h = point_along(hole.center, hz.frac)
            if dist(offset(p, h, hz.side), gc) > gr + r + 4:
                _apply_hazard(hole, hz)

    _line_the_hole_with_trees(hole, spec, rng)


def build_hole(
    spec: CourseSpec,
    rng: random.Random,
    number: int,
    par: int,
    tee_scale: float = 1.0,
    wind: Vec | None = None,
    swirl: float | None = None,
) -> Hole:
    length = _hole_length(par, rng)
    bend = math.degrees(rng.uniform(-1.0, 1.0) * spec.dogleg) * (0.25 if par == 3 else 1.0)
    center = _bent_centerline(length, bend, rng.uniform(0.35, 0.65))
    green_r = rng.uniform(12.0, 18.0) + (2.0 if par == 5 else 0.0)
    fair = spec.fairway_half * (0.55 if par == 3 else 1.0)
    grade = rng.uniform(spec.slope_max * 0.35, spec.slope_max)
    sa = rng.uniform(0, math.tau)

    hole = Hole(
        number=number,
        par=par,
        center=center,
        fairway_half=fair,
        rough_half=fair + rng.uniform(18.0, 26.0),
        green_center=center[-1],
        green_r=green_r,
        pin=center[-1],
        green_slope=(math.sin(sa) * grade, math.cos(sa) * grade),
        bumps=[],
        bunkers=[],
        water=[],
        trees=[],
        wind=wind if wind is not None else Weather(spec, rng).step()[0],
        swirl=0.15 if swirl is None else swirl,
        flag_color=spec.flag_color,
    )
    _green_detail(hole, rng)
    _place_hazards(hole, spec, rng)
    hole.yardage = int(round(polyline_length(center)))
    move_tee_up(hole, tee_scale)
    _finish(hole)
    return hole


def build_course(spec: CourseSpec, tee_scale: float = 1.0) -> list[Hole]:
    rng = random.Random(spec.seed)
    # The weather draws from its own stream so that changing how the wind is
    # rolled cannot reshuffle the geometry of every procedural hole.
    day = Weather(spec, random.Random(spec.seed * 7919 + 11))
    if spec.scripted:
        return [
            build_scripted_hole(spec, hs, rng, tee_scale, day.step()[0], hs.swirl)
            for hs in spec.scripted
        ]
    pars = PAR_ROUTINGS[spec.seed % len(PAR_ROUTINGS)]
    return [
        build_hole(spec, rng, i + 1, par, tee_scale, *day.step())
        for i, par in enumerate(pars)
    ]


def course_yardage(spec: CourseSpec, tee_scale: float, lo: int = 0, hi: int = 18) -> int:
    """Total yardage of a slice of holes, for the menu to show before you play."""
    return sum(h.yardage for h in build_course(spec, tee_scale)[lo:hi])
