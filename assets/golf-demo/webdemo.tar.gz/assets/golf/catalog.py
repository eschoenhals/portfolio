"""Every course you can tee it up on.

Three procedurally generated eighteens plus one real one.  Augusta National is
authored hole by hole from the published card: the pars and yardages are the
real ones, and each hole carries the feature it is actually known for -- the
fairway bunker right on 1, Rae's Creek fronting 12, the complete absence of
sand on 14, the forced carry on 16.  It is a sketch of the routing, not a
survey, but it plays like the place.
"""

from __future__ import annotations

from .course import (
    FLAG_YELLOW,
    CarryWater,
    CourseSpec,
    FBunker,
    FrontWater,
    GBunker,
    Grove,
    HoleSpec,
    Pond,
)


def btf(bend: float) -> float:
    """Bearing for a green that falls back towards the player.

    ``_bent_centerline`` leaves a hole pointing roughly 0.65 x its total bend,
    so the approach runs along that heading and "back to front" is 180 off it.
    Augusta's greens are famous for exactly this tilt.
    """
    return 0.65 * bend + 180.0


AUGUSTA_HOLES: tuple[HoleSpec, ...] = (
    HoleSpec(
        1, "Tea Olive", 4, 445, bend=10, bend_at=0.6, fairway_half=30, green_r=15,
        slope_dir=btf(10), slope_grade=0.032,
        hazards=(FBunker(0.64, 30, 12), GBunker(255, 2, 9), GBunker(200, 3, 8)),
        note="Fairway bunker guards the right side off the tee.",
    ),
    HoleSpec(
        2, "Pink Dogwood", 5, 585, bend=-18, bend_at=0.45, fairway_half=33, green_r=17,
        slope_dir=btf(-18), slope_grade=0.038,
        hazards=(FBunker(0.42, 27, 11), GBunker(250, 2, 10), GBunker(140, 2, 9)),
        note="Downhill and reachable if you turn it around the corner.",
    ),
    HoleSpec(
        3, "Flowering Peach", 4, 350, bend=-8, bend_at=0.5, fairway_half=28, green_r=13,
        slope_dir=btf(-8), slope_grade=0.040,
        hazards=(FBunker(0.55, -26, 8), FBunker(0.64, -30, 7), GBunker(245, 2, 8)),
        note="Short, but the smallest green on the property.",
    ),
    HoleSpec(
        4, "Flowering Crab Apple", 3, 240, bend=0, fairway_half=24, green_r=17,
        slope_dir=btf(0), slope_grade=0.030,
        hazards=(GBunker(200, 2, 10), GBunker(105, 2, 9)),
        note="A long iron off the tee. Front bunker is dead.",
    ),
    HoleSpec(
        5, "Magnolia", 4, 495, bend=-20, bend_at=0.5, fairway_half=30, green_r=15,
        slope_dir=btf(-20), slope_grade=0.042,
        hazards=(FBunker(0.55, -24, 12), FBunker(0.63, -30, 11), GBunker(340, 2, 9)),
        note="Deep bunkers up the left. Carry them or lay back.",
    ),
    HoleSpec(
        6, "Juniper", 3, 180, bend=0, fairway_half=22, green_r=16,
        slope_dir=btf(0), slope_grade=0.045,
        hazards=(GBunker(155, 2, 9),),
        note="Steeply downhill to a green with a shelf.",
    ),
    HoleSpec(
        7, "Pampas", 4, 450, bend=4, bend_at=0.5, fairway_half=22, green_r=13,
        slope_dir=btf(4), slope_grade=0.036,
        hazards=(
            Grove(0.35, -34, 12), Grove(0.35, 34, 12), Grove(0.58, -32, 11), Grove(0.58, 32, 11),
            GBunker(200, 2, 8), GBunker(160, 2, 8), GBunker(0, 2, 8), GBunker(35, 2, 7),
            GBunker(325, 2, 7),
        ),
        note="A chute of pines to a small, heavily bunkered green.",
    ),
    HoleSpec(
        8, "Yellow Jasmine", 5, 570, bend=14, bend_at=0.55, fairway_half=31, green_r=18,
        slope_dir=btf(14), slope_grade=0.034,
        hazards=(FBunker(0.34, 28, 14),),
        note="Uphill all the way. No sand around the green.",
    ),
    HoleSpec(
        9, "Carolina Cherry", 4, 460, bend=-15, bend_at=0.5, fairway_half=30, green_r=15,
        slope_dir=btf(-15), slope_grade=0.048,
        hazards=(GBunker(215, 2, 9), GBunker(255, 2, 8)),
        note="Anything short of the flag spins back off the front.",
    ),
    HoleSpec(
        10, "Camellia", 4, 495, bend=-22, bend_at=0.45, fairway_half=32, green_r=16,
        slope_dir=btf(-22), slope_grade=0.038,
        hazards=(GBunker(205, 2, 10),),
        note="Sweeping downhill left. The bunker sits in the face.",
    ),
    HoleSpec(
        11, "White Dogwood", 4, 520, bend=12, bend_at=0.35, fairway_half=29, green_r=16,
        slope_dir=btf(12), slope_grade=0.036,
        hazards=(Pond(0.94, -30, 19), GBunker(20, 2, 8)),
        note="Water left of the green. Par is a good score. Amen Corner begins.",
    ),
    HoleSpec(
        12, "Golden Bell", 3, 155, bend=0, fairway_half=20, green_r=13,
        slope_dir=btf(0), slope_grade=0.030,
        hazards=(FrontWater(5, 16), GBunker(180, 1, 7), GBunker(335, 2, 6), GBunker(25, 2, 6)),
        note="Rae's Creek, a shallow green, and swirling wind.",
        # The wind in that corner is the hole's defence: the arrow on the HUD is
        # an average, and the gust the ball actually gets is anybody's guess.
        swirl=0.85,
    ),
    HoleSpec(
        13, "Azalea", 5, 545, bend=-30, bend_at=0.4, fairway_half=30, green_r=17,
        slope_dir=btf(-30), slope_grade=0.040,
        hazards=(
            FrontWater(4, 14), GBunker(0, 2, 8), GBunker(35, 2, 7), GBunker(325, 2, 7),
            GBunker(295, 2, 7),
        ),
        note="The tributary guards the green. Go or lay up.",
    ),
    HoleSpec(
        14, "Chinese Fir", 4, 440, bend=-14, bend_at=0.5, fairway_half=31, green_r=18,
        slope_dir=btf(-14), slope_grade=0.052,
        hazards=(),
        note="Not a single bunker. The green does all the defending.",
    ),
    HoleSpec(
        15, "Firethorn", 5, 550, bend=-8, bend_at=0.45, fairway_half=32, green_r=16,
        slope_dir=btf(-8), slope_grade=0.042,
        hazards=(FrontWater(4, 15), GBunker(25, 2, 8)),
        note="Downhill and reachable, with water waiting short.",
    ),
    HoleSpec(
        16, "Redbud", 3, 170, bend=0, fairway_half=20, green_r=16,
        slope_dir=btf(0) - 55, slope_grade=0.050,
        hazards=(CarryWater(0.22, 0.70, 24, -6), GBunker(95, 2, 9), GBunker(320, 2, 8)),
        note="All carry. Feed it off the slope and watch it chase left.",
    ),
    HoleSpec(
        17, "Nandina", 4, 440, bend=-6, bend_at=0.5, fairway_half=28, green_r=15,
        slope_dir=btf(-6), slope_grade=0.038,
        hazards=(Grove(0.36, -26, 10), GBunker(205, 2, 9), GBunker(250, 2, 8)),
        note="Straight uphill, with a tree in the way off the tee.",
    ),
    HoleSpec(
        18, "Holly", 4, 465, bend=20, bend_at=0.45, fairway_half=27, green_r=15,
        slope_dir=btf(20), slope_grade=0.040,
        hazards=(FBunker(0.50, -22, 12), FBunker(0.58, -26, 11), GBunker(205, 2, 9),
                 GBunker(340, 2, 8)),
        note="Uphill through the chute, bunkers left. Finish it off.",
    ),
)


#: St Andrews, from the 2022 Open card: par 72, 7,305 yards.  The famous
#: bunkers are placed where they actually lie -- Hell on 14, the Road bunker on
#: 17, Strath on 11 -- because on this course the bunkers *are* the design.
#: Two things the vocabulary cannot say: seven greens are shared doubles (they
#: get one big green instead), and the out-of-bounds wall down 17 is not a
#: hazard the game has.  There are no trees at all, which is true to the place.
ST_ANDREWS_HOLES: tuple[HoleSpec, ...] = (
    HoleSpec(
        1, "Burn", 4, 376, bend=0, fairway_half=48, green_r=17,
        slope_dir=btf(0), slope_grade=0.018,
        hazards=(FrontWater(gap=1.5, r=7),),
        note="The widest fairway in golf, and the Swilcan Burn tight to the green.",
    ),
    HoleSpec(
        2, "Dyke", 4, 453, bend=6, bend_at=0.55, fairway_half=30, green_r=18,
        slope_dir=btf(6), slope_grade=0.022,
        hazards=(FBunker(0.62, 20, 5), GBunker(200, 1, 5), GBunker(250, 1, 4)),
        note="Cheape's bunker left, pot bunkers guarding the right half of the green.",
    ),
    HoleSpec(
        3, "Cartgate (Out)", 4, 397, bend=-5, fairway_half=32, green_r=19,
        slope_dir=btf(-5), slope_grade=0.020,
        hazards=(GBunker(205, 1, 6), FBunker(0.70, -22, 5)),
        note="Cartgate bunker eats the front left of a big shared green.",
    ),
    HoleSpec(
        4, "Ginger Beer", 4, 480, bend=5, bend_at=0.45, fairway_half=30, green_r=17,
        slope_dir=btf(5), slope_grade=0.024,
        hazards=(FBunker(0.52, 16, 5), FBunker(0.58, -20, 5), GBunker(215, 2, 5)),
        note="Ginger Beer bunker in the fairway. The safe line is well right.",
    ),
    HoleSpec(
        5, "Hole o' Cross (Out)", 5, 570, bend=8, bend_at=0.6, fairway_half=32, green_r=22,
        slope_dir=btf(8), slope_grade=0.026,
        hazards=(FBunker(0.46, -18, 6), FBunker(0.52, -24, 5), GBunker(190, 2, 6)),
        note="The Spectacles bunkers, then the largest green on the property.",
    ),
    HoleSpec(
        6, "Heathery (Out)", 4, 412, bend=-6, fairway_half=30, green_r=18,
        slope_dir=btf(-6), slope_grade=0.022,
        hazards=(FBunker(0.55, -19, 5), FBunker(0.60, 21, 5), GBunker(230, 2, 5)),
        note="Blind off the tee over the whins. Aim at nothing and trust it.",
    ),
    HoleSpec(
        7, "High (Out)", 4, 371, bend=14, bend_at=0.55, fairway_half=28, green_r=20,
        slope_dir=btf(14), slope_grade=0.028,
        hazards=(GBunker(180, 1, 7), GBunker(215, 1, 5)),
        note="Shell bunker short of a green shared with the 11th, and it crosses it.",
    ),
    HoleSpec(
        8, "Short", 3, 175, bend=0, fairway_half=22, green_r=16,
        slope_dir=btf(0), slope_grade=0.024,
        hazards=(GBunker(195, 1, 6),),
        note="One deep bunker short left. Everything else is puttable.",
    ),
    HoleSpec(
        9, "End", 4, 352, bend=0, fairway_half=34, green_r=17,
        slope_dir=btf(0), slope_grade=0.016,
        hazards=(FBunker(0.66, -14, 5), FBunker(0.72, 16, 5)),
        note="Flat, short and drivable downwind. Boase's bunker is the only defence.",
    ),
    HoleSpec(
        10, "Bobby Jones", 4, 386, bend=4, fairway_half=32, green_r=17,
        slope_dir=btf(4), slope_grade=0.020,
        hazards=(GBunker(210, 2, 5), FBunker(0.74, 18, 5)),
        note="Reachable, and named for the only man ever made a freeman of the town.",
    ),
    HoleSpec(
        11, "High (In)", 3, 174, bend=0, fairway_half=22, green_r=20,
        slope_dir=btf(0), slope_grade=0.048,
        hazards=(GBunker(170, 0.5, 5), GBunker(150, 1, 4)),
        note="Strath and Hill bunkers, on a green falling hard to the Eden estuary.",
    ),
    HoleSpec(
        12, "Heathery (In)", 4, 348, bend=-4, fairway_half=30, green_r=16,
        slope_dir=btf(-4), slope_grade=0.024,
        hazards=(FBunker(0.60, -8, 4), FBunker(0.66, 6, 4), FBunker(0.70, -14, 4)),
        note="Pot bunkers hidden in the middle of the fairway. You cannot see them.",
    ),
    HoleSpec(
        13, "Hole o' Cross (In)", 4, 465, bend=7, bend_at=0.5, fairway_half=29, green_r=19,
        slope_dir=btf(7), slope_grade=0.026,
        hazards=(FBunker(0.44, -16, 5), FBunker(0.50, -21, 5), GBunker(205, 1, 5)),
        note="The Coffins left, the Lion's Mouth short. Play out to the right.",
    ),
    HoleSpec(
        14, "Long", 5, 618, bend=9, bend_at=0.4, fairway_half=30, green_r=18,
        slope_dir=btf(9), slope_grade=0.028,
        hazards=(FBunker(0.28, -12, 5), FBunker(0.32, -17, 4), FBunker(0.52, -6, 11),
                 GBunker(200, 2, 5)),
        note="The Beardies off the tee, then Hell Bunker across the Elysian Fields.",
    ),
    HoleSpec(
        15, "Cartgate (In)", 4, 455, bend=-5, fairway_half=31, green_r=19,
        slope_dir=btf(-5), slope_grade=0.022,
        hazards=(FBunker(0.56, -15, 5), GBunker(215, 2, 5)),
        note="Sutherland bunker is the aiming point, and the thing to avoid.",
    ),
    HoleSpec(
        16, "Corner of the Dyke", 4, 423, bend=6, bend_at=0.55, fairway_half=28, green_r=17,
        slope_dir=btf(6), slope_grade=0.024,
        hazards=(FBunker(0.54, -4, 4), FBunker(0.58, -9, 4), FBunker(0.62, 2, 4),
                 GBunker(190, 1, 5)),
        note="Principal's Nose sits in the middle of the fairway. Left or right, choose.",
    ),
    HoleSpec(
        17, "Road", 4, 495, bend=11, bend_at=0.35, fairway_half=26, green_r=15,
        slope_dir=btf(11), slope_grade=0.030,
        hazards=(FBunker(0.40, -18, 6), GBunker(195, 0.5, 4), GBunker(160, 1, 4)),
        note="The Road Hole. Drive over the sheds, and the Road bunker takes the rest.",
    ),
    HoleSpec(
        18, "Tom Morris", 4, 357, bend=0, fairway_half=48, green_r=18,
        slope_dir=btf(0), slope_grade=0.030,
        hazards=(),
        note="Over the Swilcan Bridge. No bunkers -- only the Valley of Sin.",
    ),
)


#: Pinehurst No. 2, from the US Open card: par 70, about 7,530 yards.  Donald
#: Ross's holes have numbers and no names, so they get none here either.
#: Two things carry the course.  Every green is a turtleback (``crown``), which
#: is why a course with no water at all and almost no rough defends par: an
#: approach that pitches off the middle is shrugged away to the collar.  And the
#: rough *is* sand -- wiregrass and waste, modelled as wide bunkers hugging both
#: sides of the fairway rather than as a mown corridor.
PINEHURST_HOLES: tuple[HoleSpec, ...] = (
    HoleSpec(
        1, "", 4, 404, bend=5, fairway_half=26, green_r=14, crown=0.80,
        slope_dir=btf(5), slope_grade=0.018,
        hazards=(FBunker(0.62, 22, 13), FBunker(0.68, -24, 12), GBunker(215, 3, 7)),
        note="Gentle opener. The green sheds anything that lands off its middle.",
    ),
    HoleSpec(
        2, "", 4, 502, bend=-6, bend_at=0.55, fairway_half=27, green_r=14, crown=0.85,
        slope_dir=btf(-6), slope_grade=0.020,
        hazards=(FBunker(0.55, -25, 14), FBunker(0.63, 26, 12), GBunker(200, 3, 8)),
        note="A 500-yard par 4 to one of the most repellent greens on the course.",
    ),
    HoleSpec(
        3, "", 4, 387, bend=7, fairway_half=26, green_r=13, crown=0.75,
        slope_dir=btf(7), slope_grade=0.020,
        hazards=(FBunker(0.58, 21, 12), GBunker(190, 2, 7), GBunker(240, 3, 6)),
        note="Short, and the smallest crowned green out here. Wedge it or chase it off.",
    ),
    HoleSpec(
        4, "", 4, 529, bend=-5, bend_at=0.5, fairway_half=28, green_r=15, crown=0.85,
        slope_dir=btf(-5), slope_grade=0.022,
        hazards=(FBunker(0.48, -26, 15), FBunker(0.60, 24, 13), GBunker(205, 3, 8)),
        note="Plays as a par 4 in the Open, which tells you most of what you need.",
    ),
    HoleSpec(
        5, "", 5, 576, bend=8, bend_at=0.45, fairway_half=28, green_r=15, crown=0.80,
        slope_dir=btf(8), slope_grade=0.024,
        hazards=(FBunker(0.42, 24, 14), FBunker(0.66, -26, 13), GBunker(195, 3, 8)),
        note="Uphill three-shotter. The lay-up is the play, and it still is not easy.",
    ),
    HoleSpec(
        6, "", 3, 224, bend=0, fairway_half=22, green_r=14, crown=0.90,
        slope_dir=btf(0), slope_grade=0.022,
        hazards=(GBunker(180, 2, 8), GBunker(215, 3, 7), GBunker(145, 3, 6)),
        note="A long iron to a domed green ringed by sand. Par is a fine score.",
    ),
    HoleSpec(
        7, "", 4, 407, bend=-9, bend_at=0.5, fairway_half=25, green_r=13, crown=0.85,
        slope_dir=btf(-9), slope_grade=0.024,
        hazards=(FBunker(0.56, -23, 13), FBunker(0.62, 22, 11), GBunker(200, 2, 7)),
        note="Bends left off the tee to a green that falls away on three sides.",
    ),
    HoleSpec(
        8, "", 4, 489, bend=6, bend_at=0.55, fairway_half=27, green_r=14, crown=0.80,
        slope_dir=btf(6), slope_grade=0.022,
        hazards=(FBunker(0.54, 25, 14), FBunker(0.64, -24, 12), GBunker(210, 3, 8)),
        note="Long and uphill. Take the front of the green and be pleased with it.",
    ),
    HoleSpec(
        9, "", 3, 191, bend=0, fairway_half=22, green_r=14, crown=0.75,
        slope_dir=btf(0), slope_grade=0.020,
        hazards=(GBunker(185, 2, 7), GBunker(230, 3, 6)),
        note="The shortest hole. Still a crown, so the middle is the only target.",
    ),
    HoleSpec(
        10, "", 5, 613, bend=-7, bend_at=0.5, fairway_half=29, green_r=15, crown=0.85,
        slope_dir=btf(-7), slope_grade=0.024,
        hazards=(FBunker(0.40, -26, 15), FBunker(0.58, 25, 14), GBunker(200, 3, 8)),
        note="Over 600 yards, and the green still will not hold a long approach.",
    ),
    HoleSpec(
        11, "", 4, 483, bend=8, bend_at=0.5, fairway_half=27, green_r=14, crown=0.85,
        slope_dir=btf(8), slope_grade=0.022,
        hazards=(FBunker(0.56, 24, 13), FBunker(0.62, -25, 12), GBunker(195, 3, 7)),
        note="Doglegs right through the pines to a narrow crowned target.",
    ),
    HoleSpec(
        12, "", 4, 484, bend=-6, bend_at=0.55, fairway_half=27, green_r=14, crown=0.80,
        slope_dir=btf(-6), slope_grade=0.022,
        hazards=(FBunker(0.55, -24, 13), FBunker(0.65, 23, 12), GBunker(205, 3, 8)),
        note="Another long two-shotter. Sand down both sides of the landing area.",
    ),
    HoleSpec(
        13, "", 4, 383, bend=9, bend_at=0.5, fairway_half=26, green_r=13, crown=0.90,
        slope_dir=btf(9), slope_grade=0.024,
        hazards=(FBunker(0.60, 21, 12), GBunker(185, 2, 7), GBunker(235, 3, 6)),
        note="Short but the most severely crowned green on the back nine.",
    ),
    HoleSpec(
        14, "", 4, 473, bend=-8, bend_at=0.5, fairway_half=27, green_r=14, crown=0.80,
        slope_dir=btf(-8), slope_grade=0.022,
        hazards=(FBunker(0.54, -25, 14), FBunker(0.64, 24, 12), GBunker(200, 3, 8)),
        note="Downhill, then a rising approach you cannot run in.",
    ),
    HoleSpec(
        15, "", 3, 202, bend=0, fairway_half=22, green_r=14, crown=0.80,
        slope_dir=btf(0), slope_grade=0.022,
        hazards=(GBunker(175, 2, 7), GBunker(210, 3, 7)),
        note="Mid-iron, bunkers short and long, and no way to stop it on the shoulder.",
    ),
    HoleSpec(
        16, "", 4, 528, bend=7, bend_at=0.5, fairway_half=28, green_r=15, crown=0.85,
        slope_dir=btf(7), slope_grade=0.024,
        hazards=(FBunker(0.50, 26, 15), FBunker(0.62, -25, 13), GBunker(205, 3, 8)),
        note="Converted to a par 4 for the Open and it broke the field.",
    ),
    HoleSpec(
        17, "", 3, 205, bend=0, fairway_half=22, green_r=13, crown=0.90,
        slope_dir=btf(0), slope_grade=0.024,
        hazards=(GBunker(180, 2, 7), GBunker(220, 3, 6), GBunker(140, 3, 6)),
        note="All carry to a small crown. The tournament has been lost here.",
    ),
    HoleSpec(
        18, "", 4, 451, bend=6, bend_at=0.55, fairway_half=27, green_r=15, crown=0.80,
        slope_dir=btf(6), slope_grade=0.022,
        hazards=(FBunker(0.55, 24, 14), FBunker(0.63, -23, 12), GBunker(200, 3, 8)),
        note="Uphill to the clubhouse, with sand right where the drive wants to go.",
    ),
)


#: Old Town Club, Winston-Salem: Perry Maxwell, 1939, restored by Coore and
#: Crenshaw in 2013.  Par 70 at about 6,825 yards.
#:
#: Honest about its sourcing: the par, the length and the character are right,
#: but unlike Augusta, St Andrews and Pinehurst this is not a published card I
#: can quote hole for hole -- the individual yardages are a reconstruction that
#: adds up to the real total.  What it does get right is what the course is
#: about: enormous rolling fairways with the trees taken back out, no water to
#: speak of, and the greens.  Maxwell rolls are the whole defence, so the slope
#: grades here are the steepest of any real course in the game.
OLD_TOWN_HOLES: tuple[HoleSpec, ...] = (
    HoleSpec(
        1, "", 4, 400, bend=6, fairway_half=34, green_r=16,
        slope_dir=btf(6), slope_grade=0.044,
        hazards=(FBunker(0.64, 24, 10), GBunker(210, 3, 8)),
        note="Downhill opener, and the first of eighteen severely rolling greens.",
    ),
    HoleSpec(
        2, "", 4, 430, bend=-8, bend_at=0.55, fairway_half=33, green_r=16,
        slope_dir=btf(-8), slope_grade=0.046,
        hazards=(FBunker(0.58, -25, 11), GBunker(200, 3, 8), GBunker(250, 3, 7)),
        note="Wide off the tee. The green does the arguing.",
    ),
    HoleSpec(
        3, "", 3, 195, bend=0, fairway_half=24, green_r=15,
        slope_dir=btf(0), slope_grade=0.048,
        hazards=(GBunker(190, 2, 8), GBunker(150, 3, 7)),
        note="Mid-iron across the hillside to a green with a shelf in it.",
    ),
    HoleSpec(
        4, "", 4, 415, bend=9, bend_at=0.5, fairway_half=32, green_r=16,
        slope_dir=btf(9), slope_grade=0.044,
        hazards=(FBunker(0.60, 23, 10), GBunker(205, 3, 8)),
        note="Bends right around the rise. Long is dead.",
    ),
    HoleSpec(
        5, "", 5, 540, bend=-10, bend_at=0.45, fairway_half=34, green_r=17,
        slope_dir=btf(-10), slope_grade=0.042,
        hazards=(FBunker(0.46, -26, 12), FBunker(0.72, 22, 10), GBunker(195, 3, 8)),
        note="Reachable downhill, into a green that will not hold a long iron.",
    ),
    HoleSpec(
        6, "", 4, 380, bend=5, fairway_half=33, green_r=16,
        slope_dir=btf(5), slope_grade=0.046,
        hazards=(FBunker(0.66, -22, 10), GBunker(215, 3, 7)),
        note="Short two-shotter. Position over power, then read the roll.",
    ),
    HoleSpec(
        7, "", 4, 445, bend=-6, bend_at=0.55, fairway_half=32, green_r=16,
        slope_dir=btf(-6), slope_grade=0.044,
        hazards=(FBunker(0.56, -24, 11), FBunker(0.62, 23, 10), GBunker(200, 3, 8)),
        note="The longest par 4 on the front, uphill all the way in.",
    ),
    HoleSpec(
        8, "", 3, 165, bend=0, fairway_half=24, green_r=15,
        slope_dir=btf(0), slope_grade=0.050,
        hazards=(GBunker(180, 2, 8), GBunker(220, 3, 6)),
        note="Short iron, and the most tilted green on the property.",
    ),
    HoleSpec(
        9, "", 4, 420, bend=7, bend_at=0.5, fairway_half=33, green_r=16,
        slope_dir=btf(7), slope_grade=0.042,
        hazards=(FBunker(0.62, 24, 11), GBunker(205, 3, 8)),
        note="Back up the hill towards the clubhouse.",
    ),
    HoleSpec(
        10, "", 4, 405, bend=-7, fairway_half=33, green_r=16,
        slope_dir=btf(-7), slope_grade=0.046,
        hazards=(FBunker(0.60, -23, 10), GBunker(210, 3, 8)),
        note="Turns away downhill. A drive up the left shortens it considerably.",
    ),
    HoleSpec(
        11, "", 5, 525, bend=8, bend_at=0.5, fairway_half=34, green_r=17,
        slope_dir=btf(8), slope_grade=0.042,
        hazards=(FBunker(0.44, 25, 12), Pond(0.78, -30, 16), GBunker(200, 3, 8)),
        note="The one hole where the creek in the valley is genuinely in play.",
    ),
    HoleSpec(
        12, "", 3, 210, bend=0, fairway_half=24, green_r=16,
        slope_dir=btf(0), slope_grade=0.046,
        hazards=(GBunker(185, 2, 8), GBunker(230, 3, 7)),
        note="The long one. Two putts from the wrong tier is good work.",
    ),
    HoleSpec(
        13, "", 4, 460, bend=-9, bend_at=0.5, fairway_half=32, green_r=16,
        slope_dir=btf(-9), slope_grade=0.044,
        hazards=(FBunker(0.54, -25, 11), FBunker(0.60, 24, 10), GBunker(200, 3, 8)),
        note="Long, left-bending, and uphill into the prevailing wind.",
    ),
    HoleSpec(
        14, "", 4, 355, bend=6, fairway_half=34, green_r=15,
        slope_dir=btf(6), slope_grade=0.050,
        hazards=(GBunker(195, 2, 8), GBunker(240, 3, 7)),
        note="Drivable, but the green is small and falls off everywhere.",
    ),
    HoleSpec(
        15, "", 4, 430, bend=-5, bend_at=0.55, fairway_half=33, green_r=16,
        slope_dir=btf(-5), slope_grade=0.044,
        hazards=(FBunker(0.58, -24, 11), GBunker(205, 3, 8)),
        note="Straightforward off the tee. Everything is in the approach.",
    ),
    HoleSpec(
        16, "", 3, 180, bend=0, fairway_half=24, green_r=15,
        slope_dir=btf(0), slope_grade=0.048,
        hazards=(GBunker(175, 2, 8), GBunker(215, 3, 7), GBunker(140, 3, 6)),
        note="Downhill short iron, bunkered all round. Below the hole or nowhere.",
    ),
    HoleSpec(
        17, "", 4, 425, bend=8, bend_at=0.5, fairway_half=33, green_r=16,
        slope_dir=btf(8), slope_grade=0.042,
        hazards=(FBunker(0.60, 24, 11), GBunker(200, 3, 8)),
        note="Bends right, rises to the green. A par here is worth having.",
    ),
    HoleSpec(
        18, "", 4, 445, bend=-6, bend_at=0.55, fairway_half=34, green_r=17,
        slope_dir=btf(-6), slope_grade=0.044,
        hazards=(FBunker(0.56, -25, 11), GBunker(205, 3, 8), GBunker(160, 3, 7)),
        note="Uphill home to a huge rolling green under the clubhouse windows.",
    ),
)


#: Tobacco Road, Sanford: Mike Strantz, 1998.  Par 71 at about 6,555 yards.
#:
#: Same caveat as Old Town: par, length and character are right, the individual
#: yardages are a reconstruction summing to the real total, and the holes are
#: left unnamed rather than guessed at.  What defines the place is the shape of
#: the corridors: narrow strips of fairway walled in by vast sand waste, most
#: tee shots blind over a dune, and greens small enough to make the second shot
#: the hard one.  So: the narrowest fairways in the game, and bunkers two and
#: three times the size of anyone else's.
TOBACCO_ROAD_HOLES: tuple[HoleSpec, ...] = (
    HoleSpec(
        1, "", 5, 530, bend=8, bend_at=0.5, fairway_half=20, green_r=14,
        slope_dir=btf(8), slope_grade=0.034,
        hazards=(FBunker(0.42, -30, 24), FBunker(0.66, 28, 20), GBunker(200, 3, 8)),
        note="Blind over the dune, down a chute of sand. Reachable if you find it.",
    ),
    HoleSpec(
        2, "", 4, 385, bend=-10, bend_at=0.45, fairway_half=18, green_r=13,
        slope_dir=btf(-10), slope_grade=0.036,
        hazards=(FBunker(0.55, -26, 22), FBunker(0.60, 25, 18), GBunker(195, 2, 7)),
        note="A gap you cannot see, framed by waste on both sides.",
    ),
    HoleSpec(
        3, "", 3, 175, bend=0, fairway_half=18, green_r=13,
        slope_dir=btf(0), slope_grade=0.034,
        hazards=(GBunker(180, 1.5, 12), GBunker(215, 3, 9)),
        note="All carry over sand to a small green cut into the hillside.",
    ),
    HoleSpec(
        4, "", 4, 400, bend=9, bend_at=0.5, fairway_half=19, green_r=13,
        slope_dir=btf(9), slope_grade=0.036,
        hazards=(FBunker(0.52, 27, 22), FBunker(0.62, -25, 18), GBunker(205, 2, 8)),
        note="Turns hard right around a dune the size of a house.",
    ),
    HoleSpec(
        5, "", 5, 555, bend=-11, bend_at=0.45, fairway_half=21, green_r=14,
        slope_dir=btf(-11), slope_grade=0.034,
        hazards=(FBunker(0.40, -30, 26), FBunker(0.70, 26, 20), GBunker(190, 3, 8)),
        note="The longest hole, and the widest waste area on the property.",
    ),
    HoleSpec(
        6, "", 4, 340, bend=7, fairway_half=18, green_r=12,
        slope_dir=btf(7), slope_grade=0.038,
        hazards=(FBunker(0.58, 24, 20), GBunker(185, 2, 8), GBunker(230, 3, 7)),
        note="Short and mean. Lay back or take on the sand; there is no middle.",
    ),
    HoleSpec(
        7, "", 3, 160, bend=0, fairway_half=18, green_r=12,
        slope_dir=btf(0), slope_grade=0.036,
        hazards=(GBunker(175, 1.5, 11), GBunker(220, 3, 8)),
        note="A wedge to a shelf. Anything off it feeds down into the waste.",
    ),
    HoleSpec(
        8, "", 4, 420, bend=-8, bend_at=0.5, fairway_half=19, green_r=13,
        slope_dir=btf(-8), slope_grade=0.034,
        hazards=(FBunker(0.54, -28, 23), FBunker(0.62, 26, 18), GBunker(200, 2, 8)),
        note="Blind again, downhill, into a corridor barely wider than the green.",
    ),
    HoleSpec(
        9, "", 4, 395, bend=6, bend_at=0.55, fairway_half=19, green_r=13,
        slope_dir=btf(6), slope_grade=0.036,
        hazards=(FBunker(0.56, 26, 21), GBunker(195, 2, 8)),
        note="Back towards the clubhouse over a ridge you have to trust.",
    ),
    HoleSpec(
        10, "", 5, 505, bend=-9, bend_at=0.5, fairway_half=20, green_r=14,
        slope_dir=btf(-9), slope_grade=0.034,
        hazards=(FBunker(0.44, -28, 24), FBunker(0.68, 25, 19), GBunker(200, 3, 8)),
        note="Short for a five, and every yard of it is a decision.",
    ),
    HoleSpec(
        11, "", 4, 375, bend=10, bend_at=0.45, fairway_half=18, green_r=12,
        slope_dir=btf(10), slope_grade=0.038,
        hazards=(FBunker(0.52, 26, 21), FBunker(0.60, -24, 17), GBunker(190, 2, 7)),
        note="Doglegs around sand to the smallest green out here.",
    ),
    HoleSpec(
        12, "", 3, 190, bend=0, fairway_half=18, green_r=13,
        slope_dir=btf(0), slope_grade=0.036,
        hazards=(GBunker(180, 1.5, 12), GBunker(210, 3, 9), GBunker(145, 3, 8)),
        note="Long iron, ringed by waste, with nowhere to bail out.",
    ),
    HoleSpec(
        13, "", 4, 410, bend=-7, bend_at=0.5, fairway_half=19, green_r=13,
        slope_dir=btf(-7), slope_grade=0.034,
        hazards=(FBunker(0.55, -27, 22), FBunker(0.63, 25, 18), GBunker(205, 2, 8)),
        note="Uphill through the gap. The drive is everything.",
    ),
    HoleSpec(
        14, "", 4, 300, bend=12, bend_at=0.5, fairway_half=17, green_r=12,
        slope_dir=btf(12), slope_grade=0.038,
        hazards=(FBunker(0.50, 25, 20), GBunker(185, 2, 9), GBunker(235, 3, 7)),
        note="Three hundred yards, drivable, and a disaster if you miss.",
    ),
    HoleSpec(
        15, "", 4, 430, bend=-8, bend_at=0.5, fairway_half=20, green_r=13,
        slope_dir=btf(-8), slope_grade=0.034,
        hazards=(FBunker(0.54, -28, 23), FBunker(0.62, 26, 19), GBunker(200, 2, 8)),
        note="The hardest driving hole on the back nine.",
    ),
    HoleSpec(
        16, "", 3, 205, bend=0, fairway_half=18, green_r=13,
        slope_dir=btf(0), slope_grade=0.036,
        hazards=(GBunker(175, 1.5, 12), GBunker(215, 3, 9)),
        note="Long, exposed, and entirely carry. Take one more club.",
    ),
    HoleSpec(
        17, "", 4, 385, bend=9, bend_at=0.5, fairway_half=19, green_r=13,
        slope_dir=btf(9), slope_grade=0.036,
        hazards=(FBunker(0.53, 26, 21), FBunker(0.61, -24, 17), GBunker(195, 2, 8)),
        note="Blind tee shot around the dune, then a short one you can attack.",
    ),
    HoleSpec(
        18, "", 4, 395, bend=-6, bend_at=0.55, fairway_half=20, green_r=13,
        slope_dir=btf(-6), slope_grade=0.036,
        hazards=(FBunker(0.55, -27, 22), FBunker(0.63, 24, 18), GBunker(200, 2, 8)),
        note="Home between the dunes, with sand exactly where you want to be.",
    ),
)


AUGUSTA = CourseSpec(
    name="Augusta National",
    blurb="The real thing. Par 72, 7,555 yards of pine straw and lightning greens.\n"
    "Wide off the tee, terrifying once you get there.",
    seed=1934,
    wind_max=15.0,
    roll_mult=1.2,
    # The quickest greens in the game, but not so quick that a good lag putt
    # runs 8 feet by: measured leaves got silly below about 0.95.
    green_friction=0.95,
    slope_max=0.05,
    tree_density=1.7,
    scripted=AUGUSTA_HOLES,
    real=True,
    flag_color=FLAG_YELLOW,  # Augusta's pins are yellow, not the usual red
)


PEBBLE_PINES = CourseSpec(
    name="Pebble Pines",
    blurb="Classic parkland. Generous fairways, tree-lined, gentle greens.\n"
    "A good place to learn the swing.",
    seed=1207,
    wind_max=13.0,
    roll_mult=1.0,
    green_friction=1.35,
    slope_max=0.022,
    water_chance=0.28,
    tree_density=1.5,
    bunkers=(1, 2),
    dogleg=0.55,
    fairway_half=30.0,
)

HIGHLAND_LINKS = CourseSpec(
    name="Highland Links",
    blurb="Windswept links. Firm ground, glassy greens, deep pot bunkers.\n"
    "Keep it low and take your medicine.",
    seed=7741,
    wind_max=28.0,
    roll_mult=1.55,
    green_friction=1.00,
    slope_max=0.038,
    water_chance=0.10,
    tree_density=0.15,
    bunkers=(2, 4),
    dogleg=0.75,
    fairway_half=26.0,
)

PALM_CAY = CourseSpec(
    name="Palm Cay",
    blurb="Resort target golf. Wide landing areas but water everywhere,\n"
    "and slow, receptive greens.",
    seed=3390,
    wind_max=19.0,
    roll_mult=0.85,
    green_friction=1.65,
    slope_max=0.026,
    water_chance=0.72,
    tree_density=0.9,
    bunkers=(1, 3),
    dogleg=0.45,
    fairway_half=34.0,
)

ST_ANDREWS = CourseSpec(
    name="St Andrews Old",
    blurb="The Home of Golf. Par 72, 7,305 yards of firm links turf, gorse\n"
    "and pot bunkers. No trees, nowhere to hide, and the wind decides.",
    seed=1552,  # the year the townsfolk were granted the right to play there
    wind_max=32.0,  # the highest in the game: on the Old Course the wind is the course
    roll_mult=1.75,  # baked links turf -- the ball runs for ever
    green_friction=1.05,
    slope_max=0.034,
    tree_density=0.0,  # there is not a single tree on the Old Course
    scripted=ST_ANDREWS_HOLES,
    real=True,
)

PINEHURST_NO2 = CourseSpec(
    name="Pinehurst No. 2",
    blurb="Donald Ross's masterpiece. Par 70, 7,530 yards, not one drop of\n"
    "water, and greens shaped like turtle shells that throw the ball off.",
    seed=1907,
    wind_max=13.0,
    roll_mult=1.35,  # sandhills soil, and the ball chases off those crowns
    green_friction=1.05,
    slope_max=0.030,  # the crowns do the work, not the tilt
    tree_density=1.1,  # longleaf pines, but they stand well back
    scripted=PINEHURST_HOLES,
    real=True,
)

OLD_TOWN = CourseSpec(
    name="Old Town Club",
    blurb="Perry Maxwell in the Winston-Salem hills, restored by Coore and\n"
    "Crenshaw. Par 70, 6,825 yards. Huge fairways, and greens that roll.",
    seed=1939,
    wind_max=12.0,
    roll_mult=1.25,
    green_friction=1.10,
    slope_max=0.050,  # Maxwell rolls: the steepest real greens in the game
    tree_density=0.45,  # most of the timber came out in the restoration
    scripted=OLD_TOWN_HOLES,
    real=True,
    flag_color=FLAG_YELLOW,
)

TOBACCO_ROAD = CourseSpec(
    name="Tobacco Road",
    blurb="Mike Strantz's fever dream in the North Carolina sandhills.\n"
    "Par 71, 6,555 yards. Blind shots, vast waste, and no room at all.",
    seed=1998,
    wind_max=14.0,
    roll_mult=1.40,
    green_friction=1.15,
    slope_max=0.040,
    tree_density=1.3,
    scripted=TOBACCO_ROAD_HOLES,
    real=True,
)

COURSES: list[CourseSpec] = [
    AUGUSTA,
    ST_ANDREWS,
    PINEHURST_NO2,
    OLD_TOWN,
    TOBACCO_ROAD,
    PEBBLE_PINES,
    HIGHLAND_LINKS,
    PALM_CAY,
]
