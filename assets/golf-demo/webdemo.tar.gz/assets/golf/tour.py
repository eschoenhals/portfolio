"""The tour: who is out there, and how well a CPU plays.

Two kinds of number live here and they are deliberately not the same thing.

``Pro.rating`` is *strokes per round better than the tour's own field average*.
It is the only input the statistical field simulation in :mod:`golf.career`
takes, because a tournament field is scored, never played -- nobody wants to
watch sixty balls.  The scale is the familiar one: the best player in the world
is worth a bit over two and a half shots a round on the field, the median card
is zero, and the back of the roster gives up half a shot.

``Level`` is how a *watched* opponent plays in match play, where the ball is
real and every shot goes through the physics engine.  Its numbers are the ones
handed to ``Game.fire`` and ``Game.strike_putt`` -- an accuracy-meter miss and a
power, exactly what a person at the keyboard produces.  A rating cannot be used
for this: knowing someone averages 69 tells you nothing about which club they
pull on a par 5.

The two are joined only at the menu, where picking a difficulty picks the band
of the roster a "Random" opponent is drawn from.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, replace

from .clubs import ARCHETYPES, Archetype


@dataclass(frozen=True)
class Pro:
    name: str
    rating: float  # strokes per round better than the field average


#: The roster, strongest first.  Order is meaningful -- :func:`band` slices it --
#: so add players in rating order rather than appending to the end.
ROSTER: list[Pro] = [
    Pro("Scottie Scheffler", 2.62),
    Pro("Rory McIlroy", 2.11),
    Pro("Xander Schauffele", 1.83),
    Pro("Ludvig Aberg", 1.70),
    Pro("Collin Morikawa", 1.66),
    Pro("Jon Rahm", 1.62),
    Pro("Bryson DeChambeau", 1.55),
    Pro("Viktor Hovland", 1.44),
    Pro("Tommy Fleetwood", 1.36),
    Pro("Justin Thomas", 1.31),
    Pro("Patrick Cantlay", 1.28),
    Pro("Hideki Matsuyama", 1.24),
    Pro("Russell Henley", 1.16),
    Pro("Shane Lowry", 1.12),
    Pro("Sepp Straka", 1.08),
    Pro("Wyndham Clark", 1.03),
    Pro("Matt Fitzpatrick", 0.99),
    Pro("Cameron Young", 0.96),
    Pro("Robert MacIntyre", 0.92),
    Pro("Tyrrell Hatton", 0.89),
    Pro("Sungjae Im", 0.86),
    Pro("Sam Burns", 0.83),
    Pro("Corey Conners", 0.80),
    Pro("Keegan Bradley", 0.77),
    Pro("Aaron Rai", 0.74),
    Pro("Brian Harman", 0.71),
    Pro("Akshay Bhatia", 0.68),
    Pro("Max Homa", 0.65),
    Pro("Jordan Spieth", 0.62),
    Pro("Tony Finau", 0.59),
    Pro("Will Zalatoris", 0.56),
    Pro("Sahith Theegala", 0.53),
    Pro("Taylor Pendrith", 0.50),
    Pro("Min Woo Lee", 0.47),
    Pro("Justin Rose", 0.45),
    Pro("Denny McCarthy", 0.42),
    Pro("Si Woo Kim", 0.39),
    Pro("Harris English", 0.36),
    Pro("J.T. Poston", 0.33),
    Pro("Nick Taylor", 0.30),
    Pro("Christiaan Bezuidenhout", 0.27),
    Pro("Thomas Detry", 0.24),
    Pro("Cam Davis", 0.21),
    Pro("Matthieu Pavon", 0.18),
    Pro("Nicolai Hojgaard", 0.15),
    Pro("Adam Scott", 0.12),
    Pro("Jason Day", 0.09),
    Pro("Alex Noren", 0.06),
    Pro("Kurt Kitayama", 0.03),
    Pro("Stephan Jaeger", 0.00),
    Pro("Mackenzie Hughes", -0.03),
    Pro("Ben Griffin", -0.06),
    Pro("Eric Cole", -0.09),
    Pro("Adam Hadwin", -0.12),
    Pro("Seamus Power", -0.15),
    Pro("Emiliano Grillo", -0.18),
    Pro("Chris Kirk", -0.21),
    Pro("Lucas Glover", -0.24),
    Pro("Billy Horschel", -0.27),
    Pro("Rickie Fowler", -0.30),
    Pro("Davis Riley", -0.33),
    Pro("Andrew Putnam", -0.36),
    Pro("Beau Hossler", -0.39),
    Pro("Lee Hodges", -0.42),
    Pro("Nate Lashley", -0.45),
    Pro("Patrick Reed", -0.48),
    Pro("Brooks Koepka", -0.51),
    Pro("Cameron Smith", -0.54),
    Pro("Dustin Johnson", -0.57),
    Pro("Webb Simpson", -0.60),
    Pro("Zach Johnson", -0.64),
    Pro("Peter Malnati", -0.68),
]

NAMES: list[str] = [p.name for p in ROSTER]


def find(name: str) -> Pro:
    """A pro by name, falling back to a median card for anyone unknown.

    Saved careers hold names rather than indexes, so a roster edit must not be
    able to break a career that is halfway through a season.
    """
    for pro in ROSTER:
        if pro.name == name:
            return pro
    return Pro(name, 0.0)


# --------------------------------------------------------------------- difficulty


@dataclass(frozen=True)
class Level:
    """How a watched opponent plays.

    ``err`` is the sigma of the accuracy-meter miss it hands to ``Game.fire``:
    the same number a person produces by stopping the descending meter, where
    zero is pured and 0.18 is the bottom of the sweep.  It is the dominant term
    by far -- on a driver it is worth about 120 yards of bend per unit -- so the
    four levels are mostly this one number.

    ``nerve`` is judgement rather than execution: how much of the wind it
    allows for, whether it lays up short of water instead of taking it on, and
    how finely it reads a putt.  A low-nerve opponent misses because it played
    the wrong shot, which is a different and more interesting kind of bad than
    simply shaking.
    """

    name: str
    blurb: str
    err: float  # sigma of the accuracy-meter miss
    power_err: float  # sigma on the power it stops the meter at
    putt: float  # putting error scale, multiplying the archetype's own
    nerve: float  # 0..1 -- how well it plays the wind, the lie and the trouble
    arch: str  # the Archetype it plays
    band: tuple[int, int]  # slice of ROSTER a "Random" opponent comes from

    # Every level plays Balanced on purpose.  The archetypes are a *trade* --
    # a Dinker buys accuracy with nine per cent of its carry -- so handing the
    # hardest level a Dinker made it play longer clubs into every green and cost
    # it back everything its better hands had won.  A ladder of difficulty wants
    # one axis, not two: err and nerve are the whole ladder.


LEVELS: list[Level] = [
    Level(
        "Amateur",
        "Plays off about 12. Sprays it, takes on carries it has no business\n"
        "attempting, and three-putts. You should beat this.",
        err=0.085, power_err=0.055, putt=1.55, nerve=0.20, arch="Balanced",
        band=(55, 72),
    ),
    Level(
        "Club Pro",
        "A good player having a normal day: mostly in play, sensible about\n"
        "trouble, and will hole enough putts to punish a loose hole.",
        err=0.048, power_err=0.032, putt=1.15, nerve=0.55, arch="Balanced",
        band=(35, 60),
    ),
    Level(
        "Tour Pro",
        "Finds fairways, takes the right side of every flag, and does not\n"
        "give a hole away. You will need birdies, not pars.",
        err=0.022, power_err=0.016, putt=0.82, nerve=0.85, arch="Balanced",
        band=(8, 30),
    ),
    Level(
        "Legend",
        "Flushes it, reads greens you cannot, and sits on the 100% line every\n"
        "time. Two over at Augusta, eight under at St Andrews. Par will not\n"
        "beat this.",
        err=0.009, power_err=0.007, putt=0.48, nerve=1.00, arch="Balanced",
        band=(0, 8),
    ),
]


def level_by_name(name: str) -> Level:
    for lv in LEVELS:
        if lv.name == name:
            return lv
    return LEVELS[1]


def archetype_for(level: Level) -> Archetype:
    """The bag the opponent swings.

    Putting is the one part of a CPU's game that ``err`` cannot reach --
    ``strike_putt`` scales its stroke by ``arch.putting`` and nothing else -- so
    the level's putting difficulty is folded in here rather than smuggled into
    the putt call.  Everything else is left exactly as the archetype authored it,
    so a Legend is a Dinker who happens to putt beautifully, not a bespoke set of
    physics.
    """
    base = next((a for a in ARCHETYPES if a.name == level.arch), ARCHETYPES[0])
    return replace(base, putting=base.putting * level.putt)


def opponent_for(level: Level, rng: random.Random | None = None) -> str:
    """A name from the part of the roster that suits this difficulty."""
    lo, hi = level.band
    picks = NAMES[lo:hi] or NAMES
    return (rng or random).choice(picks)
